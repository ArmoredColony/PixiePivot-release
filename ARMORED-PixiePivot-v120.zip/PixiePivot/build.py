#!/usr/bin/env python3

import subprocess
import sys
import re
import pathlib


MAKER_PREFIX = 'ARMORED'
MANIFEST_NAME = 'blender_manifest.toml'


def fail(message: str, code: int = 1) -> None:
	print(message)
	sys.exit(code)


def run_git_command(args: list[str]) -> str:
	result = subprocess.run(
		['git', *args],
		stdout=subprocess.PIPE,
		stderr=subprocess.PIPE,
		text=True,
	)
	if result.returncode != 0:
		fail(result.stderr.strip() or 'Git command failed.')
	return result.stdout.strip()


def parse_manifest(path: pathlib.Path) -> tuple[str, str, str]:
	content = path.read_text(encoding='utf-8')

	id_match = re.search(r"^id\s*=\s*'([^']+)'", content, re.MULTILINE)
	name_match = re.search(r"^name\s*=\s*'([^']+)'", content, re.MULTILINE)
	version_match = re.search(r"^version\s*=\s*'([^']+)'", content, re.MULTILINE)

	if not id_match or not version_match:
		fail('Could not parse id or version from blender_manifest.toml.')

	id_value = id_match.group(1)
	name_value = name_match.group(1) if name_match else ''
	version_value = version_match.group(1)

	return id_value, name_value, version_value


def main() -> None:
	force = '--force' in sys.argv

	if not pathlib.Path('.git').exists():
		fail('Not a git repository. Run this from the repo root.')

	manifest_path = pathlib.Path(MANIFEST_NAME)
	if not manifest_path.exists():
		fail('blender_manifest.toml not found in repo root.')

	git_status = run_git_command(['status', '--porcelain'])

	if git_status and not force:
		print('\nWarning: Uncommitted changes detected.')
		confirm = input('Build from last commit anyway? (y/N): ').strip().lower()
		if confirm != 'y':
			fail('Build cancelled.')

	id_value, name_value, version_value = parse_manifest(manifest_path)

	version_flat = version_value.replace('.', '')
	archive_name = f'{MAKER_PREFIX}-{id_value}-v{version_flat}.zip'

	print('\nBuild Summary:')
	print(f'  ID:       {id_value}')
	print(f'  Name:     {name_value}')
	print(f'  Version:  {version_value}')
	print(f'  Output:   {archive_name}\n')

	confirm = input('Press Enter to build, or type anything to cancel: ')
	if confirm.strip():
		print('Build cancelled.')
		sys.exit(0)

	print(f'Building {archive_name} ...')

	subprocess.run([
		'git',
		'archive',
		'--format=zip',
		f'--prefix={id_value}/',
		'-o',
		archive_name,
		'HEAD'
	], check=True)

	print('Done.')


if __name__ == '__main__':
	main()