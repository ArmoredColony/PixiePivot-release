#!/usr/bin/env python3

import subprocess
import sys
import re
import pathlib

MAKER_PREFIX = 'ARMORED'
MANIFEST_NAME = 'blender_manifest.toml'


def fail(message: str, code: int = 1) -> None:
	'''
	Print a message and exit with the given code.
	'''
	print(message)
	sys.exit(code)


def run_git_command(args: list[str]) -> str:
	'''
	Run a git command and return stdout, fail on error.
	'''
	result = subprocess.run(
		['git', *args],
		stdout=subprocess.PIPE,
		stderr=subprocess.PIPE,
		text=True,
	)
	if result.returncode != 0:
		fail(result.stderr.strip() or 'Git command failed.')
	return result.stdout.strip()


def parse_manifest(path: pathlib.Path) -> tuple[str, str, str]:
	'''
	Parse id, name, and version from the blender_manifest.toml.
	'''
	content = path.read_text(encoding='utf-8')

	id_match = re.search(r"^id\s*=\s*'([^']+)'", content, re.MULTILINE)
	name_match = re.search(r"^name\s*=\s*'([^']+)'", content, re.MULTILINE)
	version_match = re.search(r"^version\s*=\s*'([^']+)'", content, re.MULTILINE)

	if not id_match or not version_match:
		fail('Could not parse id or version from blender_manifest.toml.')

	id_value = id_match.group(1)
	name_value = name_match.group(1) if name_match else ''
	version_value = version_match.group(1)

	return id_value, name_value, version_value


def find_latest_blender() -> str:
	'''
	Locate the latest installed Blender executable on Windows.
	Checks common installation folders instead of the registry.
	'''
	program_files = [
		pathlib.Path(r'C:\Program Files\Blender Foundation'),
		pathlib.Path(r'C:\Program Files (x86)\Blender Foundation')
	]

	candidates = []

	for base in program_files:
		if base.exists():
			for entry in base.iterdir():
				if entry.is_dir() and re.match(r'Blender \d+\.\d+', entry.name):
					blender_exe = entry / 'blender.exe'
					if blender_exe.exists():
						version = entry.name.split()[1]
						candidates.append((version, str(blender_exe)))

	if not candidates:
		fail('No installed Blender versions found in standard folders.')

	# Sort versions numerically and pick the latest
	candidates.sort(key=lambda x: list(map(int, x[0].split('.'))))
	latest_version, exe_path = candidates[-1]
	print(f'\nFound latest Blender version: {latest_version} at {exe_path}\n')
	return exe_path


def generate_extension_index(repo_dir: str) -> None:
	'''
	Run Blender to generate the extension index in the given directory.
	This mirrors the working terminal command exactly.
	'''

	print('\nRunning Blender extension server-generate...')
	blender_exe = find_latest_blender()
	repo_path = repo_dir

	cmd = [
		blender_exe,
		'--background',
		'--command',
		'extension',
		'server-generate',
		'--repo-dir',
		repo_path,
		'--html'
	]
	subprocess.run(cmd, check=True)
	print('Extension index generated successfully.\n')


def main() -> None:
	auto_yes = '--yes' in sys.argv

	if not pathlib.Path('.git').exists():
		fail('Not a git repository. Run this from the repo root.')

	manifest_path = pathlib.Path(MANIFEST_NAME)
	if not manifest_path.exists():
		fail('blender_manifest.toml not found in repo root.')

	git_status = run_git_command(['status', '--porcelain'])

	if git_status and not auto_yes:
		print('\nWarning: Uncommitted changes detected.')
		confirm = input('Build from last commit anyway? [Y/n]: ').strip().lower()
		if confirm not in ('', 'y', 'yes'):
			fail('Build cancelled.')

	id_value, name_value, version_value = parse_manifest(manifest_path)
	version_flat = version_value.replace('.', '')
	archive_name = f'{MAKER_PREFIX}-{id_value}-v{version_flat}.zip'

	print('\nBuild Summary:')
	print(f'  ID:       {id_value}')
	print(f'  Name:     {name_value}')
	print(f'  Version:  {version_value}')
	print(f'  Output:   {archive_name}\n')

	if not auto_yes:
		confirm = input('Build archive now? [Y/n]: ').strip().lower()
		if confirm not in ('', 'y', 'yes'):
			print('Build cancelled.')
			sys.exit(0)

	print(f'\nBuilding {archive_name} ...')
	subprocess.run([
		'git',
		'archive',
		'--format=zip',
		f'--prefix={id_value}/',
		'-o',
		archive_name,
		'HEAD'
	], check=True)
	print('Archive build complete.\n')

	if not auto_yes:
		gen_index = input('Generate extension index as well? [Y/n]: ').strip().lower()
		run_index = gen_index in ('', 'y', 'yes')
	else:
		run_index = True

	if run_index:
		generate_extension_index(repo_dir='.')
	else:
		print('Skipping extension index generation.\n')


if __name__ == '__main__':
	main()