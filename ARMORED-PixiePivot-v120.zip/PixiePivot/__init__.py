import sys


EXTENSION_PACKAGE = __package__


# FOR HOT-RELOADS
if 'bpy' in locals():
	if __name__ in sys.modules:
		del sys.modules[__name__]

	dotted = __name__ + '.'
	for name in tuple(sys.modules):
		if name.startswith(dotted):
			del sys.modules[name]


import bpy
from . import source

def register():
	source.register()


def unregister():
	source.unregister()

