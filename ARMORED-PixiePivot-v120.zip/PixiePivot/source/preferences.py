import bpy
import functools
import string


from . import keymaps

from .icons import promo_icons

from .utils import addon
from .utils import debug
from .utils import pretty
from .utils import prop_forge
from .utils import release_check



# CONSTANTS __________________________________________________

ALPHANUMERIC_CHARS = string.ascii_letters + string.digits
# SHOW_PROP_ICONS = False

MODIFIER_ACTIONS = (
	'OPERATION_TYPE',
	'ALIGN_WITH_NORMAL',
	'LOCK_CURSOR_LOCATION',
	'SNAP_TO_BOUNDING_BOX',
	'USE_GLOBAL_ORIENTATION',
	'DO_NOTHING',
)

AXES = ('X', 'Y', 'Z')


# TYPE ALIASES __________________________________________________

BPYEnumID = str
BPYEnumName = str
BPYEnumDescription = str



# HELPERS __________________________________________________

def itemize(str_list) -> list[tuple[BPYEnumID, BPYEnumName, BPYEnumDescription]]:
	'''
	Return as a list of items compatible with Blender EnumProperty types.
	- Description is empty.
	'''
	
	enum_items = []
	for elem in str_list:
		enum_items.append((elem, pretty.title(elem), ''))
	
	return enum_items


def rgba_prop(name, default=(0, 0, 0, 1)) -> bpy.props.FloatVectorProperty:
	return bpy.props.FloatVectorProperty(
		name=name,
		default=default,
		subtype='COLOR_GAMMA',
		min=0,
		max=1,
		size=4,
	)
				

# RegularKeyProps HANDLERS __________________________________________________

def get_normalized_char(char: str) -> str | None:
	'''
	Return uppercase single alphanumeric, or None if invalid.
	'''

	if not char:
		return None
	
	char = char.strip()
	if len(char) != 1:
		return None
	
	up = char.upper()

	return up if up in ALPHANUMERIC_CHARS else None


def _unset_duplicates(self, current_prop) -> None:
	'''
	Loop over the other modal _key props and set duplicates to empty strings.
	'''
	
	for other_prop in RegularKeyProps.get_prop_keys():
		if other_prop == current_prop:
			continue

		debug.msg('    Look at', other_prop)

		if getattr(self, other_prop) == '':
			continue
		
		if getattr(self, other_prop) == getattr(self, current_prop):
			debug.msg('    ...remove Duplicate')
			setattr(self, other_prop, '')
	
	debug.msg()


update_key_guard = False
@debug.run_check
def update_key(self, context, prop) -> None:
	'''
	Ensure Uppercase char or empty string when invalid.
	- Calls normalize char func.
	- Calls unset duplicates func.
	'''
	
	global update_key_guard

	if update_key_guard:
		debug.msg('Guard', prop)
		return

	update_key_guard = True
	debug.msg('Update Triggered', prop)

	raw = getattr(self, prop)
	debug.msg('raw', raw)

	if raw == '':
		return
	
	norm_char = get_normalized_char(raw)
	debug.msg('norm_char', norm_char)

	if norm_char is None:
		debug.msg('Invalid Raw Val', 'Unset to Default')
		self.property_unset(prop)

		return

	setattr(self, prop, norm_char)
	
	_unset_duplicates(self, prop)

	update_key_guard = False


class RegularKeyProps(prop_forge.PropGroup):
	'''
	Mode-selector and single-action Key defaults.
	'''

	PRETTY_NAME = 'Sticky Toggle Keys'

	def char_prop(name: str, default: str = ''):
		return bpy.props.StringProperty(
			name=pretty.title(name.removesuffix('_key')),
			default=default,
			maxlen=1,
			update=lambda self, context: update_key(self, context, name)
		)
	
	# NOTE
	# The name argument must match the annotation, otherwise any formatting
	# will get captured by the lambdas and break stuff.
	
	# Setters
	one_point_pivot_key:	char_prop('one_point_pivot_key', '1')
	two_point_pivot_key:	char_prop('two_point_pivot_key', '2')
	three_point_pivot_key:	char_prop('three_point_pivot_key', '3')
	set_origin_key:		char_prop('set_origin_key', 'O')
	set_cursor_key:		char_prop('set_cursor_key', 'C')
	set_x_axis_key:		char_prop('set_x_axis_key', 'X')
	set_y_axis_key:		char_prop('set_y_axis_key', 'Y')
	set_z_axis_key:		char_prop('set_z_axis_key', 'Z')
	reset_defaults_key:	char_prop('reset_defaults_key', 'R')

	_M1: prop_forge.AddSeparator

	# Toggles
	lock_cursor_location_key:	char_prop('lock_cursor_location_key', 'T')
	align_with_normal_key:		char_prop('align_with_normal_key', 'N')
	snap_to_bounding_box_key:	char_prop('snap_to_bounding_box_key', 'B')
	use_global_orientation_key:	char_prop('use_global_orientation_key', 'G')

	# ICONS = {
	# 	'one_point_pivot_key': 'ERROR'
	# }


class ModifierActionProps(prop_forge.PropGroup):
	PRETTY_NAME = 'Modifier Actions'
	
	@staticmethod
	def mod_action(name, default):
		return bpy.props.EnumProperty(
			name=name, 
			default=default, 
			items=itemize(MODIFIER_ACTIONS),
		)
	
	use_maya_navigation: bpy.props.BoolProperty(
		name='Use Maya Navigation',
		default=False
	)

	_M1: prop_forge.AddSeparator

	ctrl_action: mod_action(
		name='CTRL Action',
		default='OPERATION_TYPE',
	)

	_M2: prop_forge.GateIfStart(source='use_maya_navigation', value=True, action='disable_and_alert')

	alt_action: mod_action(
		name='ALT Action',
		default='SNAP_TO_BOUNDING_BOX',
	)
	_M3: prop_forge.GateEnd

	shift_action: mod_action(
		name='SHIFT Action',
		default='ALIGN_WITH_NORMAL',
	)


class AxesAndElements(prop_forge.PropGroup):
	PRETTY_NAME = 'Axes and Elements'

	use_theme_colors: bpy.props.BoolProperty(
		name='Use Theme Colors', 
		default=True,
	)

	_M1: prop_forge.GateIfStart(source='use_theme_colors', value=False, action='draw')

	axis_x_rgba: rgba_prop('X Axis', (1.0, 0.0, 0.0, 1.0))
	axis_y_rgba: rgba_prop('Y Axis', (0.0, 1.0, 0.0, 1.0))
	axis_z_rgba: rgba_prop('Z Axis', (0.0, 0.0, 1.0, 1.0))

	_M2: prop_forge.GateEnd

	_M3: prop_forge.AddSeparator

	highlight_elements: bpy.props.BoolProperty(name='Highlight Elements', default=True)
	
	_M4: prop_forge.AddSeparator

	highlight_rgba:    rgba_prop('Highlight', (1.0, 1.0, 0.0, 1.0))
	bounding_box_rgba: rgba_prop('Bonding Box', (0.0, 0.0, 0.0, 1.0))


class MouseHUDColorProps(prop_forge.PropGroup):
	PRETTY_NAME = 'Mouse HUD'

	mouse_hud_base_rgba:	rgba_prop('Base',		(1.0, 1.0, 1.0, 1.0))
	origin_mode_rgba:	rgba_prop('Origin Mode',	(1.0, 1.0, 0.0, 1.0))
	active_states_rgba:	rgba_prop('Active States',	(1.0, 1.0, 0.5, 1.0))
	warning_rgba:		rgba_prop('Warning',		(1.0, 0.73, 0.24, 1.0))

	_M1: prop_forge.AddSeparator

	mouse_hud_shadow: bpy.props.BoolProperty(name='Draw Shadow', default=True)


class FixedHUDColorProps(prop_forge.PropGroup):
	PRETTY_NAME = 'Fixed HUD'

	fixed_hud_name_rgba:	rgba_prop('Name',	(1.0, 1.0, 1.0, 1.0))
	fixed_hud_hotkey_rgba:	rgba_prop('Hotkey',	(1.0, 1.0, 1.0, 0.7))
	fixed_hud_value_rgba:	rgba_prop('Value',	(0.6, 1.0, 0.6, 1.0))

	_M1: prop_forge.AddSeparator
	
	fixed_hud_shadow: bpy.props.BoolProperty(name='Draw Shadow', default=True)


class ScaleProps(prop_forge.PropGroup):
	PRETTY_NAME = None

	draw_scale: bpy.props.FloatProperty(
		name='Draw Scale',
		description='Scale multiplier for everything drawn by the addon (points, lines, text, etc)',
		default=1.0,
		min=.25,
	)

	_M1: prop_forge.AddSeparator

	axis_size: bpy.props.FloatProperty(
		name='Axis Size', 
		default=90, 
		min=25,
		subtype='PIXEL',
		step=1,
		precision=0,
	)

	axis_font_size: bpy.props.IntProperty(
		name='Axis Font Size', 
		description='Font size of the X, Y and Z labels at the axis tips', 
		default=16,
		min=6,
	)

	axis_width: bpy.props.FloatProperty(
		name='Axis Width', 
		default=2, min=0.5, 
		precision=1
	)

	_M2: prop_forge.AddSeparator

	hud_font_size: bpy.props.IntProperty(
		name='HUD Font Size', 
		description='Font size for the HUD text', 
		default=16,
		min=6,
	)

	_M3: prop_forge.AddSeparator

	vert_size:  bpy.props.FloatProperty(name='Vert Size',  default=8, min=0.5, precision=1)
	edge_width: bpy.props.FloatProperty(name='Edge Width', default=1, min=0.5, precision=1)


class LayoutProps(prop_forge.PropGroup):
	PRETTY_NAME = None

	draw_fixed_hud: bpy.props.BoolProperty(
		name='Draw Fixed HUD',
		description='Draw the fixed HUD which displays active modes and hotkeys',
		default=True,
	)

	fixed_hud_position: bpy.props.EnumProperty(
		name='Fixed HUD Position',
		description='Where to draw the fixed HUD',
		default='BOTOM_LEFT',
		items=[
			('BOTOM_LEFT',		'Bottom Left', ''),
			('BOTTOM_CENTER',	'Bottom Center', ''),
			('BOTTOM_RIGHT',	'Bottom Right', ''),
		]

	)
	

# BehaviorProps HANDLERS __________________________________________________

@debug.run_check
def update_primary(self, context) -> None:
	'''
	Prevents the Secondary axis being equal to the Primary one.
	'''
	
	if self.primary_axis == self.secondary_axis:
		# Pick a different secondary axis
		for axis in AXES:
			if axis != self.primary_axis:
				self.secondary_axis = axis
				break


@debug.run_check
def update_secondary(self, context) -> None:
	'''
	Prevents the Primary axis being equal to the Secondary one.
	'''

	if self.secondary_axis == self.primary_axis:
		# Pick a different primary axis
		for axis in AXES:
			if axis != self.secondary_axis:
				self.primary_axis = axis
				break


class BehaviorProps(prop_forge.PropGroup):
	PRETTY_NAME = 'Modal Behavior'

	primary_axis: bpy.props.EnumProperty(
		description='Which axis you want to align first in supported modes',
		default = 'Y',
		items=itemize(AXES),
		update=lambda self, context: update_primary(self, context),
	)


	secondary_axis: bpy.props.EnumProperty(
		description='Which axis you want to align second in supported modes',
		default = 'Z',
		items=itemize(AXES),
		update=lambda self, context: update_secondary(self, context),
	)

	_M1:  prop_forge.AddSeparator

	pivot_point_mode: bpy.props.EnumProperty(
		description='Initial behavior when the modal is activated',
		default='ONE',
		items=[
			('ONE',   'One Point Pivot', 'Pick one alignment point'),
			('TWO',   'Two Point Pivot', 'Pick two alignment points'),
			('THREE', 'Three Point Pivot', 'Pick three alignment points'),
		]
	)

	operation_type: bpy.props.EnumProperty(
		description='What gets placed when the pivot is confirmed',
		default='CURSOR',
		items=[
			('CURSOR',	'3D Cursor', ''),
			('ORIGIN',	'Origin', ''),
		]
	)

	lock_cursor_location: bpy.props.BoolProperty(
		description='Keep the pivot near your selection instead of moving it to the 3DCursor',
		default=False,
	)

	align_with_normal: bpy.props.BoolProperty(
		name='Align with Normal',
		description='Align with the target element normal if possible',
		default=False,
	)

	snap_to_bounding_box: bpy.props.BoolProperty(
		description='Snap to the object\'s bounding box instead of the mesh elements',
		default=False,
	)
	
	use_global_orientation: bpy.props.BoolProperty(
		description='Use global/world space instead of local/object space',
		default=False,
	)

	_M2:  prop_forge.AddSeparator

	persistent_state: bpy.props.BoolProperty(
		name='Remember Sticky Toggles', 
		description='Non-modifier state changes (ex: pressing "B" for Bounding Box) will be remembered',
		default=True,
	)

	hide_3d_cursor: bpy.props.BoolProperty(
		name='Hide 3D Cursor', 
		description='Hide the 3D Cursor while the modal is running',
		default=True,
	)

	orientation_items = [
		('GLOBAL',	'Global', ''),
		('LOCAL',	'Local', ''),
		('NORMAL',	'Normal', ''),
		('GIMBAL',	'Gimbal', ''),
		('VIEW',	'View', ''),
		('CURSOR',	'Cursor', ''),
		('PARENT',	'Parent', ''),
	]

	pivot_items = [
			# Unique number is REQUIRED after the optional icon string.
			('MEDIAN_POINT',	'Median Point',		'Average of selected vertices/objects',		'PIVOT_MEDIAN', 1),
			('BOUNDING_BOX_CENTER',	'Bounding Box Center',	'Center of the selection\'s bounding box', 	'PIVOT_BOUNDBOX', 2),
			('ACTIVE_ELEMENT',	'Active Element',	'Use the active element as pivot', 		'PIVOT_ACTIVE', 3),
			('INDIVIDUAL_ORIGINS',	'Individual Origins',	'Pivot for each selected object individually', 	'PIVOT_INDIVIDUAL', 4),
			# ('CURSOR', '3D Cursor', 'Use the 3D cursor as pivot'),
		]
	
	_M3:  prop_forge.AddSeparator

	double_tap_resets_to: bpy.props.EnumProperty(
		name='Double Tap resets to',
		default='PREVIOUS',
		items=[
			('PREVIOUS',	'Previous Non-Cursor',	'Double-tap resets back to the previous Orientation and Pivot that were NOT the CURSOR'),
			('DEFAULT',	'Blender Defaults',	'Double-tap resets back to GLOBAL Orientation and MEDIAN_POINT Pivot'),
			('CUSTOM',	'Custom',		'Double-tap resets back to specific Orientation and Pivot values'),

		],
	)

	_M4: prop_forge.GateIfStart(source='double_tap_resets_to', value='CUSTOM', action='draw')
	
	transform_orientation_reset: bpy.props.EnumProperty(
		name='Transform Orientation Reset',
		default='GLOBAL',
		items=orientation_items,
	)

	transform_pivot_point_reset: bpy.props.EnumProperty(
		name='Pivot Pivot Reset',
		default='MEDIAN_POINT',
		items=pivot_items,
	)

	_M5: prop_forge.GateEnd
	
	_M6:  prop_forge.AddSeparator

	bounds_calculator: bpy.props.EnumProperty(
		default='ACCURATE',
		items=[
			('ACCURATE', 'Accurate', 'Encapsulates objects tightly, even with form-changing modifiers like Subdivision Surfaces, but can be slow with heavy meshes because it has to iterate over every vertex'),
			('FAST',     'Fast',     'Only recommended for really heavy meshes that do not have modifiers, otherwise the result may be innacurate.'),

		],
	)


def draw_url_button(columns, text, button_text, url, icon=None) -> bpy.types.Operator:
	columns[0].label(text=text)
	op = columns[-1].operator('wm.url_open', text=button_text)
	op.url = url
	
	if icon and len(columns) >= 3:
		columns[1].label(text='', icon=icon)

	return op


def draw_release_check_result(layout):
	addon_prefs = addon.get_preferences()

	# Double check
	if not addon_prefs.check_for_updates:
		return
	
	s = release_check.get_release_state()
	fetch   = s['fetch']
	local   = s['local']
	latest  = s['latest']
	derived = s['derived']


	# Not done yet
	if not fetch.get('has_fetched'):
		if fetch.get('fetch_in_progress'):
			layout.label(text='Checking for new versions...', icon='TIME')
		return

	# Error during fetch/parse
	if fetch.get('error_message'):
		layout.label(text='New version check failed', icon='ERROR')
		return

	# Remote metadata missing a usable version
	if not derived.get('has_latest_version_info'):
		layout.label(text='Could not find latest version info in repo', icon='ERROR')
		return
	

	current_str = local.get('current_version_string')
	latest_str = latest.get('latest_version_string')

	if derived.get('update_available'):
		layout.label(text=f'Update Available: {current_str} → {latest_str}', icon='INFO')
		return
	
	# WHY IS THERE NO UPDATE?
	current_tuple = local.get('current_version_tuple')
	latest_tuple = latest.get('latest_version_tuple')
	
	# Missing current info
	if not current_tuple or not latest_tuple:
		layout.label(text=f'Failed update check', icon='INFO')
		return

	# Already Up to Date
	if current_tuple == latest_tuple:
		layout.label(text=f'Up to date: {current_str}', icon='CHECKMARK')
		return
	
	if current_tuple >= latest_tuple:
		layout.label(text=f'Your version: {current_str} is ahead of the latest: {latest_str}', icon='INFO')
		return
	

@prop_forge.inject_prop_groups(
	RegularKeyProps,
	ModifierActionProps,
	AxesAndElements,
	ScaleProps,
	LayoutProps,
	MouseHUDColorProps,
	FixedHUDColorProps,
	BehaviorProps,
)
class ARMORED_PT_PixiePivot_Preferences(bpy.types.AddonPreferences):
	'''
	Addon Preferences inside the Blender Preferences Window.
	'''

	__slots__ = ()
	bl_idname = addon.get_extension_package()

	main_categories: bpy.props.EnumProperty(
		name='Preference Tabs',
		default='KEYMAPS',
		items=[ 
			('KEYMAPS',	'Keymaps',	'Hotkeys for activating tools and in-tool actions'),
			('APPEARANCE',	'Appearance',	'Colors, scaling, and UI layout'),
			('BEHAVIOR',	'Behavior',	'Controls how the tool operates'),
			('HELP',	'Help',		'Training videos and more'),
		]
	)

	sub_categories: bpy.props.EnumProperty(
		name='Preference Tabs',
		default='COLORS',
		items=[ 
			('COLORS',	'Colors',	'Colors for the UI and other drawn elements'),
			('SCALING',	'Scaling',	'Size of the UI and other drawn elements'),
			('LAYOUT',	'Layout',	'HUD placement and arrangement'),
		]
	)

	def _check_for_updates_handler(self, context):
		if self.check_for_updates:
			release_check.force_fetch_now()

	check_for_updates: bpy.props.BoolProperty(
		default=True,
		description=(
			'Merely compares add-on version numbers, nothing is downloaded. \n\n'
			'Users must download new versions manually, from the same '
			'website they purchased the add-on from.'
		),
		update=_check_for_updates_handler,
	)

	def draw(self, context):
		layout = self.layout
		col = layout.column(align=True)
		col.alignment = 'CENTER'
		
		# if self.check_for_updates:
		# 	row = col.row(align=True)
		# 	row.alignment = 'CENTER'
		# 	draw_release_check_result(row)
		# 	col.separator()

		promo_icons.draw(self, col)
		col.separator(factor=2)

		row = col.row(align=True)
		row.prop(self, 'main_categories', expand=True)

		if self.main_categories == 'KEYMAPS':
			col.separator(factor=4, type='LINE')
			self._draw_keymaps_section(layout=col)

		elif self.main_categories == 'APPEARANCE':
			self._draw_appearance_sub_sections(layout=col)

		elif self.main_categories == 'BEHAVIOR':
			col.separator(factor=4, type='LINE')
			self._draw_behavior_section(layout=col)

		elif self.main_categories == 'HELP':
			col.separator(factor=4, type='LINE')
			self._draw_help_section(layout=col)
		
		else:
			raise KeyError(f'The category {self.main_categories} does not exist')
		


	# PRIVATE METHODS __________________________________________________

	def _draw_keymaps_section(self, layout) -> None:
		'''
		Define the keymaps that activate and control the modal operator.
		'''
			
		# OPERATOR KEYMAP  __________________________________________________

		keymaps.draw_addon_keymaps(layout)
		layout.separator(factor=4)


		# MODAL KEYS  __________________________________________________

		prop_forge.boxed_description(layout, text='The following keys only work while the modal is running.')

		grid_flow = layout.grid_flow()

		prop_forge.draw_prop_group(self, grid_flow, ModifierActionProps)
		prop_forge.draw_prop_group(self, grid_flow, RegularKeyProps)
	
	def _draw_appearance_sub_sections(self, layout) -> None:
		'''
		Appearance is a category with subcategories.
		'''
		
		row_container = layout.row()
		left_row = row_container.row()
		center_row = row_container.row()
		right_row = row_container.row()
		left_row.label(text='')
		right_row.label(text='')
		center_row.prop(self, 'sub_categories', expand=True)
		layout.separator(factor=4, type='LINE')

		if self.sub_categories == 'COLORS':
			self._draw_colors_section(layout=layout)

		elif self.sub_categories == 'SCALING':
			self._draw_scaling_section(layout=layout)

		elif self.sub_categories == 'LAYOUT':
			self._draw_layout_section(layout=layout)
		else:
			raise KeyError(f'The sub-category {self.sub_categories} does not exist')

	def _draw_colors_section(self, layout) -> None:
		'''
		Control the colors of the elements drawn on the screen.
		'''
		
		# prop_forge.boxed_description(layout, text='Set color alphas to 0 to hide certain elements.')

		grid_flow = layout.grid_flow()

		# AXES AND ELEMENTS
		prop_forge.draw_prop_group(self, grid_flow, AxesAndElements)
		
		# MOUSE HUD
		prop_forge.draw_prop_group(self, grid_flow, MouseHUDColorProps)

		# FIXED HUD
		prop_forge.draw_prop_group(self, grid_flow, FixedHUDColorProps)
	
	def _draw_scaling_section(self, layout) -> None:
		'''
		Control the size of the elements drawn on the screen.
		'''

		prop_forge.boxed_description(layout, text='OS and Blender scaling are used automatically')

		grid_flow = layout.grid_flow()
		prop_forge.draw_prop_group(self, grid_flow, ScaleProps)


	def _draw_layout_section(self, layout) -> None:
		'''
		Control the size of the elements drawn on the screen.
		'''

		# prop_forge.boxed_description(layout, text='Layout bla bla')

		prop_forge.draw_prop_group(self, layout, LayoutProps)

		
	def _draw_behavior_section(self, layout) -> None:
		'''
		Control how the tool handles different situations.
		'''

		prop_forge.boxed_description(layout, text='Initial states and other behaviors')

		prop_forge.draw_prop_group(self, layout, BehaviorProps)

		prop_box = prop_forge.prop_box(layout, title='Other')
		prop_forge.FakeRow.build(
			self, prop_box, prop_name='check_for_updates', label='Check for updates'
		)


	def _draw_help_section(self, layout) -> None:
		'''
		Control how the tool handles different situations.
		'''
		
		# prop_forge.boxed_description(layout, text='Having issues? Try the latest ')

		grid_flow = layout.grid_flow()
		prop_box = functools.partial(prop_forge.prop_box, grid_flow)
		
		columns = prop_box(title='What\'s new?', use_icons=True)
		draw_url_button(
			columns,
			text='Changelog',
			button_text='Github',
			url=release_check.make_changelog_url(),
			icon='URL'
		)

		columns = prop_box(title='Youtube Videos', use_icons=True)
		video_url_button = functools.partial(draw_url_button, columns=columns, button_text='Watch', icon='FILE_MOVIE')

		video_url_button(text='Full Playlist',
			url='https://www.youtube.com/playlist?list=PLJJAC1PMAT69pBgVDXsvK7XOZ9qNvNvu8')
		
		video_url_button(text='What can Pixie do?',
			url='https://youtu.be/zqaX9lGHKE8')


# REPO_NAME = 'Pixie Pivot'
# REPO_URL = 'https://github.com/ArmoredColony/PixiePivot-release'


# def is_repo_public(url: str) -> bool:
# 	try:
# 		import urllib.request
# 		req = urllib.request.Request(url, method='HEAD')
# 		with urllib.request.urlopen(req) as resp:
# 			return resp.status == 200
# 	except Exception:
# 		return False


# def remove_unreachable_repos():
# 	for i, r in enumerate(bpy.context.preferences.extensions.repos):
# 		url = getattr(r, 'remote_url', None)
# 		if url and not is_repo_public(url):
# 			print(f'Repository {r.name} is unreachable, removing...')
# 			if bpy.ops.preferences.extension_repo_remove.poll():
# 				bpy.ops.preferences.extension_repo_remove(index=i, remove_files=False)
# 			else:
# 				print('Remove operator poll() failed – invalid context')


# def add_repo_if_missing():
# 	for r in bpy.context.preferences.extensions.repos:
# 		if getattr(r, 'remote_url', None) == REPO_URL:
# 			print(f'Repository {REPO_NAME} already exists, skipping add.')
# 			return

# 	if not is_repo_public(REPO_URL):
# 		print(f'Repository {REPO_NAME} is private or unreachable, skipping add.')
# 		return

# 	if bpy.ops.preferences.extension_repo_add.poll():
# 		result = bpy.ops.preferences.extension_repo_add(
# 			name=REPO_NAME,
# 			remote_url=REPO_URL,
# 			use_sync_on_startup=True,
# 			type='REMOTE'
# 		)
# 		print(f'bpy.ops Result {result}')
# 		print(f'Repository {REPO_NAME} added with sync enabled.')
# 	else:
# 		print('Operator poll() failed – invalid context')


# def manage_repo():
# 	print('Running timer one-shot...')
# 	remove_unreachable_repos()
# 	add_repo_if_missing()
# 	return None

classes = (
	ARMORED_PT_PixiePivot_Preferences,
)

def register() -> None:
	for cls in classes:
		bpy.utils.register_class(cls)


	promo_icons.register()

	# THREADING TEST
	# rc = release_check
	# rc.FETCH_ADAPTER = rc._fake_success_slow
	# rc.FETCH_ADAPTER = rc._fake_failure_slow

	# try:
	# 	addon_prefs = addon.get_preferences()

	# 	if addon_prefs.check_for_updates:
	# 		bpy.app.timers.register(manage_repo, first_interval=3.0)
	# 		# release_check.schedule_initial_fetch(first_interval=.5)

	# except Exception as e:
	# 	print(e)
	# 	print(f'PIXIE PIVOT → Non critical error; skip new release check')

	# if add_repo_on_load not in bpy.app.handlers.load_post:
	# 	bpy.app.handlers.load_post.append(add_repo_on_load)

	# bpy.app.timers.register(manage_repo, first_interval=3.0)

def unregister() -> None:
	for cls in classes:
		bpy.utils.unregister_class(cls)

	promo_icons.unregister()

	# if add_repo_on_load in bpy.app.handlers.load_post:
	# 	bpy.app.handlers.load_post.remove(add_repo_on_load)