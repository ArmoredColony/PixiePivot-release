import bpy
import blf
import math
import mathutils


from . import gizmo_shapes

from ..utils import addon
from ..utils import draw_text
from ..utils import drawcore
from ..utils import view3d

from ..runtime_state import runtime_state


FONT_PATH = str(addon.get_resources_path() / 'fonts' / 'Roboto-Bold.ttf')


# HELPERS ______________________________________________________

def invalid_gizmo_state():
	rs = runtime_state
	
	if rs.gizmo_matrix is None:
		return True
	
	return False


def draw_axis_labels(context):
	'''
	Draw 2D text labels for the axis tips.
	'''
	
	if invalid_gizmo_state():
		return

	addon_prefs = addon.get_preferences()
	scale = context.preferences.system.ui_scale * addon_prefs.draw_scale

	for axis_name, tip_world in runtime_state.axis_tip_world.items():
		if tip_world is None:
			continue

		co2d = view3d.get_2d_from_3d(tip_world, context)
		if co2d is None:
			continue

		ui = context.preferences.themes[0].user_interface
		axis_color = getattr(ui, f'axis_{axis_name.lower()}')

		draw_text.draw_text_center_center(
			text=axis_name,
			coords=co2d,
			color=draw_text.choose_bw_for_background(axis_color),
			font_id=blf.load(str(FONT_PATH)),
			font_size=addon_prefs.axis_font_size,
			scale=scale,
			shadow=False,
			dim_sample='XYZ',
		)


def matrix_without_scale(m: mathutils.Matrix) -> mathutils.Matrix:
	'''
	Return a copy of the 4x4 matrix 'm' with scale removed.
	- Preserves world location and rotation
	- Handles non-uniform/negative scale
	- Discards shear (if present)
	'''
	
	loc, rot, _scale = m.decompose()
	return mathutils.Matrix.LocRotScale(
		loc,
		rot,
		mathutils.Vector((1.0, 1.0, 1.0)),
	)


# GIZMO GROUP: 3 axis lines ____________________________________

class VIEW3D_GGT_pixie_axes(bpy.types.GizmoGroup):
	'''
	Three colored axis lines (X/Y/Z). Position & rotation come from your modal by setting matrix_basis.
	'''

	bl_idname = 'VIEW3D_GGT_pixie_axes'
	bl_label = 'Pixie Pivot'
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'WINDOW'
	bl_options = {'3D'}  # stays alive until you destroy()

	@classmethod
	def poll(cls, context):
		'''
		Always available; constrain here if needed.
		'''

		return True

	def setup(self, context):
		addon_prefs = addon.get_preferences()
		scale = context.preferences.system.ui_scale * addon_prefs.draw_scale

		color_x, color_y, color_z = drawcore.get_theme_axis_colors_rgba(context)

		Rx = mathutils.Matrix.Identity(4)                         # +X
		Ry = mathutils.Matrix.Rotation(math.pi * 0.5, 4, 'Z')     # +Y
		Rz = mathutils.Matrix.Rotation(-math.pi * 0.5, 4, 'Y')    # +Z

		self._axes = {}

		for name, rot, col in (
			('Z', Rz, color_z),
			('Y', Ry, color_y),
			('X', Rx, color_x),
		):
			gz = self.gizmos.new(gizmo_shapes.GIZMO_GT_line_3d.bl_idname)
			gz.color = col[:3]
			gz.alpha = col[3]
			gz.matrix_offset = rot
			gz.line_width_px = 2 * scale
			self._axes[name] = gz
	
	def draw_prepare(self, context):
		'''
		Read the global matrix each redraw and apply it to all gizmos.
		'''

		if invalid_gizmo_state():
			self.hide()
			return

		M = matrix_without_scale(runtime_state.gizmo_matrix)

		for axis_name, gz in self._axes.items():
			gz.matrix_basis = M

			# Compute actual drawn tip using matrix_world
			tip_world = gz.matrix_world @ mathutils.Vector((1.0, 0.0, 0.0))
			runtime_state.axis_tip_world[axis_name] = tip_world
		
		self.show()
	
	def hide(self):
		for gz in self._axes.values():
			gz.hide = True
	
	def show(self):
		for gz in self._axes.values():
			gz.hide = False

	@classmethod
	def create(cls, context):
		'''
		Ensure the gizmo group is created and active.
		'''

		wm = context.window_manager
		wm.gizmo_group_type_ensure(cls.bl_idname)

	@classmethod
	def destroy(cls, context):
		'''
		Unlink and remove the gizmo group.
		'''
		
		wm = context.window_manager
		wm.gizmo_group_type_unlink_delayed(cls.bl_idname)


class VIEW3D_GGT_pixie_tips(bpy.types.GizmoGroup):
	'''
	2D screen-space buttons positioned at projected axis tips.
	'''

	bl_idname = 'VIEW3D_GGT_pixie_tips'
	bl_label = 'Pixie Pivot 2D'
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'WINDOW'
	bl_options = {'SCALE'}  # MATCH PROTOTYPE

	@classmethod
	def poll(cls, context):
		return True
			
	def setup(self, context):
		addon_prefs = addon.get_preferences()
		color_x, color_y, color_z = drawcore.get_theme_axis_colors_rgba(context)

		self._axis_tips = {}
		self._label_positions = {}
		scale = context.preferences.system.ui_scale * addon_prefs.draw_scale

		for name, col in (
			('X', color_x),
			('Y', color_y),
			('Z', color_z),
		):	
			gz = self.gizmos.new(gizmo_shapes.GIZMO_GT_square_2d.bl_idname)
			gz.size = addon_prefs.axis_font_size * 0.6 * scale
			gz.roundness = 0.3
			gz.fill_color = col
			gz.outline_color = (0, 0, 0, 1)
			gz.line_width = 1

			self._axis_tips[name] = gz

	def draw_prepare(self, context):
		if invalid_gizmo_state():
			self.hide()
			return

		for axis_name in ('X', 'Y', 'Z'):
			gz = self._axis_tips[axis_name]

			tip_world = runtime_state.axis_tip_world.get(axis_name)

			if tip_world is None:
				gz.hide = True
				self._label_positions[axis_name] = None
				continue

			cords_2d = view3d.get_2d_from_3d(tip_world, context)

			self._label_positions[axis_name] = cords_2d

			if cords_2d:
				gz.x , gz.y = cords_2d
				gz.hide = False
			else:
				gz.hide = True

		self.show()

	def hide(self):
		for btn in self._axis_tips.values():
			btn.hide = True

	def show(self):
		for btn in self._axis_tips.values():
			btn.hide = False

	@classmethod
	def create(cls, context):
		wm = context.window_manager
		wm.gizmo_group_type_ensure(cls.bl_idname)

	@classmethod
	def destroy(cls, context):
		wm = context.window_manager
		wm.gizmo_group_type_unlink_delayed(cls.bl_idname)


classes = (
	VIEW3D_GGT_pixie_axes,
	VIEW3D_GGT_pixie_tips,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)


def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)