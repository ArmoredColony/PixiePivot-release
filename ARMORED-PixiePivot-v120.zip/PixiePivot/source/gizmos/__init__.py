from ... import module_loader

_imported = None


def register():
	global _imported
	_imported = module_loader.load_package_modules(__name__)
	module_loader.register_modules(_imported)


def unregister():
	global _imported
	mods = _imported or module_loader.load_package_modules(__name__)
	module_loader.unregister_modules(mods)
	_imported = None