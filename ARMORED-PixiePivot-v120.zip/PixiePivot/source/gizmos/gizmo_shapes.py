import bpy
import math
import mathutils
import gpu

import gpu_extras.batch as gpu_batch


class GIZMO_GT_line_3d(bpy.types.Gizmo):
	'''
	AA line using POLYLINE_UNIFORM_COLOR. Width is an RNA property.
	Length comes from matrix_basis @ matrix_offset mapping local [0..1] along +X.
	'''

	bl_idname = 'GIZMO_GT_line_3d'
	# __slots__ = ()

	# RNA property so value persists and can be set from the GizmoGroup / UI.
	line_width_px: bpy.props.FloatProperty(
		name='Line Width (px)',
		default=2.0,
		min=1.0,
		soft_max=24.0,
	)

	def setup(self):
		'''
		Initialize visual defaults. Do not set custom properties here.
		'''

		self.color = (1.0, 1.0, 1.0)
		self.alpha = 1.0

	def draw(self, context):
		'''
		Draw an AA line segment in world space using POLYLINE_UNIFORM_COLOR.
		'''

		# M = self.matrix_basis @ self.matrix_offset
		M = self.matrix_world	# Keeps size fixed in screen space
		p0 = (M @ mathutils.Vector((0.0, 0.0, 0.0, 1.0))).to_3d()
		p1 = (M @ mathutils.Vector((1.0, 0.0, 0.0, 1.0))).to_3d()
		coords = [tuple(p0), tuple(p1)]

		shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
		batch = gpu_batch.batch_for_shader(shader, 'LINES', {'pos': coords})

		prev_depth = gpu.state.depth_test_get()
		prev_blend = gpu.state.blend_get()
		gpu.state.depth_test_set('NONE')
		gpu.state.blend_set('ALPHA')

		shader.bind()
		shader.uniform_float('color', (*self.color, float(self.alpha)))
		shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
		shader.uniform_float('lineWidth', self.line_width_px)

		batch.draw(shader)

		gpu.state.depth_test_set(prev_depth)
		gpu.state.blend_set(prev_blend)

	def test_select(self, context, location):
		'''
		Non-interactive gizmo.
		'''

		return -1


class GIZMO_GT_square_2d(bpy.types.Gizmo):
	bl_idname = 'GIZMO_GT_square_2d'
	bl_label = 'Basic 2D Gizmo'

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)

		# Dynamic properties that can be updated each frame
		self.x = 500.0
		self.y = 500.0
		self.size = 40.0
		self.roundness = 0.3
		self.fill_color = (1.0, 1.0, 1.0, 1.0)
		self.outline_color = (0.0, 0.0, 0.0, 1.0)
		self.line_width = 1.0

	def _geometry(self):
		'''Return verts & indices for a rounded rectangle in screen space'''
		size = self.size
		r = self.roundness * size
		steps = 8  # smoothness of corners
		x, y = self.x, self.y

		verts = []

		# Top edge
		for i in range(steps + 1):
			t = i / steps
			verts.append((x - size + r + t * (2 * (size - r)), y + size))

		# Top-right corner
		for i in range(steps + 1):
			theta = math.radians(90 - (i / steps) * 90)
			verts.append((x + size - r + math.cos(theta) * r, y + size - r + math.sin(theta) * r))

		# Right edge down
		for i in range(steps + 1):
			t = i / steps
			verts.append((x + size, y + size - r - t * (2 * (size - r))))

		# Bottom-right corner
		for i in range(steps + 1):
			theta = math.radians(0 - (i / steps) * 90)
			verts.append((x + size - r + math.cos(theta) * r, y - size + r + math.sin(theta) * r))

		# Bottom edge left
		for i in range(steps + 1):
			t = i / steps
			verts.append((x + size - r - t * (2 * (size - r)), y - size))

		# Bottom-left corner
		for i in range(steps + 1):
			theta = math.radians(270 - (i / steps) * 90)
			verts.append((x - size + r + math.cos(theta) * r, y - size + r + math.sin(theta) * r))

		# Left edge up
		for i in range(steps + 1):
			t = i / steps
			verts.append((x - size, y - size + r + t * (2 * (size - r))))

		# Top-left corner
		for i in range(steps + 1):
			theta = math.radians(180 - (i / steps) * 90)
			verts.append((x - size + r + math.cos(theta) * r, y + size - r + math.sin(theta) * r))

		# Center for fan
		center = (x, y)
		center_index = len(verts)
		verts.append(center)

		# Triangulate
		indices = []
		n = len(verts) - 1
		for i in range(n):
			indices.append((i, (i + 1) % n, center_index))

		return verts, indices
	
	def _rotated_geometry(self, rotation):
		verts, indices = self._geometry()

		if rotation != 0.0:
			cos_a = math.cos(rotation)
			sin_a = math.sin(rotation)

			rotated = []
			for vx, vy in verts:
				dx = vx - self.x
				dy = vy - self.y

				rx = dx * cos_a - dy * sin_a
				ry = dx * sin_a + dy * cos_a

				rotated.append((self.x + rx, self.y + ry))

			verts = rotated
		
		return verts, indices

	def _draw_shape(self, color):
		shader = gpu.shader.from_builtin('UNIFORM_COLOR')
		verts, indices = self._geometry()
		batch = gpu_batch.batch_for_shader(shader, 'TRIS', {'pos': verts}, indices=indices)

		gpu.state.blend_set('ALPHA')
		shader.bind()
		shader.uniform_float('color', color)
		batch.draw(shader)
		gpu.state.blend_set('NONE')


		# shader = gpu.shader.from_builtin('UNIFORM_COLOR')
		# verts, indices = self._rotated_geometry(rotation=(math.pi/2))
		# batch = gpu_batch.batch_for_shader(shader, 'TRIS', {'pos': verts}, indices=indices)

		# gpu.state.blend_set('ALPHA')
		# shader.bind()
		# shader.uniform_float('color', color)
		# batch.draw(shader)
		# gpu.state.blend_set('NONE')

	# def _draw_outline(self, context, color, line_width):
	# 	shader = gpu.shader.from_builtin('UNIFORM_COLOR')
	# 	verts, _ = self._geometry()
	# 	batch = gpu_batch.batch_for_shader(shader, 'LINE_LOOP', {'pos': verts[:-1]})
		
	# 	gpu.state.blend_set('ALPHA')  # <— add this
	# 	gpu.state.depth_test_set('NONE')
	# 	shader.bind()
	# 	shader.uniform_float('color', color)
	# 	batch.draw(shader)
	# 	gpu.state.blend_set('NONE')
	
	def _draw_outline(self, context, color, line_width=1.0):
		shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
		verts, _ = self._geometry()
		batch = gpu_batch.batch_for_shader(shader, 'LINE_LOOP', {'pos': verts[:-1]})

		gpu.state.blend_set('ALPHA')
		# gpu.state.blend_set('NONE')
		# gpu.state.depth_test_set('NONE')
		shader.bind()
		shader.uniform_float('color', color)
		# shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
		shader.uniform_float('viewportSize', (context.area.width, context.area.height))

		shader.uniform_float('lineWidth', float(max(1.0, line_width)))

		batch.draw(shader)
		gpu.state.blend_set('NONE')


	def draw(self, context):
		self._draw_shape(self.fill_color)
		self._draw_outline(context, self.outline_color, self.line_width)

	def test_select(self, context, location):
		verts, _ = self._geometry()
		xs = [v[0] for v in verts[:-1]]
		ys = [v[1] for v in verts[:-1]]
		x, y = location
		if min(xs) <= x <= max(xs) and min(ys) <= y <= max(ys):
			return 0
		return -1


classes = (
	GIZMO_GT_line_3d,
	GIZMO_GT_square_2d,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)


def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)