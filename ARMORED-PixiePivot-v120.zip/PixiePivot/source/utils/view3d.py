import mathutils
import bpy_extras.view3d_utils


MIN_SAFE_SCALE = 1e-6


def pixel_to_world_scalar(
	context, location: mathutils.Vector, pixel_size: float, scale: float, min_scalar: float = MIN_SAFE_SCALE,
) -> float:
	'''
	Returns a world-space scalar such that a vector of that length appears as `pixel_size`
	screen pixels, with optional scale adjustment (usually ui_scale).

	Clamps to a minimum scalar to ensure the value is never zero.
	'''

	region = context.region
	rv3d = context.region_data

	screen_coord = bpy_extras.view3d_utils.location_3d_to_region_2d(
		region, rv3d, location
	)
	if screen_coord is None:
		return min_scalar  # fallback if offscreen

	adjusted_pixel_size = pixel_size * scale
	offset_coord = screen_coord + mathutils.Vector((adjusted_pixel_size, 0))

	loc_3d_offset = bpy_extras.view3d_utils.region_2d_to_location_3d(
		region, rv3d, offset_coord, location
	)
	scalar = (loc_3d_offset - location).length

	return max(min_scalar, scalar)


def get_raycast_origin_and_direction(context, event) -> tuple[mathutils.Vector, mathutils.Vector]:
	'''
	Returns two World Space vectors
	'''

	region = context.region
	rv3d = context.region_data
	coord = event.mouse_region_x, event.mouse_region_y

	ray_origin = bpy_extras.view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
	ray_direction = bpy_extras.view3d_utils.region_2d_to_vector_3d(
		region, rv3d, coord
	)

	return ray_origin, ray_direction


def get_2d_from_3d(coords: mathutils.Vector, context) -> mathutils.Vector | None:
	'''
	Convert a World 3D Vector into a Screen 2D Vector
	'''
	
	return bpy_extras.view3d_utils.location_3d_to_region_2d(
		context.region, context.region_data, coords, default=None
	)