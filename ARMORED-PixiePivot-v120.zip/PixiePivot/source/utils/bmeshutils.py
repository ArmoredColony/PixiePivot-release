import bmesh
import bmesh.ops
import mathutils
import numpy


def find_center(verts: list[bmesh.types.BMVert]) -> mathutils.Vector:
	return find_mean_center(verts)

	
def find_mean_center(verts: list[bmesh.types.BMVert]) -> mathutils.Vector:
	'''
	Returns the mean center of a list of bmesh vertices.
	'''

	count = len(verts)
	assert count > 0, 'find_mean_center requires at least one vertex'

	total = sum((v.co for v in verts), mathutils.Vector())

	return total / count


def find_mean_center_foreach(verts, buffer=None) -> mathutils.Vector:
	'''
	Mean center via foreach_get into a NumPy array.
	Assumes verts supports foreach_get('co', ...).
	'''

	vert_count = len(verts)
	assert vert_count > 0, 'find_mean_center requires at least one vertex'

	if buffer is None:
		buffer = numpy.empty(vert_count * 3, dtype=numpy.float32)

	verts.foreach_get('co', buffer)

	coords = buffer.reshape(vert_count, 3)
	# Compute mean in float64 for precision; returns shape (3,)
	mean_xyz = coords.mean(axis=0, dtype=numpy.float64)

	return mathutils.Vector(mean_xyz.tolist())


def create_single_vert_bmesh(location: mathutils.Vector = None) -> bmesh.types.BMesh:
	'''
	Return a BMesh containing a single loose vertex at `location`.
	'''

	if location is None:
		location = mathutils.Vector()

	bm = bmesh.new()
	bm.verts.new(location)
	bm.verts.ensure_lookup_table()
	
	return bm


def pivot_bounding_box_center(bm=None, objects=None):
	'''
	Return the bounding box center of selection.
	'''

	if bm:  # Edit Mode
		coords = [v.co for v in bm.verts if v.select]
	elif objects:  # Object Mode
		coords = [obj.location for obj in objects if obj.select_get()]
	else:
		return None
	if not coords:
		return None
	min_corner = mathutils.Vector((
		min(v.x for v in coords),
		min(v.y for v in coords),
		min(v.z for v in coords)
	))
	max_corner = mathutils.Vector((
		max(v.x for v in coords),
		max(v.y for v in coords),
		max(v.z for v in coords)
	))
	return (min_corner + max_corner) * 0.5


def pivot_median_point(bm=None, objects=None):
	'''
	Return the median point of selection.
	'''

	if bm:
		coords = [v.co for v in bm.verts if v.select]
	elif objects:
		coords = [obj.location for obj in objects if obj.select_get()]
	else:
		return None
	if not coords:
		return None
	return sum(coords, mathutils.Vector()) / len(coords)


def pivot_active_element(bm=None, context=None):
	'''
	Return the active element location.
	'''

	if bm:
		# Active vertex first, then edge center, then face center
		if bm.select_history.active:
			elem = bm.select_history.active
			if isinstance(elem, bmesh.types.BMVert):
				return elem.co.copy()
			elif isinstance(elem, bmesh.types.BMEdge):
				return (elem.verts[0].co + elem.verts[1].co) * 0.5
			elif isinstance(elem, bmesh.types.BMFace):
				return elem.calc_center_median()
	elif context:
		obj = context.active_object
		if obj:
			return obj.location.copy()
	return None


def pivot_cursor(context):
	'''
	Return the 3D cursor location.'''

	return context.scene.cursor.location.copy()


def pivot_individual_origins(bm=None, objects=None):
	'''
	Return a list of locations for individual origins (no single pivot).
	'''

	if bm:
		return [v.co.copy() for v in bm.verts if v.select]
	elif objects:
		return [obj.location.copy() for obj in objects if obj.select_get()]
	return []


def get_pivot_location(context, pivot_mode: str, bm=None, objects=None):
	'''
	Return the pivot location based on the current transform pivot point setting.
	'''

	# pivot_mode = context.scene.tool_settings.transform_pivot_point

	if pivot_mode == 'BOUNDING_BOX_CENTER':
		return pivot_bounding_box_center(bm=bm, objects=objects)
	elif pivot_mode == 'MEDIAN_POINT':
		return pivot_median_point(bm=bm, objects=objects)
	elif pivot_mode == 'ACTIVE_ELEMENT':
		return pivot_active_element(bm=bm, context=context)
	elif pivot_mode == 'CURSOR':
		return pivot_cursor(context)
	elif pivot_mode == 'INDIVIDUAL_ORIGINS':
		return pivot_individual_origins(bm=bm, objects=objects)
	return None
