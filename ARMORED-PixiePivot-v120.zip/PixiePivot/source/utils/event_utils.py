import bpy

from . import events
from . import datatypes
from . import debug


# ALIASES __________________________________________________

KeyBindType = datatypes.KeyBinding | datatypes.KeyBindingGroup


def simple_modifier(key: str) -> str:
	'''
	Returns a simpler (CTRL, ALT or SHIFT) string.
	- Raises with invalid modifier keys
	'''
	
	if key in {'LEFT_SHIFT', 'RIGHT_SHIFT', 'SHIFT'}: return 'SHIFT'
	if key in {'LEFT_CTRL',  'RIGHT_CTRL',  'CTRL'}:  return 'CTRL'
	if key in {'LEFT_ALT',   'RIGHT_ALT',   'ALT'}:   return 'ALT'
	# if key in {'LEFT_OSKEY', 'RIGHT_OSKEY', 'OSKEY'}: return 'OSKEY'

	raise KeyError(F'The key {key} is not a valid modifier or modifier_event')

# def explicit_modifier(key: str) -> str:
# 	expicit_modifiers = []

def current_mods_from_event(event: bpy.types.Event) -> set[str]:
	'''
	Reference event.ctrl, event.alt and event.shift and return a set of 
	simple (CTRL, ALT and SHIFT) strings for whichever are true.
	'''
	
	pressing_mods = set()
	if event.shift: pressing_mods.add('SHIFT')
	if event.ctrl:  pressing_mods.add('CTRL')
	if event.alt:   pressing_mods.add('ALT')

	return pressing_mods


def map_events_to_key_bindings(key_bindings: list[KeyBindType]) -> dict[str, KeyBindType]:
	'''
	Convert a list of key_bindings to a dict: {event_type: callable}
	- Converts numeric strings ('1', '2', '3') to their Blender event.types ('ONE', 'TWO', 'THREE').
	- Leaves alphabetic characters unchanged.
	'''
	
	return {
		events.NUMBERS.get(kb.hotkey, kb.hotkey): kb
		for kb in key_bindings
		if kb.is_valid_hotkey
	}


def map_events_to_hotkeys(key_bindings: list[KeyBindType]) -> dict[str, callable]:
	'''
	Convert a list of key_bindings to a dict: {event_type: callable}
	- Converts numeric strings ('1', '2', '3') to their Blender event.types ('ONE', 'TWO', 'THREE').
	- Leaves alphabetic characters unchanged.
	'''
	
	return {
		events.NUMBERS.get(kb.hotkey, kb.hotkey): kb.callback
		for kb in key_bindings
		if kb.is_valid_hotkey
	}


def map_events_to_modifiers(key_bindings: list[KeyBindType]) -> dict[str, callable]:
	modifier_callbacks = {}

	for kb in key_bindings:
		assert kb.modifier in ('CTRL', 'ALT', 'SHIFT', None), 'Possible Modifier Typo'

		if not kb.is_valid_modifier:
			debug.msg('Skipping Invalid Modifier')
			continue

		if kb.modifier is None or kb.callback is None:
			continue

		if kb.modifier == 'CTRL':
			modifier_callbacks['LEFT_CTRL'] = kb.callback
			modifier_callbacks['RIGHT_CTRL'] = kb.callback
			modifier_callbacks['CTRL'] = kb.callback	# Yes we use these as well so keep them

		elif kb.modifier == 'ALT':
			modifier_callbacks['LEFT_ALT'] = kb.callback
			modifier_callbacks['RIGHT_ALT'] = kb.callback
			modifier_callbacks['ALT'] = kb.callback

		elif kb.modifier == 'SHIFT':
			modifier_callbacks['LEFT_SHIFT'] = kb.callback
			modifier_callbacks['RIGHT_SHIFT'] = kb.callback
			modifier_callbacks['SHIFT'] = kb.callback
	
	return modifier_callbacks