'''
Formatting for strings and other values.
'''



def title(text: str):
	return text.replace('_', ' ').title()


def safe_title(text):
	if not isinstance(text, str):
		return text
	
	return text.replace('_', ' ').title()

