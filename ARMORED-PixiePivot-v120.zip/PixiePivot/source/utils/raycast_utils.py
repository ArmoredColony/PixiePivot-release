import bpy
import mathutils

from . import datatypes
from . import debug
from . import view3d



MAX_DISTANCE = 1e6


@debug.timed
def calc_aabb_from_bound_box(
	obj: bpy.types.Object,
	matrix: mathutils.Matrix | None = None,
) -> tuple[mathutils.Vector, mathutils.Vector]:
	'''
	Return min and max Vectors of an AABB around the OBB.
	'''

	if matrix is None:
		matrix = mathutils.Identity(4)

	coords_world = [(matrix @ mathutils.Vector(c)) for c in obj.bound_box]

	min_world = mathutils.Vector(map(min, *coords_world))
	max_world = mathutils.Vector(map(max, *coords_world))

	return min_world, max_world


def create_wireframe_box(min_co: mathutils.Vector, max_co: mathutils.Vector) -> bpy.types.Object:
	'''
	Create a wireframe box defined by two world-space corners.
	'''
	size = max_co - min_co
	center = (min_co + max_co) * 0.5

	# Add a unit cube (local bounds -1..+1, i.e. size 2)
	bpy.ops.mesh.primitive_cube_add(size=1.0, location=center)
	obj = bpy.context.active_object

	# Scale directly to match the bounding box
	obj.scale = size

	obj.display_type = 'WIRE'
	obj.show_wire = True
	return obj


@debug.timed
def scene_raycast(context, event, depsgraph=None) -> datatypes.Raycast | None:
	'''
	Return the full data or simply None if the raycast failed.
	'''

	ray_origin, ray_direction = view3d.get_raycast_origin_and_direction(context, event)
	if depsgraph is None:
		depsgraph = context.evaluated_depsgraph_get()
	
	hit, location, normal, face_index, obj, matrix = context.scene.ray_cast(
		depsgraph, ray_origin, ray_direction
	)

	if not hit:
		return None
		
	return datatypes.Raycast(co=location, face_index=face_index, obj=obj, matrix=matrix)
	

@debug.timed
def bvh_raycast(context, event, snap_target: datatypes.SnapTarget) -> datatypes.BVHRaycast | None:
	ray_origin, ray_direction = view3d.get_raycast_origin_and_direction(
		context, event
	)

	if snap_target is None:
		return None

	obj = snap_target.source.obj
	# mat = obj.matrix_world
	mat = snap_target.matrix
	bm = snap_target.get_bmesh()
	bvh = snap_target.get_bvh()

	# BVH expects Object Space coordinates.
	mat_inv = mat.inverted()
	ray_origin_local = mat_inv @ ray_origin
	ray_direction_local = mat_inv.to_3x3() @ ray_direction

	co, normal, face_index, distance = bvh.ray_cast(ray_origin_local, ray_direction_local)

	if face_index is None:
		return None

	# co_world = mat @ co
	face = bm.faces[face_index]
	face = datatypes.FaceElement(face, mat)
	co = mat @ co
	
	debug.msg('BVH Face', face)

	return datatypes.BVHRaycast(co=co, face=face, obj=obj, matrix=mat)
