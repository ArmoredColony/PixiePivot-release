from __future__ import annotations

import dataclasses
import functools
import inspect
import pprint
import time
import typing
from collections.abc import Mapping  # ✅ correct Mapping type


# -------- configuration (you can override these from your addon) --------

DEBUG_MODE: bool = True
BACKEND: str = 'rich'  # 'print' | 'pprint' | 'rich'


# best-effort import of rich; we never crash if it's missing
try:
	from rich import print as rich_print
	from rich.pretty import pprint as rich_pprint
	_HAS_RICH = True

except Exception:
	_HAS_RICH = False
	rich_print = None  # type: ignore
	rich_pprint = None  # type: ignore


# -------- backend helpers --------

def set_debug(on: bool) -> None:
	global DEBUG_MODE
	DEBUG_MODE = bool(on)


def use_backend(name: str) -> None:
	'''
	name: 'print' | 'pprint' | 'rich'
	- graceful fallback to 'print' if unavailable
	'''
	
	global BACKEND
	name = (name or 'print').lower()
	if name == 'rich' and not _HAS_RICH:
		BACKEND = 'print'
	elif name in {'print', 'pprint', 'rich'}:
		BACKEND = name
	else:
		BACKEND = 'print'


def _emit(obj: typing.Any = '') -> None:
	if obj == '':
		# explicit blank line
		if BACKEND == 'rich' and _HAS_RICH and rich_print is not None:
			rich_print()
		else:
			print()
		return

	# normal output
	if BACKEND == 'rich' and _HAS_RICH and rich_print is not None:
		rich_print(obj)
	else:
		print(obj)


def _to_str(value: typing.Any, *, width: int = 100) -> str:
	'''
	Pretty string for any value without adding tables.
	- 'pprint' backend: compact pformat
	- others: str(value)
	'''

	if BACKEND == 'pprint':
		return pprint.pformat(value, width=width, compact=True)
	return str(value)


# -------- public, minimal API --------

def msg(*args: typing.Any) -> None:
	'''
	Lightweight printf.
	- 0 args: blank line
	- 1 arg : print that
	- >1    : join with arrow
	'''

	if not DEBUG_MODE:
		return
	if not args:
		_emit('')
	elif len(args) == 1:
		_emit(_to_str(args[0]))
	else:
		_emit(' → '.join(map(str, args)))


def info(*args: typing.Any, level: int = 1) -> typing.Any:
	'''
	Log "<addon> - <caller>() at <lineno> returns" then pretty-print args.
	Returns args (pass-through).
	'''

	if len(args) == 1:
		ret = args[0]
	else:
		ret = args

	if not DEBUG_MODE:
		return ret

	stack = inspect.stack()
	if level <= len(stack):
		frame = stack[level]
		func_name = frame.function
		line_number = frame.lineno
	else:
		func_name = '<unknown>'
		line_number = '?'

	_emit(f'Pixie Pivot - {func_name}() at {line_number} returns')
	_emit(_to_str(ret))
	return ret


def dump(
	value: typing.Any,
	title: str | None = None,
	*,
	width: int = 100,
	max_items: int | None = None,
) -> None:
	'''
	Smart dumper with:
	- auto title: "<Name> (<Type>)"
	- 4-space indent for sub-items
	- aligned "key → value" columns where applicable
	- routes:
		• dataclass instance  -> fields
		• object with __dict__-> vars(obj)
		• mapping             -> items
		• sequence (not str)  -> enumerate(items)
		• other               -> plain value
	'''

	if not DEBUG_MODE:
		return

	name = _short_name(value)
	kind = type(value).__name__
	header = title or f'{name} ({kind})'

	try:
		# --- SIMPLE RICH PATH: just pretty-print recursively and bail ---
		if BACKEND == 'rich' and _HAS_RICH and rich_pprint is not None:
			rich_print(header + ':')
			# rich.pretty.pprint handles nested indentation & colors
			rich_pprint(value, expand_all=True)
			return

		# non-Rich path (print / pprint)
		_emit(header + ':')
		indent = '    '

		# dataclass instance
		if dataclasses.is_dataclass(value) and not isinstance(value, type):
			_pairs = [(f.name, getattr(value, f.name)) for f in dataclasses.fields(value)]
			_print_pairs(_pairs, indent=indent, width=width)
			return

		# object with __dict__
		if hasattr(value, '__dict__') and isinstance(getattr(value, '__dict__', None), dict):
			_print_pairs(list(vars(value).items()), indent=indent, width=width)
			return

		# mapping (dict or any Mapping)
		if isinstance(value, (dict, Mapping)):
			_print_pairs(list(value.items()), indent=indent, width=width)
			return

		# list/tuple/set (but not str/bytes)
		if isinstance(value, (list, tuple, set)):
			items = list(value)
			if max_items is not None:
				items = items[:max_items]
			idx_width = len(str(len(items) - 1)) if items else 1
			for i, v in enumerate(items):
				prefix = f'{indent}{str(i).rjust(idx_width)} → '
				_print_wrapped(prefix, v, align_to=len(prefix), width=width)
			return

		# fallback: just print the scalar/object
		_emit(indent + _to_str(value, width=width))

	finally:
		# always leave a blank line at the end
		_emit()


# -------- small helpers --------

def _short_name(value: typing.Any) -> str:
	'''
	Best-effort short name for header.
	- class instance -> value.__class__.__name__
	- mapping/list   -> same but with length tag
	'''

	t = type(value).__name__
	try:
		if isinstance(value, (list, tuple, set, dict)):
			return f'{t}[{len(value)}]'
	except Exception:
		pass
	return t


def _print_pairs(pairs: list[tuple[typing.Any, typing.Any]], *, indent: str, width: int) -> None:
	'''
	Print aligned "key → value" rows.
	- keys converted to str
	- values pretty-formatted; multiline values get aligned continuation
	'''

	if not pairs:
		_emit(indent + '(empty)')
		return

	keys = [str(k) for k, _ in pairs]
	pad = max(len(k) for k in keys)

	for (k, v), ktxt in zip(pairs, keys):
		left = f'{indent}{ktxt.ljust(pad)} → '
		_print_wrapped(left, v, align_to=len(left), width=width)


def _print_wrapped(prefix: str, value: typing.Any, *, align_to: int, width: int) -> None:
	'''
	Print a possibly multi-line value so that subsequent lines align under the value column.
	'''

	text = _to_str(value, width=width)
	if '\n' not in text:
		_emit(prefix + text)
		return

	# align subsequent lines
	cont = ' ' * align_to
	lines = text.splitlines()
	_emit(prefix + lines[0])
	for line in lines[1:]:
		_emit(cont + line)


# -------- tiny decorators you already use, wired to msg() --------

def run_check(func):
	'''
	DECORATOR: Prints that the function ran.
	'''

	@functools.wraps(func)
	def wrapper(*args, **kwargs):
		if DEBUG_MODE:
			msg(f'RUN {func.__name__} in {func.__module__}')
		return func(*args, **kwargs)
	return wrapper

def timed(_func=None, *, label: str | None = None, enabled=None):
	'''
	Time a function and print "<name> took <ms> ms".
	Usage:
	  @timed
	  @timed()
	  @timed(label='mesh_center')
	  @timed(enabled=lambda self: self.debug_timings)
	- enabled: None->use DEBUG_MODE; bool->fixed; callable(self)->dynamic per instance
	'''

	def decorator(func):
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			if enabled is None:
				on = DEBUG_MODE
			elif callable(enabled):
				self_obj = args[0] if args else None
				on = enabled(self_obj)
			else:
				on = bool(enabled)

			if not on:
				return func(*args, **kwargs)

			start = time.perf_counter()
			try:
				return func(*args, **kwargs)
			finally:
				elapsed = (time.perf_counter() - start) * 1000.0
				name = label or func.__qualname__
				msg(f' ⏱  → {name} took {round(elapsed)} ms')
		return wrapper

	if _func is None:
		return decorator
	return decorator(_func)
