import bpy
import re
import typing

# AVOID IMPORTING LOCAL MODULES (operators.py)
# KEEP THIS STANDALONE


# CONSTANTS __________________________________________________

DEBUG = False
DEFAULT_PROP_ICON = 'PIVOT_BOUNDBOX'

_reset_op_registered = False
_last_prefs_for_reset = None


# TYPE ALIASES __________________________________________________

UIColumns = tuple[bpy.types.UILayout, ...]


class _NoInstance(type):
	def __call__(cls, *args, **kwargs):
		raise TypeError(f'{cls.__name__} is a marker type and cannot be instantiated')
	

# ANNOTATON MARKERS __________________________________________________

class InternalMarker(metaclass=_NoInstance): 
	'''Will be skipped by annotation property injection.'''
	__slots__ = ()


class AddSeparator(InternalMarker): 
	'''Indicates where to insert a UILayout.separator.'''
	__slots__ = ()


class GateBase(InternalMarker):
	'''
	Base class: every gate defines a predicate(data) → bool and an action.
	Nothing else. No duplicated logical ops.
	'''

	__slots__ = ()

	predicate = staticmethod(lambda data: True)  # default: unconditional pass

	@classmethod
	def check(cls, data) -> bool:
		try:
			return bool(cls.predicate(data))
		except Exception:
			# gates must fail closed
			return False


def GateIf(*, predicate, action='draw') -> type:
	'''
	Most flexible: user supplies predicate(data) → bool directly.
	'''
	name = getattr(predicate, '__name__', 'anon')
	cls_name = f'GateIf__{name}__{action}'
	attrs = {
		'action': action,
		'predicate': staticmethod(predicate),
		'__slots__': (),
	}
	return type(cls_name, (GateBase,), attrs)


def GateIfStart(
	*,
	source: str | None = None,
	value=None,
	value_not=None,
	value_in=None,
	value_not_in=None,
	predicate=None,
	action='draw',
) -> type:
	'''
	Hybrid gate:
		- If `predicate` is supplied → use that.
		- Else → build a predicate from the simple constraint DSL.
	'''

	if predicate is None:
		def auto_pred(data):
			val = getattr(data, source, None) if source is not None else None

			# simple constraints
			if value is not None and val != value:
				return False
			if value_not is not None and val == value_not:
				return False
			if value_in is not None and val not in value_in:
				return False
			if value_not_in is not None and val in value_not_in:
				return False

			# no constraints → default behavior
			if (value is None and value_not is None
				and value_in is None and value_not_in is None):
				return bool(val) if source is not None else True

			return True

		predicate = auto_pred

	# name building (cosmetic)
	name_bits = []
	if source is not None:
		name_bits.append(f'src_{source}')
	if value is not None:
		name_bits.append(f'eq_{repr(value)}')
	if value_not is not None:
		name_bits.append(f'neq_{repr(value_not)}')
	if value_in is not None:
		name_bits.append(f'in_{len(value_in)}')
	if value_not_in is not None:
		name_bits.append(f'notin_{len(value_not_in)}')
	if predicate is not None and predicate is not auto_pred:
		name_bits.append('pred')

	name_bits.append(action)
	cls_name = f'GateIfStart__{"__".join(name_bits)}'

	attrs = {
		'action': action,
		'predicate': staticmethod(predicate),
		'__slots__': (),
	}
	return type(cls_name, (GateBase,), attrs)



class GateEnd(InternalMarker):
	__slots__ = ()



# MAIN CLASS __________________________________________________

class PropGroup:
	'''
	Group of bpy.props with extra anotations for specific iterators
	(ex: AddSeparator to add a uilayout.separator when drawing the PropGroup).
	'''

	PRETTY_NAME = None

	_registry: dict[str, type] = {}

	def __init_subclass__(cls, **kwargs) -> None:
		'''
		Automatically creates a dictionary of class_name: type(subclass) for cases
		where we can only pass class names (str) and not the actual class
		(ex: unsetting properties in a PropGroup subclass using a shared bpy.types.Operator)
		'''
		
		super().__init_subclass__(**kwargs)
		PropGroup._registry[cls.__name__] = cls
	
	@classmethod
	def get_prop_keys(cls) -> list[str]:
		'''
		Get a list of keys in each PropGroup subclass.
		'''
		
		annotations = getattr(cls, '__annotations__', {})
		props = []
		for name, ann in annotations.items():
			# If the annotation is a class and it’s an InternalMarker (or subclass), skip it
			if isinstance(ann, type) and issubclass(ann, InternalMarker):
				continue

			props.append(name)

		return props
	
	@classmethod
	def unset_props(cls, addon_prefs):
		if DEBUG:
			print(f'From: {cls.__name__}')

		for prop in cls.get_prop_keys():
			addon_prefs.property_unset(prop)

			if DEBUG:
				print('Unset Prop', prop)

	@classmethod
	def reset_props(cls, addon_prefs):
		'''
		This doesnt reset certain props like Enums.
		'''
		
		if DEBUG:
			print(f'From: {cls.__name__}')

		# RNA definition for the AddonPreferences type
		rna = type(addon_prefs).bl_rna

		for prop_name in cls.get_prop_keys():
			rna_prop = rna.properties.get(prop_name)
			if rna_prop is None:
				if DEBUG:
					print(f'Skipping unknown prop {prop_name}')
				continue

			if rna_prop.identifier == "rna_type" or rna_prop.is_readonly:
				if DEBUG:
					print(f'Skipping readonly/internal prop {prop_name}')
				continue

			try:
				if rna_prop.is_array:
					default_value = rna_prop.default_array[:]
				else:
					default_value = rna_prop.default

				if DEBUG:
					print(f'Resetting {prop_name} -> {default_value!r}')

				# This assignment triggers the update callback
				setattr(addon_prefs, prop_name, default_value)

			except Exception as exc:
				if DEBUG:
					print(f'Failed to reset {prop_name}: {exc}')
				continue


# ANNOTATION TYPE CHECKS --------------------------------------------------------------

# def _is_marker(ann) -> bool:
# 	# ann is a class in your scheme (e.g., AddSeparator)
# 	try:
# 		return isinstance(ann, type) and issubclass(ann, InternalMarker)
# 	except TypeError:
# 		return False


def _is_bpy_property(ann) -> bool:
	'''
	Return True if 'ann' looks like a Blender property factory result.
	Works for modern annotation-only style and classic assignment style.
	'''

	# The internal class name is not public API, but consistent:
	# >>> type(bpy.props.IntProperty())
	# <class 'bpy.props._PropertyDeferred'>
	return ann.__class__.__name__ == '_PropertyDeferred'


# def _is_typing_meta(ann) -> bool:
# 	'''
# 	Skip typing-only markers like ClassVar, Annotated, etc.
# 	'''

# 	orig = typing.get_origin(ann)
	
# 	return orig is not None  # e.g., ClassVar[int], Annotated[str, ...], etc.


# INJECTOR DECORATOR --------------------------------------------------------------

def inject_prop_groups(*group_classes: PropGroup):
	'''
	Accepts group classes.
	Injects only real bpy.props into the target class; skips all other annotations.
	Warns (soft) if a property name is being overridden.
	'''

	def _decorator(cls):
		annotations = dict(getattr(cls, '__annotations__', {}))

		for group_cls in group_classes:
			for prop_name, ann in getattr(group_cls, '__annotations__', {}).items():
				# Only inject real bpy props
				if not _is_bpy_property(ann):
					continue

				# Warn if overriding
				if prop_name in annotations:
					print(
						f'PROP INJECTOR [Warning] → {group_cls.__name__}.{prop_name} overrides '
						f'existing property in {cls.__name__} '
						f'({type(annotations[prop_name]).__name__})'
					)

				# Inject
				setattr(cls, prop_name, ann)
				annotations[prop_name] = ann

		cls.__annotations__ = annotations
		return cls

	return _decorator



# UILAYOUT HELPERS --------------------------------------------------------------

def boxed_description(layout, text, icon='ERROR') -> bpy.types.UILayout:
	'''
	Create a box with a label inside with the specified Text.
	'''
	
	box = layout.box()
	row = box.row(align=True)
	row.alignment = 'CENTER'
	row.label(text=text, icon=icon)
	layout.separator(factor=2)
	
	return box


def column_generator(layout: bpy.types.UILayout, count) -> UIColumns:
	'''
	Fill the layout with the specified number of columns.
	- All columns are first CENTER aligned.
	- Finnaly, first and last column are RIGHT and LEFT aligned.
	'''
	
	row = layout.row(align=True)

	columns = []
	for i in range(count):
		col = row.column(align=True)
		col.alignment = 'CENTER'
		columns.append(col)

		if i < count - 1:
			row.separator()

	columns[0].alignment = 'RIGHT'
	columns[-1].alignment = 'LEFT'

	return columns


def two_columns(layout) -> UIColumns:
	return column_generator(layout, 2)


def three_columns(layout) -> UIColumns:
	return column_generator(layout, 3)


def centered_box(layout, title=None, title_suffix=' ↓') -> bpy.types.UILayout:  # ↘
	'''
	Generate a centered box with a post separator.
	'''
	
	row = layout.row()
	row.alignment = 'CENTER'
	centered_column = row.column()

	if title:
		centered_column.label(text=f'{title}{title_suffix}')
	
	box = centered_column.box()
	centered_column.separator(factor=3)

	return box


def prop_box(layout, *, title=None, title_suffix=' ↓', use_icons=False):
	'''
	A box filled with multiple columns (side-by-side) to be filled with FakeRow instances.
	'''

	box = centered_box(layout, title, title_suffix)
	count = 3 if use_icons else 2

	return column_generator(box, count)


class FakeRow:
	'''
	Creates one UILayout row in each provided column and forwards
	common row attributes to all of them.
	'''

	def __init__(self, columns, align=True) -> None:
		if len(columns) not in (2, 3):
			raise ValueError('FakeRow supports exactly 2 or 3 columns.')
		
		self.rows = [
			col.row(align=align) 
			for col in columns
		]

		# Align the same way you do the columns
		self.rows[0].alignment = 'RIGHT'
		if len(self.rows) == 3:
			self.rows[1].alignment = 'CENTER'
		self.rows[-1].alignment = 'LEFT'

	@classmethod
	def build(cls, addon_prefs, columns, prop_name, *,
		label='', 
		icon=DEFAULT_PROP_ICON,
		minus_suffix=None, 
		gate_fn=None):

		fake_row = cls(columns)

		if gate_fn:
			gate_fn(fake_row)

		fake_row.fill(
			addon_prefs,
			prop_name,
			label=label,
			icon=icon,
			minus_suffix=minus_suffix,
		)

		return fake_row

	def fill(
		self,
		addon_prefs: bpy.types.AddonPreferences,
		prop_name: str,
		*,
		label: str = '',
		icon: str = DEFAULT_PROP_ICON,
		minus_suffix: str | typing.Iterable[str] | None = None
	) -> None:
		'''
		Draw (Label, Icon, Property) into this row.
		'''

		prop_val = getattr(addon_prefs, prop_name)
		is_bool  = isinstance(prop_val, bool)

		if is_bool:
			prop_text = f'{str(prop_val)} ' if prop_val else str(prop_val)
		else:
			prop_text = ''

		if not label:
			rna_name = type(addon_prefs).bl_rna.properties[prop_name].name

			if rna_name:
				label = rna_name.replace('_', ' ').title()
			else:
				base  = _strip_suffix(prop_name, minus_suffix)
				label = base.replace('_', ' ').title()

		self.label(text=label)
		self.icon(icon=icon)
		self.prop(addon_prefs, prop_name, text=prop_text, toggle=is_bool)


	# MAIN PROPERTIES __________________________________________________

	def label(self, *args, **kwargs) -> None:
		self.rows[0].label(*args, **kwargs)

	def icon(self, *args, **kwargs) -> None:
		if len(self.rows) != 3:
			# No need to raise, just skip setting it so it's empty.
			return
		
		self.rows[1].label(*args, **kwargs)

	def prop(self, *args, **kwargs) -> None:
		self.rows[-1].prop(*args, **kwargs)


	# FORWARD OTHER COMMON PROPERTIES __________________________________________________

	@property
	def enabled(self) -> bool:
		return self.rows[0].enabled if self.rows else True
	
	@enabled.setter
	def enabled(self, val: bool) -> None:
		self._apply('enabled', val)

	@property
	def active(self) -> bool:
		return self.rows[0].active if self.rows else True
	@active.setter
	def active(self, val: bool) -> None:
		self._apply('active', val)

	@property
	def alert(self) -> bool:
		return self.rows[0].alert if self.rows else False
	@alert.setter
	def alert(self, val: bool) -> None:
		self._apply('alert', val)


	def _apply(self, attr: str, val) -> None:
		'''
		Iterate over the list of rows to apply an attribute value.
		'''
		
		if not self.rows:
			return
		
		if not hasattr(self.rows[0], attr):
			raise AttributeError(f'UILayout rows do not have attribute {attr!r}')
		
		for row in self.rows:
			setattr(row, attr, val)
	

def _strip_suffix(name: str, minus_suffix: str | typing.Iterable[str] | None) -> str:
	'''
	Remove the specified suffix(s) (when found) and return the potentially modified string.
	Example:
		minus_suffix = '_color'
		axis_x_color → axis_x
		axis_y_color → axis_y
		axis_z_color → axis_z
	'''
	
	if not minus_suffix:
		return name
	
	if isinstance(minus_suffix, str):
		suffixes = (minus_suffix,)
	else:
		suffixes = tuple(minus_suffix)

	for sfx in suffixes:
		if sfx and name.endswith(sfx):
			return name[: -len(sfx)]
		
	return name


def draw_prop_group(
	addon_prefs: bpy.types.AddonPreferences,
	layout: bpy.types.UILayout,
	prop_group: PropGroup,
	*,
	minus_suffix: str = None,
	use_icons=False,
) -> bpy.types.UILayout:

	def split_camel(name: str) -> str:
		return re.sub(r'(?<!^)(?=[A-Z])', ' ', name)

	icons = getattr(prop_group, 'ICONS', {})

	# --- Use the public helper ---
	columns = prop_box(
		layout,
		title=prop_group.PRETTY_NAME or split_camel(prop_group.__name__),
		use_icons=use_icons,
	)

	# ---- Gate state ----
	gate_active   = False
	gate_action   = None
	gate_condition = False

	def gate_allows_draw() -> bool:
		# Only "draw" gates suppress drawing. Other actions don't skip drawing.
		return not (gate_active and gate_action == 'draw' and not gate_condition)

	def apply_gate_state(row_like) -> None:
		'''
		Apply non-draw gate actions to a row-like object (FakeRow or UILayout row).
		'''
		if not gate_active:
			return

		gate_condition_bool = bool(gate_condition)
		current_action = gate_action

		if current_action == 'draw':
			return  # handled by gate_allows_draw()

		elif current_action == 'enable':
			row_like.enabled = gate_condition_bool

		elif current_action == 'activate':
			row_like.active = gate_condition_bool

		elif current_action == 'disable':
			row_like.enabled = not gate_condition_bool

		elif current_action == 'deactivate':
			row_like.active = not gate_condition_bool

		elif current_action == 'disable_and_alert':
			row_like.enabled = not gate_condition_bool
			row_like.alert = gate_condition_bool

		elif current_action == 'deactivate_and_alert':
			row_like.active = not gate_condition_bool
			row_like.alert = gate_condition_bool

		else:
			raise ValueError(f'Invalid gate action: {current_action!r}')

	def multi_separator(items: list[bpy.types.UILayout]) -> None:
		for item in items:
			item.separator()

	def reset_button(layout, group_cls: PropGroup, title=None) -> None:
		global _last_prefs_for_reset

		if not _reset_op_registered:
			return

		_last_prefs_for_reset = addon_prefs

		title = title or 'Reset Group'
		operator_button = layout.operator(PROP_UTILS_OT_reset_prop_group.bl_idname, text=title)
		operator_button.group = group_cls.__name__

	# ---- Draw loop ----
	for prop_name, ann in getattr(prop_group, '__annotations__', {}).items():

		# Internal markers (gates, separators, etc.)
		if isinstance(ann, type) and issubclass(ann, InternalMarker):

			if issubclass(ann, GateBase):
				gate_active = True
				gate_action = getattr(ann, 'action', 'draw')
				gate_condition = ann.check(addon_prefs)
				continue

			if ann is GateEnd:
				gate_active = False
				gate_action = None
				gate_condition = False
				continue

			if ann is AddSeparator:
				# Respect draw-gates for markers too
				if gate_allows_draw():
					multi_separator(columns)
				continue

			# Unknown marker: ignore
			continue

		# Normal properties
		if not gate_allows_draw():
			continue
		
		FakeRow.build(
			addon_prefs,
			columns,
			prop_name,
			icon=icons.get(prop_name, DEFAULT_PROP_ICON),
			minus_suffix=minus_suffix,
			gate_fn=apply_gate_state,
		)

	# End-of-group separator (always)
	multi_separator(columns)
	reset_button(columns[-1], prop_group)



# OPERATORS __________________________________________________

def _sanitize_prefix(raw: str) -> str:
	'''
	Make a safe operator prefix from a package/module id.
	'''

	raw = (raw or 'addon').lower()
	raw = re.sub(r'[^a-z0-9_]+', '_', raw)	# replace dots/spaces/etc
	raw = re.sub(r'_+', '_', raw).strip('_')

	if not raw or not raw[0].isalpha():
		raw = f'addon_{raw}' if raw else 'addon'

	return raw


class PROP_UTILS_OT_reset_prop_group(bpy.types.Operator):
	'''
	Static operator so Blender reliably registers RNA props.
	'''

	bl_idname = 'prop_utils.reset_prop_group'
	bl_label = 'Reset Prop Group'
	bl_description = 'Reset all properties in the selected group to their default values'
	bl_options = {'INTERNAL'}

	group: bpy.props.StringProperty(name='Group', options={'SKIP_SAVE'})

	def execute(self, context):
		global _last_prefs_for_reset

		addon_prefs = _last_prefs_for_reset
		if addon_prefs is None:
			self.report({'ERROR'}, 'Reset operator has no preferences context.')

			return {'CANCELLED'}

		group_cls = PropGroup._registry.get(self.group)
		if group_cls is None:
			self.report({'ERROR'}, f'Unknown group: {self.group}')

			return {'CANCELLED'}

		# group_cls.reset_props(addon_prefs)
		group_cls.unset_props(addon_prefs)

		return {'FINISHED'}


def register_reset_operator_with_id(raw_id: str):
	'''
	Register reset operator using a raw addon/extension id string.
	Auto-register path (no bpy.context needed).
	'''

	global _reset_op_registered

	prefix = _sanitize_prefix(raw_id)
	PROP_UTILS_OT_reset_prop_group.bl_idname = f'{prefix}.reset_prop_group'

	# If an old copy is registered in this module, unregister it first.
	old_cls = getattr(bpy.types, PROP_UTILS_OT_reset_prop_group.__name__, None)
	if old_cls is not None:
		try:
			bpy.utils.unregister_class(old_cls)
		except Exception:
			pass

	try:
		bpy.utils.register_class(PROP_UTILS_OT_reset_prop_group)
		_reset_op_registered = True

	except RuntimeError as e:
		_reset_op_registered = False
		print('prop_utils: failed to register reset operator:', e)


def unregister_reset_operator():
	'''
	Unregister reset operator.
	'''

	global _reset_op_registered

	if not _reset_op_registered:
		return

	try:
		bpy.utils.unregister_class(PROP_UTILS_OT_reset_prop_group)
	except Exception:
		pass

	_reset_op_registered = False


def register() -> None:
	# __package__ works for both addons and extensions.
	# If it's None for weird cases, fall back to __name__.
	register_reset_operator_with_id(__package__ or __name__)


def unregister() -> None:
	unregister_reset_operator()