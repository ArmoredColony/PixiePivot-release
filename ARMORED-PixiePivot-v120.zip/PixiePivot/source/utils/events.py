'''
Event Types that trigger specific actions while the modal operator runs.
Modal Keys and Modifiers are extracted from addon_prefs and defined during invoke()
'''


MODE_SWITCH = {
	'ONE', 
	'TWO', 
	'THREE', 
	'NUMPAD_0', 
	'NUMPAD_1', 
	'NUMPAD_2',
}


PASSTHROUGH = {
	'MIDDLEMOUSE',
	'WHEELUPMOUSE',
	'WHEELDOWNMOUSE',
	'NUMPAD_PERIOD',
	'NUMPAD_5',
	'HOME',
	'A',
	'F',
	'SLASH',
}


MODIFIER_KEYS = {
	'LEFT_SHIFT',
	'RIGHT_SHIFT',
	'LEFT_CTRL',
	'RIGHT_CTRL',
	'LEFT_ALT',
	'RIGHT_ALT',
}


CANCEL = {
	'RIGHTMOUSE',
	'ESC',
	'TAB',
	'F5',
}


FINISH = {
	'RET',
	'SPACE',
	'NUMPAD_ENTER',
}


GROW_PIVOT = {
	'PLUS',
	'NUMPAD_PLUS',
	'RIGHT_BRACKET',
}


SHRINK_PIVOT = {
	'MINUS',
	'NUMPAD_MINUS',
	'LEFT_BRACKET',
}


RESET_PIVOT_SIZE = {
	'NUMPAD_ASTERIX',
	'QUOTE',
}


SCALE_PIVOT = GROW_PIVOT | SHRINK_PIVOT


NUMBERS = {
	'0': 'ZERO',
	'1': 'ONE',
	'2': 'TWO',
	'3': 'THREE',
	'4': 'FOUR',
	'5': 'FIVE',
	'6': 'SIX',
	'7': 'SEVEN',
	'8': 'EIGHT',
	'9': 'NINE',
}