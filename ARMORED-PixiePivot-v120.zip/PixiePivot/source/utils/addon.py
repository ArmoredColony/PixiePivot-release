import bpy
import pathlib
import importlib.resources


def get_extension_package() -> str:
	'''
	Return root extension package:
	'bl_ext.Extensions.PixiePivot'
	'''

	return '.'.join(__package__.split('.')[:3])


def get_extension_id() -> str:
	'''
	Return extension ID:
	'PixiePivot'
	'''

	return __package__.split('.')[2]


def get_extension():
	return bpy.context.preferences.addons[get_extension_package()]


def get_preferences():
	return get_extension().preferences


def get_path() -> pathlib.Path:
	'''
	Return the top-level extension folder (PixiePivot).
	'''

	return pathlib.Path(importlib.resources.files(get_extension_package()))


def get_resources_path() -> pathlib.Path:
	'''
	Return the resources folder inside the extension.
	'''

	return get_path() / 'source' / 'resources'