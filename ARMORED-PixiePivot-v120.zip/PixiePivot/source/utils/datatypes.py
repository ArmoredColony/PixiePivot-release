import bpy
import bmesh
import bmesh.ops
import dataclasses
import numpy
import mathutils
import typing

from . import addon
from . import debug
from . import pretty

from ..runtime_state import runtime_state


# CONSTANTS __________________________________________________

MIN_SAFE_SCALE = 1e-6


class AxisFields(typing.NamedTuple):
	'''
	Basic container.
	'''
	
	x: float
	y: float
	z: float


class ModalPreferences:
	'''
	A container of addon preferences that are relevant to the modal operator,
	with properties defined during invoke() and a custom `field_names` to track them.
	'''

	def __init__(self, **kwargs):
		self.attr_names = []  # track any attributes set
		for key, value in kwargs.items():
			setattr(self, key, value)
			self.attr_names.append(key)
	

class ElementInterface(typing.Protocol):
	'''
	Interface for bmesh/mesh element proxies.
	Implementers must provide `.raw`, `.co`, `.world_co`, `.normal`.
	'''

	# underlying element (BM* or Mesh*)
	raw: (
		bmesh.types.BMVert
		| bmesh.types.BMEdge
		| bmesh.types.BMFace
		| bpy.types.MeshVertex
		| bpy.types.MeshEdge
		| bpy.types.MeshPolygon
	)

	@property
	def co(self) -> mathutils.Vector:
		...

	@property
	def normal(self) -> mathutils.Vector:
		...

	@property
	def world_co(self) -> mathutils.Vector:
		...

	@property
	def world_normal(self) -> mathutils.Vector:
		...


class ElementBase:
	'''
	Base for Element abstraction.
	'''

	def __init__(self, raw, matrix):
		self.raw = raw

		# Not necesarily an object's matrix, but the space we are working in.
		# eg. a AABB around multiple objects → Identity matrix
		self.matrix = matrix
	
	@property
	def world_co(self) -> mathutils.Vector:
		return self.matrix @ self.co
	
	@property
	def world_normal(self) -> mathutils.Vector:
		M = self.matrix.to_3x3()
		return (M @ self.normal).normalized()	


class VertElement(ElementBase):

	@property
	def co(self) -> mathutils.Vector:
		'''
		Local-space coordinate.
		Works for both BMVert and MeshVertex.
		'''

		return self.raw.co.copy()

	@property
	def normal(self) -> mathutils.Vector:
		'''
		Local-space normal.
		Handles both BMVert and MeshVertex.
		'''

		raw = self.raw

		if isinstance(raw, bmesh.types.BMVert):
			return raw.normal.copy()

		if isinstance(raw, bpy.types.MeshVertex):
			return raw.normal.copy()

		raise TypeError(f'Unsupported vertex raw type: {type(raw)}')


	# DEBUG __________________________________________________

	def __repr__(self):
		return f'<VertElement co={tuple(self.co)}>'



class EdgeElement(ElementBase):

	@property
	def co(self) -> mathutils.Vector:
		raw = self.raw

		# BMesh
		if isinstance(raw, bmesh.types.BMEdge):
			v1, v2 = raw.verts
			return (v1.co + v2.co) * 0.5

		# Mesh
		elif isinstance(raw, bpy.types.MeshEdge):
			mesh = raw.id_data
			v1 = mesh.vertices[raw.vertices[0]].co
			v2 = mesh.vertices[raw.vertices[1]].co
			return (v1 + v2) * 0.5

		raise TypeError(f'Unsupported edge type: {type(raw)}')

	@property
	def normal(self) -> mathutils.Vector:
		raw = self.raw

		# BMesh path (edit mode)
		if isinstance(raw, bmesh.types.BMEdge):
			if raw.link_faces:
				n = mathutils.Vector()
				for f in raw.link_faces:
					n += f.normal
				return n.normalized()
			return self._direction_from_bmesh(raw).orthogonal()

		# Mesh path (object mode)
		elif isinstance(raw, bpy.types.MeshEdge):
			mesh = raw.id_data
			v1, v2 = mesh.vertices[raw.vertices[0]], mesh.vertices[raw.vertices[1]]

			# Use vertex normals to approximate edge normal
			n = v1.normal + v2.normal
			if n.length_squared > 0:
				return n.normalized()

			# Fallback: orthogonal to edge direction
			return self._direction_from_mesh(raw).orthogonal()

		raise TypeError(f'Unsupported edge type: {type(raw)}')


	@property
	def verts(self) -> list["VertElement"]:
		raw = self.raw

		# BMesh
		if isinstance(raw, bmesh.types.BMEdge):
			return [
				VertElement(v, self.matrix)
				for v in raw.verts
			]

		# Mesh
		elif isinstance(raw, bpy.types.MeshEdge):
			mesh = raw.id_data
			return [
				VertElement(mesh.vertices[i], self.matrix)
				for i in raw.vertices
			]

		raise TypeError(f'Unsupported edge type: {type(raw)}')


	# HELPERS __________________________________________________

	def _direction_from_bmesh(self, edge: bmesh.types.BMEdge):
		v1, v2 = edge.verts
		return (v2.co - v1.co).normalized()

	def _direction_from_mesh(self, edge: bpy.types.MeshEdge):
		mesh = edge.id_data
		v1 = mesh.vertices[edge.vertices[0]].co
		v2 = mesh.vertices[edge.vertices[1]].co
		return (v2 - v1).normalized()


	# DEBUG __________________________________________________

	def __repr__(self):
		return f"<EdgeElement index={getattr(self.raw, 'index', '?')}>"
	

class FaceElement(ElementBase):

	@property
	def co(self) -> mathutils.Vector:
		raw = self.raw

		# BMesh
		if isinstance(raw, bmesh.types.BMFace):
			acc = mathutils.Vector()
			for v in raw.verts:
				acc += v.co
			return acc / len(raw.verts)

		# Mesh
		elif isinstance(raw, bpy.types.MeshPolygon):
			mesh = raw.id_data
			acc = mathutils.Vector()
			for idx in raw.vertices:
				acc += mesh.vertices[idx].co
			return acc / len(raw.vertices)

		raise TypeError(f'Unsupported face type: {type(raw)}')

	@property
	def normal(self) -> mathutils.Vector:
		raw = self.raw

		if isinstance(raw, bmesh.types.BMFace):
			return raw.normal.copy()

		elif isinstance(raw, bpy.types.MeshPolygon):
			return raw.normal.copy()

		raise TypeError(f'Unsupported face type: {type(raw)}')

	@property
	def verts(self) -> list["VertElement"]:
		raw = self.raw

		if isinstance(raw, bmesh.types.BMFace):
			return [VertElement(v, self.matrix) for v in raw.verts]

		elif isinstance(raw, bpy.types.MeshPolygon):
			mesh = raw.id_data
			return [
				VertElement(mesh.vertices[i], self.matrix)
				for i in raw.vertices
			]

		raise TypeError(f'Unsupported face type: {type(raw)}')

	@property
	def edges(self) -> list["EdgeElement"]:
		raw = self.raw

		if isinstance(raw, bmesh.types.BMFace):
			return [EdgeElement(e, self.matrix) for e in raw.edges]

		elif isinstance(raw, bpy.types.MeshPolygon):
			mesh = raw.id_data

			start = raw.loop_start
			end = start + raw.loop_total

			return [
				EdgeElement(mesh.edges[mesh.loops[i].edge_index], self.matrix)
				for i in range(start, end)
			]

		raise TypeError(f'Unsupported face type: {type(raw)}')


	# DEBUG __________________________________________________

	def __repr__(self):
		return f"<FaceElement verts={len(self.verts)}>"


class CenterAsVertElement(VertElement):
	'''
	A virtual vertex representing the BMesh center.
	Holds a BMesh reference to keep it alive.
	'''

	def __init__(self, bm, raw, matrix):
		super().__init__(raw, matrix)
		self.bm = bm


# RAYCAST DATA __________________________________________________

@dataclasses.dataclass(slots=True)
class Raycast:
	'''
	Pure raycast result container.
	'''

	obj:    bpy.types.Object | None = None
	co:     mathutils.Vector | None = None
	matrix: mathutils.Matrix | None = None
	
	face_index: int | None = None
	# face:   bmesh.types.BMFace | bpy.types.MeshPolygon | None = None


class BVHRaycast(typing.NamedTuple):
	'''
	BVH Raycast Container.
	'''

	co:     mathutils.Vector | None
	face:   bmesh.types.BMFace | None
	obj:    bpy.types.Object | None
	matrix: mathutils.Matrix | None


# GEOMETRY SOURCES __________________________________________________

class GeometrySource(typing.Protocol):
	'''
	Abstract source of raw geometry data.
	Does NOT build bmesh, BVH, or bounding boxes.
	'''
	
	@property
	def object_count(self):
		...

	def iter_objects(self):
		...

	def iter_world_vertices(self):
		'''
		Yield world-space vertices across all objects.
		'''

		...


class SingleObjectSource:

	def __init__(self, obj: bpy.types.Object):
		self.obj = obj
		self._vert_buffer = None

	@property
	def matrix(self):
		return self.obj.matrix_world

	@property
	def object_count(self):
		return 1

	def iter_objects(self):
		yield self.obj

	def iter_local_vertices(self):
		mesh = self.obj.data
		for v in mesh.vertices:
			yield mathutils.Vector(v.co)

	def iter_world_vertices(self):
		mesh = self.obj.data
		vert_count = len(mesh.vertices)
		if vert_count == 0:
			return

		# Buffer reuse
		float_count = vert_count * 3
		if self._vert_buffer is None or self._vert_buffer.size < float_count:
			self._vert_buffer = numpy.empty(float_count, dtype=numpy.float32)

		mesh.vertices.foreach_get('co', self._vert_buffer)
		arr = self._vert_buffer.reshape(vert_count, 3)

		m = self.obj.matrix_world.to_3x3()
		t = self.obj.matrix_world.translation

		transformed = arr @ numpy.array(m)
		for co in transformed:
			yield mathutils.Vector(co) + t


class MultiObjectSource(GeometrySource):

	def __init__(self, objects: list[bpy.types.Object]):
		self.objects = objects
		self._sources = [SingleObjectSource(o) for o in objects]

	@property
	def matrix(self):
		return mathutils.Matrix.Identity(4)

	@property
	def object_count(self):
		return len(self.objects)
	
	def iter_objects(self):
		yield from self.objects

	def iter_world_vertices(self):
		for src in self._sources:
			yield from src.iter_world_vertices()


# IM NOT ENFORCING THIS STRUCTURE FOR NOW BECAUSE BBOX REPRESENTATIONS
# MIGHT SWITCH FROM BVH RAYCASTING TO SOMETHING ELSE
class Representation:
	def get_bmesh(self, strategy=None):
		raise NotImplementedError

	def get_bvh(self, strategy=None):
		raise NotImplementedError
		
	@property
	def matrix(self):
		raise NotImplementedError


class MeshRepresentation:
	'''
	Per-object mesh geometry with caching.
	Assumes source yields exactly one object.
	'''

	def __init__(self, source: SingleObjectSource):
		self.source = source
		self._cache = {}  # cache for bmesh and bvh	
	
	@property
	def matrix(self):
		# Should be the same as obj.matrix_world
		return self.source.matrix

	def get_bmesh(self):
		'''
		Returns the cached BMesh for the object.
		If the object is in OBJECT mode, uses evaluated BMesh.
		If in EDIT mode, uses edit mesh BMesh.
		'''
		
		if 'bmesh' not in self._cache:
			obj = next(self.source.iter_objects())

			if obj.mode == 'OBJECT':
				bm = bmesh.new()
				depsgraph = bpy.context.evaluated_depsgraph_get()
				obj_eval = obj.evaluated_get(depsgraph)
				bm.from_object(obj_eval, depsgraph)
			else:
				bm = bmesh.from_edit_mesh(obj.data)

			bm.faces.ensure_lookup_table()
			self._cache['bmesh'] = bm

		return self._cache['bmesh']

	def get_bvh(self):
		'''
		Returns the cached BVHTree for the object's BMesh.
		Always built from whatever BMesh get_bmesh() returns.
		'''

		if 'bvh' not in self._cache:
			self._cache['bvh'] = mathutils.bvhtree.BVHTree.FromBMesh(self.get_bmesh())

		return self._cache['bvh']

	def clear_cache(self):
		'''
		Frees BMesh objects and clears cache.
		'''

		if 'bmesh' in self._cache:
			self._cache['bmesh'].free()

		self._cache.clear()


def build_bbox_bmesh(corners):
	'''
	Build cube BMesh from 8 corners.
	'''

	faces = [
		(0, 1, 2, 3),
		(7, 6, 5, 4),
		(4, 5, 1, 0),
		(5, 6, 2, 1),
		(6, 7, 3, 2),
		(7, 4, 0, 3),
	]

	bm = bmesh.new()
	verts = [bm.verts.new(c) for c in corners]
	bm.verts.ensure_lookup_table()

	for idx in faces:
		bm.faces.new([verts[i] for i in idx])

	bm.faces.ensure_lookup_table()
	
	return bm

	
	# THIS BUILDS EDGES ONLY, NO FACES. WE CANT BVH RAYCAST ONTO IT
	# bm = bmesh.new()

	# # Create verts
	# verts = [bm.verts.new(corner) for corner in corners]
	# bm.verts.ensure_lookup_table()

	# # Edge index pairs for a box
	# edges = [
	# 	(0, 1), (1, 2), (2, 3), (3, 0),  # bottom
	# 	(4, 5), (5, 6), (6, 7), (7, 4),  # top
	# 	(0, 4), (1, 5), (2, 6), (3, 7),  # vertical
	# ]

	# for i1, i2 in edges:
	# 	bm.edges.new((verts[i1], verts[i2]))

	# bm.edges.ensure_lookup_table()

	# return bm


class BBoxRepresentation:

	def __init__(self, source):
		self.source = source
		self._cache = {}

		self._strategies = {
			'local_accurate':  LocalBoundingBox.accurate,
			'local_fast':      LocalBoundingBox.fast,
			'global_accurate': GlobalBoundingBox.accurate,
			'global_fast':     GlobalBoundingBox.fast,
		}

	@property
	def matrix(self):
		strategy = self.active_strategy

		# Local bbox lives in object space
		if strategy in {'local_accurate', 'local_fast'}:
			return self.source.matrix

		# Global strategies are already in world space
		if strategy in {'global_accurate', 'global_fast'}:
			return mathutils.Matrix.Identity(4)

		raise ValueError(f'{strategy} is not a valid BBox Representation Strategy')
	

	def get_bmesh(self, strategy=None):
		'''
		Returns the BMesh for the given strategy.
		Strategy is based on prefs and object count.
		'''

		if strategy is None:
			strategy = self.active_strategy

		if strategy not in self._strategies:
			raise ValueError(f'Unknown BBox strategy: {strategy}')

		if strategy not in self._cache:
			strategy_func = self._strategies[strategy]

			# Call function directly
			corners = strategy_func(self.source)
			self._cache[strategy] = build_bbox_bmesh(corners)

		return self._cache[strategy]

	def get_bvh(self):
		return mathutils.bvhtree.BVHTree.FromBMesh(self.get_bmesh())

	def clear_cache(self):
		self._cache.clear()

	@property
	def active_strategy(self):
		'''
		Controls which strategies to use.
		'''
		
		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences

		if self.source.object_count > 1:
			return 'global_fast'
		
		if addon_prefs.bounds_calculator == 'FAST':
			return 'global_fast' if modal_prefs.use_global_orientation else 'local_fast'
		
		return 'global_accurate' if modal_prefs.use_global_orientation else 'local_accurate'


class LocalBoundingBox:

	@staticmethod
	def fast(source: 'SingleObjectSource'):
		'''
		Fast local bounding box.
		Uses Blender's built-in bound_box data.
		'''

		obj = source.obj
		
		if obj.mode == 'OBJECT':
			pass
			# DOES NOT WORK ANYWAY `bound_box` DOES NOT SEEM TO CARE ABOUT EVALUATED OBJS
			# depsgraph = bpy.context.evaluated_depsgraph_get()
			# obj = obj.evaluated_get(depsgraph)
		else:
			obj.update_from_editmode()

		# Local object-oriented bbox
		return [mathutils.Vector(c) for c in obj.bound_box]


	@staticmethod
	def accurate(source: 'GeometrySource'):
		'''
		Accurate local bounding box.
		Iterates vertices and computes min/max in local space.
		'''

		local_verts = []

		for obj in source.iter_objects():

			# If we're in object mode, use evaluated object to get modifiers
			if obj.mode == 'OBJECT':
				depsgraph = bpy.context.evaluated_depsgraph_get()
				obj_eval = obj.evaluated_get(depsgraph)
				mesh = obj_eval.data
			else:
				# EDIT mode or other, use base mesh
				obj.update_from_editmode()
				mesh = obj.data

			vert_count = len(mesh.vertices)
			if vert_count == 0:
				continue

			# Reuse source buffer if it exists
			if not hasattr(source, '_vert_buffer') or source._vert_buffer is None or source._vert_buffer.size < vert_count * 3:
				source._vert_buffer = numpy.empty(vert_count * 3, dtype=numpy.float32)
			buf = source._vert_buffer

			mesh.vertices.foreach_get('co', buf)
			arr = buf.reshape(vert_count, 3)

			# No world transformation: local object coordinates only
			for i in range(vert_count):
				local_verts.append(mathutils.Vector(arr[i]))

		if not local_verts:
			v = mathutils.Vector((0, 0, 0))
			return [v] * 8

		# Compute local min/max
		xs = [v.x for v in local_verts]
		ys = [v.y for v in local_verts]
		zs = [v.z for v in local_verts]

		local_min = mathutils.Vector((min(xs), min(ys), min(zs)))
		local_max = mathutils.Vector((max(xs), max(ys), max(zs)))

		corners = [
			mathutils.Vector((local_min.x, local_min.y, local_min.z)),
			mathutils.Vector((local_min.x, local_min.y, local_max.z)),
			mathutils.Vector((local_min.x, local_max.y, local_max.z)),
			mathutils.Vector((local_min.x, local_max.y, local_min.z)),
			mathutils.Vector((local_max.x, local_min.y, local_min.z)),
			mathutils.Vector((local_max.x, local_min.y, local_max.z)),
			mathutils.Vector((local_max.x, local_max.y, local_max.z)),
			mathutils.Vector((local_max.x, local_max.y, local_min.z)),
		]

		return corners


class GlobalBoundingBox:

	@staticmethod
	def accurate(source: 'GeometrySource'):
		'''
		Accurate global bounding box.
		Iterates vertices and computes world-space min/max.
		'''

		# I DO NOT THINK THIS WILL WORK FOR MULTI OBJECTS
		# But it seems to work for single objects.

		world_verts = []

		for obj in source.iter_objects():

			if obj.mode == 'OBJECT':
				depsgraph = bpy.context.evaluated_depsgraph_get()
				obj = obj.evaluated_get(depsgraph)

			mesh = obj.data

			vert_count = len(mesh.vertices)
			if vert_count == 0:
				continue

			# Reuse source buffer if it exists
			if not hasattr(source, '_vert_buffer') or source._vert_buffer is None or source._vert_buffer.size < vert_count * 3:
				source._vert_buffer = numpy.empty(vert_count * 3, dtype=numpy.float32)
			buf = source._vert_buffer

			mesh.vertices.foreach_get('co', buf)
			arr = buf.reshape(vert_count, 3)

			# Convert to world space
			m = obj.matrix_world
			r0 = numpy.array((m[0][0], m[0][1], m[0][2]), dtype=numpy.float32)
			r1 = numpy.array((m[1][0], m[1][1], m[1][2]), dtype=numpy.float32)
			r2 = numpy.array((m[2][0], m[2][1], m[2][2]), dtype=numpy.float32)
			p0 = arr @ r0
			p1 = arr @ r1
			p2 = arr @ r2

			tx, ty, tz = m[0][3], m[1][3], m[2][3]

			for i in range(vert_count):
				world_verts.append(mathutils.Vector((p0[i] + tx, p1[i] + ty, p2[i] + tz)))

		if not world_verts:
			v = mathutils.Vector((0, 0, 0))
			return [v] * 8

		# Compute global min/max
		xs = [v.x for v in world_verts]
		ys = [v.y for v in world_verts]
		zs = [v.z for v in world_verts]

		wmin = mathutils.Vector((min(xs), min(ys), min(zs)))
		wmax = mathutils.Vector((max(xs), max(ys), max(zs)))

		corners = [
			mathutils.Vector((wmin.x, wmin.y, wmin.z)),
			mathutils.Vector((wmin.x, wmin.y, wmax.z)),
			mathutils.Vector((wmin.x, wmax.y, wmax.z)),
			mathutils.Vector((wmin.x, wmax.y, wmin.z)),
			mathutils.Vector((wmax.x, wmin.y, wmin.z)),
			mathutils.Vector((wmax.x, wmin.y, wmax.z)),
			mathutils.Vector((wmax.x, wmax.y, wmax.z)),
			mathutils.Vector((wmax.x, wmax.y, wmin.z)),
		]

		return corners


	@staticmethod
	def fast(source: 'GeometrySource'):
		'''
		Fast global bounding box.
		Merges object bound_box corners in world space.
		'''

		# collect all world-space bounding box points
		world_coords = []
		for obj in source.iter_objects():
			bounding_box = getattr(obj, 'bound_box', None)
			if not bounding_box:
				continue

			M = obj.matrix_world
			for corner in bounding_box:
				world_point = M @ mathutils.Vector(corner)
				world_coords.append(world_point)

		if not world_coords:
			zero_vector = mathutils.Vector((0.0, 0.0, 0.0))
			return [zero_vector] * 8

		world_min = mathutils.Vector(map(min, *world_coords))
		world_max = mathutils.Vector(map(max, *world_coords))

		# reconstruct 8 corners of the global bounding box
		return [
			mathutils.Vector((world_min.x, world_min.y, world_min.z)),
			mathutils.Vector((world_min.x, world_min.y, world_max.z)),
			mathutils.Vector((world_min.x, world_max.y, world_max.z)),
			mathutils.Vector((world_min.x, world_max.y, world_min.z)),
			mathutils.Vector((world_max.x, world_min.y, world_min.z)),
			mathutils.Vector((world_max.x, world_min.y, world_max.z)),
			mathutils.Vector((world_max.x, world_max.y, world_max.z)),
			mathutils.Vector((world_max.x, world_max.y, world_min.z)),
		]


	@staticmethod
	def very_fast(source: 'GeometrySource'):
		'''
		Very-fast global bounding box.
		Uses only object world origins.
		'''

		world_points = [obj.matrix_world.translation for obj in source.iter_objects()]

		if not world_points:
			v = mathutils.Vector((0.0, 0.0, 0.0))
			return [v] * 8

		# compute per-axis min/max using map
		world_min = mathutils.Vector(map(min, *world_points))
		world_max = mathutils.Vector(map(max, *world_points))

		# reconstruct the 8 corners from global min/max
		return [
			mathutils.Vector((world_min.x, world_min.y, world_min.z)),
			mathutils.Vector((world_min.x, world_min.y, world_max.z)),
			mathutils.Vector((world_min.x, world_max.y, world_max.z)),
			mathutils.Vector((world_min.x, world_max.y, world_min.z)),
			mathutils.Vector((world_max.x, world_min.y, world_min.z)),
			mathutils.Vector((world_max.x, world_min.y, world_max.z)),
			mathutils.Vector((world_max.x, world_max.y, world_max.z)),
			mathutils.Vector((world_max.x, world_max.y, world_min.z)),
		]


class SnapTarget:

	def __init__(self, source: 'GeometrySource'):
		self.source = source
		self._bbox_representation = None
		self._mesh_representation = None

	@property
	def matrix(self):
		return self._get_current_representation().matrix


	def _get_current_representation(self):
		prefs = runtime_state.modal_preferences

		if prefs.snap_to_bounding_box:
			if self._bbox_representation is None:
				self._bbox_representation = BBoxRepresentation(self.source)
			return self._bbox_representation
		else:
			if self._mesh_representation is None:
				self._mesh_representation = MeshRepresentation(self.source)
			return self._mesh_representation

	def get_bmesh(self):
		return self._get_current_representation().get_bmesh()

	def get_bvh(self):
		return self._get_current_representation().get_bvh()


class SnapFactory:

	@staticmethod
	def create_for_objects(objects):
		# decide what kind of source to use
		if len(objects) == 1:
			source = SingleObjectSource(objects[0])
		else:
			source = MultiObjectSource(objects)

		# no need to create representation here; SnapTarget will handle it dynamically
		return SnapTarget(source)


class SnapTypeInterface(typing.Protocol):
	'''
	Different object types (Meshes, Armatures, Curves) will handle their own
	implementations for finding the nearest element to an abstract raycast.
	'''

	# MAYBE THIS SHOULD BE A FUNCTION
	@property
	def nearest_element(self) -> ElementInterface:
		'''
		Find the nearest element to the raycast hit coordinates.
		'''

		...
	

class SnapMesh:
	'''
	Finds the nearest element (vert, edge, or face)
	on a FaceElement to a given world-space coordinate.
	'''

	__slots__ = ('face', 'hit_co', '_elements')

	def __init__(self, face: FaceElement, hit_co: mathutils.Vector):
		self.face = face              # Already abstracted
		self.hit_co = hit_co          # World-space coordinate
		self._elements = None         # Lazy cache

	@property
	def elements(self) -> list[ElementBase]:
		if self._elements is None:
			self._elements = (
				self.face.verts +
				self.face.edges +
				[self.face]
			)

		return self._elements

	@property
	def nearest_element(self) -> ElementBase:
		if not self.elements:
			raise RuntimeError('Face contains no elements')

		return min(
			self.elements,
			key=lambda e: (e.world_co - self.hit_co).length_squared
		)
	
	@classmethod
	def from_raycast(cls, raycast: BVHRaycast):
		return cls(face=raycast.face, hit_co=raycast.co)


class Targets:
	'''
	Stores three target elements and tracks which one is being assigned.
	Uses 1-based indexing: 1 = first, 2 = second, 3 = third.
	'''
	
	first:  ElementInterface = None
	second: ElementInterface = None
	third:  ElementInterface = None
	active_index: int = 1

	def __iter__(self):
		yield self.first
		yield self.second
		yield self.third
	
	def __len__(self):
		return sum(target is not None for target in (self.first, self.second, self.third))
	
	@property
	def valid(self) -> list[ElementInterface]:
		'''
		Return all non-None targets in slot order.
		'''

		return [t for t in (self.first, self.second, self.third) if t]
	
	@property
	def active(self) -> ElementInterface:
		'''
		Return the currently active target (may be None).
		'''

		return {
			1: self.first,
			2: self.second,
			3: self.third,
		}.get(self.active_index)
	
	@property
	def last_valid(self) -> ElementInterface | None:
		'''
		Return the last non-None target in slot order.
		'''

		for t in (self.third, self.second, self.first):
			if t is not None:
				return t
		return None

	@property
	def inactive(self) -> list[ElementInterface]:
		'''
		Return all valid targets except the active one.
		'''

		active = self.active
		return [t for t in self.valid if t is not active]
	

	def clear(self):
		self.first = None
		self.second = None
		self.third = None
		self.choosing_first = True

	@property
	def choosing_first(self) -> bool:
		return self.active_index == 1

	@choosing_first.setter
	def choosing_first(self, value: bool):
		if value:
			self.active_index = 1

	@property
	def choosing_second(self) -> bool:
		return self.active_index == 2

	@choosing_second.setter
	def choosing_second(self, value: bool):
		if value:
			self.active_index = 2

	@property
	def choosing_third(self) -> bool:
		return self.active_index == 3

	@choosing_third.setter
	def choosing_third(self, value: bool):
		if value:
			self.active_index = 3


@dataclasses.dataclass(slots=True)
class Binding:
	name: str
	has_callback:          bool = dataclasses.field(default=True, kw_only=True)
	callback_source: typing.Any = dataclasses.field(default=None, kw_only=True)
	modifier:        str | None = dataclasses.field(default=None, kw_only=True)

	def get_source(self):
		return self.callback_source or runtime_state.modal_operator_instance	
	
	@property
	def hotkey_str(self) -> str:
		'''
		Useful whenever you need to display a single string
		(debugging, datatypes.HUDProperty.hotkey).
		'''
		
		hotkeys = getattr(self, 'hotkeys', None)
		if hotkeys:
			return ', '.join(str(h) for h in hotkeys if h)

		hotkey = getattr(self, 'hotkey', None)
		if hotkey:
			return str(hotkey)
		
		raise AttributeError('Subclass must define `hotkey` or `hotkeys`')
		
	@property
	def callback(self):
		if not self.has_callback:
			debug.msg(self.name, 'Callback getter DISABLED')
			return None
		
		callback_name = f'_{self.name}_callback'
		source = self.get_source()
		callback = getattr(source, callback_name, None)

		if callback is None:
			raise AttributeError(f'Callback {source.__class__.__name__}.{callback_name} does not exist')
		
		return callback

	# @property
	def is_valid_modifier(self) -> bool:
		return self.modifier in ('CTRL', 'ALT', 'SHIFT')
	

@dataclasses.dataclass(slots=True)
class KeyBinding(Binding):
	parent: str | None = None
	
	@property
	def hotkey(self):
		attr_name = f'{self.name}_key'
		hotkey_attr = getattr(addon.get_preferences(), attr_name, None)

		if hotkey_attr is None:
			raise AttributeError(f'Hotkey attribute {attr_name} does not exist')
		
		return hotkey_attr
	
	@property
	def is_valid_hotkey(self) -> bool:
		'''
		Checks for falsy hotkey values that cannot be assigned.
		'''

		return bool(self.hotkey)
	

@dataclasses.dataclass(slots=True)
class KeyBindingGroup(Binding):
	kb_group:	list[KeyBinding]
	prop_group: 	tuple[str, ...] | None = None	# Optional Props you want to group under the name.

	def __iter__(self):
		yield from self.kb_group
	
	@property
	def hotkeys(self) -> tuple[str, ...]:
		return tuple(hotkey for kb in self.kb_group if (hotkey := kb.hotkey))
	
		# return tuple(
		# 	kb.hotkey for kb in self.group
		# 	if kb.hotkey
		# )


@dataclasses.dataclass
class HUDProperty:
	'''
	Unordered HUD property info to be drawn in the viewport
	during the modal.
	'''
	
	key_binding: KeyBinding | KeyBindingGroup
	value: typing.Any

	@property
	def name(self):
		return pretty.title(self.key_binding.name)
	
	@property
	def hotkey(self):
		# Use the debugger property
		return self.key_binding.hotkey_str
	
	@property
	def modifier(self):
		return self.key_binding.modifier


@dataclasses.dataclass
class FakeRow:
	'''
	Creates one UILayout row in each provided column and forwards
	common row attributes to all of them.
	'''

	def __init__(self, columns, align=True) -> None:
		if len(columns) not in (2, 3):
			raise ValueError('FakeRow instance can only recieve 2 or 3 columns.')
		
		self.rows = [
			col.row(align=align) 
			for col in columns
		]

		# Align the same way you do the columns
		self.rows[0].alignment = 'RIGHT'
		self.rows[1].alignment = 'CENTER'
		self.rows[-1].alignment = 'LEFT'

	def _apply(self, attr: str, val) -> None:
		'''
		Iterate over the list of rows to apply an attribute value.
		'''
		
		if not self.rows:
			return
		
		if not hasattr(self.rows[0], attr):
			raise AttributeError(f'UILayout rows do not have attribute {attr!r}')
		
		for row in self.rows:
			setattr(row, attr, val)
	

	# Forward Common Attributes __________________________________________________

	def label(self, *args, **kwargs) -> None:
		self.rows[0].label(*args, **kwargs)

	def icon(self, *args, **kwargs) -> None:
		if len(self.rows) != 3:
			# raise ValueError('Icons require exactly 3 columns')
			return
		
		self.rows[1].label(*args, **kwargs)

	def prop(self, *args, **kwargs) -> None:
		self.rows[-1].prop(*args, **kwargs)

	@property
	def enabled(self) -> bool:
		return self.rows[0].enabled if self.rows else True
	
	@enabled.setter
	def enabled(self, val: bool) -> None:
		self._apply('enabled', val)

	@property
	def active(self) -> bool:
		return self.rows[0].active if self.rows else True
	@active.setter
	def active(self, val: bool) -> None:
		self._apply('active', val)

	@property
	def alert(self) -> bool:
		return self.rows[0].alert if self.rows else False
	@alert.setter
	def alert(self, val: bool) -> None:
		self._apply('alert', val)