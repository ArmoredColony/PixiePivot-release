import bpy
import bmesh
import collections
import dataclasses
import gpu
import math
import mathutils

import gpu_extras.batch as gpu_batch

from . import datatypes


# TYPE ALIASES __________________________________________________

RGB  = tuple[float, float, float]
RGBA = tuple[float, float, float, float]


def get_rgb(color) -> RGB:
	'''
	Return the first 3 color components (RGB). Raises if fewer than 3.
	'''
	
	if len(color) < 3:
		raise ValueError(f'Expected 3 or more elements, got {len(color)}: {color}')

	return color[:3]


def get_alpha(color) -> float:
	'''
	Return the alpha component from a 4-element color. Raises if invalid.
	'''
	
	if len(color) != 4:
		raise ValueError('Expected 4-element color (RGBA), got: ' + str(color))
	
	return color[3]


def get_theme_axis_colors_rgb(context) -> tuple[RGB, RGB, RGB]:
	'''
	Return RGB tuples for X, Y, Z axis from the current theme.
	'''
	
	theme = context.preferences.themes[0]
	ui = theme.user_interface
	
	return ui.axis_x, ui.axis_y, ui.axis_z


def get_theme_axis_colors_rgba(context, alpha: float = 1.0) -> tuple[RGBA, RGBA, RGBA]:
	'''
	Return RGBA tuples for X, Y, Z axis from the current theme.
	'''
	
	rgb_colors = get_theme_axis_colors_rgb(context)

	return tuple((*color, alpha) for color in rgb_colors)



# --- TOPOLOGY CACHE (object-space verts + loop-tri indices) -----------------

_mesh_topology_cache: dict[int, dict] = {}

def get_mesh_tris_objspace(mesh: bpy.types.Mesh) -> tuple[list[mathutils.Vector], list[tuple[int, int, int]]]:
	'''
	Return object-space vertices and loop-triangle indices for a mesh.
	Cached for speed; call invalidate_mesh_topology(mesh) when topology changes.
	'''
	
	key = mesh.as_pointer()
	ent = _mesh_topology_cache.get(key)
	if ent is not None:
		return ent['verts'], ent['tris']
	
	verts = [v.co.copy() for v in mesh.vertices]
	if not mesh.loop_triangles:
		mesh.calc_loop_triangles()
	tris = [tuple(lt.vertices) for lt in mesh.loop_triangles]
	
	_mesh_topology_cache[key] = {'verts': verts, 'tris': tris}
	return verts, tris


def invalidate_mesh_topology(mesh: bpy.types.Mesh) -> None:
	'''
	Drop cached topology for this mesh (call if modifiers/topology change).
	'''
	
	_mesh_topology_cache.pop(mesh.as_pointer(), None)



# STYLES ________________________________________________________

@dataclasses.dataclass(frozen=True)
class DrawStyle:
	'''
	Immutable style for drawables.
	'''

	color: RGBA = (1.0, 1.0, 1.0, 1.0)
	width_px: float = 2.0
	depth_test: bool = True
	blend: bool = True

	def with_(self, **changes):
		'''
		Return a copy with requested field changes.
		'''

		return dataclasses.replace(self, **changes)


@dataclasses.dataclass(frozen=True)
class ElementStyle:
	'''
	Compound, user-facing style for drawing mesh elements.

	Color precedence per kind ('points' | 'lines' | 'tris'):
		per-kind color → global color → default

	Common use:
	- set just 'color' for a global look
	- optionally set point_color/line_color/poly_color to override
	- set sizes once; sensible depth/blend policies applied automatically
	- 'outline' controls whether face outlines are requested
	'''

	# global color (or None to force per-kind only)
	color: RGBA | None = (1.0, 1.0, 0.0, 1.0)

	# optional per-kind overrides (singular names)
	point_color: RGBA | None = None
	line_color:  RGBA | None = None
	poly_color:  RGBA | None = None   # polygon/face fill

	# sizes / policy
	point_size: float = 6.0		# px
	line_width: float = 3.0		# px (POLYLINE_UNIFORM_COLOR)
	face_opacity: float = 0.3       # scales fill alpha
	depth_test: bool = False	# cull when behind other geometry.
	outline: bool = True		# draw outlines for faces/polys

	def with_(self, **changes):
		'''
		Return a copy with changed fields.
		'''

		return dataclasses.replace(self, **changes)

	def faded(self, factor: float = 0.4) -> 'ElementStyle':
		'''
		Return a faded variant by scaling alpha on any colors that are set.
		'''

		def _fade(c: RGBA | None) -> RGBA | None:
			if c is None:
				return None
			r, g, b, a = c
			return (r, g, b, a * factor)

		return self.with_(
			color=_fade(self.color),
			point_color=_fade(self.point_color),
			line_color=_fade(self.line_color),
			poly_color=_fade(self.poly_color),
		)

	def _resolve_color(self, kind: str, default_color: RGBA) -> RGBA:
		'''
		Resolve RGBA for 'points' | 'lines' | 'tris' via precedence.
		'''

		per_kind = {
			'points': self.point_color,
			'lines':  self.line_color,
			'tris':   self.poly_color,
		}.get(kind)
		if per_kind is not None:
			return per_kind
		if self.color is not None:
			return self.color
		return default_color

	def to_draw_styles(self) -> tuple[DrawStyle, DrawStyle, DrawStyle]:
		'''
		Resolve this ElementStyle into per-primitive DrawStyles.

		Returns:
			(points_style, line_style, poly_style)
		'''

		points_dt = self.depth_test
		lines_dt  = self.depth_test
		tris_dt   = self.depth_test

		points_col = self._resolve_color('points', (1.0, 1.0, 1.0, 1.0))
		lines_col  = self._resolve_color('lines',  (1.0, 1.0, 1.0, 1.0))
		tris_col   = self._resolve_color('tris',   (1.0, 1.0, 1.0, 1.0))

		# Apply face opacity to alpha
		r, g, b, a = tris_col
		tris_col = (r, g, b, min(1.0, a * self.face_opacity))

		points = DrawStyle(
			color=points_col,
			width_px=self.point_size,
			depth_test=points_dt,
			blend=True,
		)
		lines = DrawStyle(
			color=lines_col,
			width_px=self.line_width,
			depth_test=lines_dt,   # overlay by default for outlines
			blend=True,            # AA required for POLYLINE_UNIFORM_COLOR
		)
		tris = DrawStyle(
			color=tris_col,
			width_px=1.0,          # unused
			depth_test=tris_dt,
			blend=True,            # semi-transparent fills
		)

		return points, lines, tris


# SHADERS (BUILT-INS) __________________________________________

class ShaderRegistry:
	'''
	Lazy access to built-in shaders. Centralize swaps here.
	'''

	_point = None
	_line = None
	_face = None

	@classmethod
	def point(cls):
		'''
		Point shader with size uniform (Blender 4.5+).
		'''

		if cls._point is None:
			cls._point = gpu.shader.from_builtin('POINT_UNIFORM_COLOR')
		return cls._point

	@classmethod
	def line(cls):
		'''
		Screen-space thick, anti-aliased lines.
		Requires uniforms: viewportSize, lineWidth.
		'''

		if cls._line is None:
			cls._line = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
		return cls._line

	@classmethod
	def face(cls):
		'''
		Uniform color for triangles.
		'''

		if cls._face is None:
			cls._face = gpu.shader.from_builtin('UNIFORM_COLOR')
		return cls._face


# GEOMETRY DATA _________________________________________________

@dataclasses.dataclass
class Geometry:
	'''
	Plain geometry container: positions and optional indices.
	Mark dirty when mutated; drawables rebuild batches lazily.
	'''

	positions: list[mathutils.Vector] = dataclasses.field(default_factory=list)
	indices: list[tuple[int, int]] | list[tuple[int, int, int]] | None = None
	_dirty: bool = True

	def set_positions(self, verts: list[mathutils.Vector]) -> None:
		'''
		Replace vertex list and mark dirty.
		'''

		self.positions = verts
		self._dirty = True

	def set_indices(self, idx) -> None:
		'''
		Replace index list and mark dirty.
		'''

		self.indices = idx
		self._dirty = True

	def mark_clean(self) -> None:
		'''
		Mark this geometry as clean after (re)batching.
		'''

		self._dirty = False

	def is_dirty(self) -> bool:
		'''
		Whether the geometry has changed since last batch build.
		'''

		return self._dirty


# DRAWABLES _____________________________________________________

class Drawable:
	'''
	Base drawable that owns style, geometry and a GPU batch.

	Subclasses provide:
		- _shader()        → gpu shader object
		- _primitive()     → 'POINTS' | 'LINES' | 'TRIS'

	Optionally override:
		- _apply_per_primitive_state(style)  # GPU state (depth/line/point)
		- _apply_shader_uniforms(shader, style)  # extra uniforms (e.g., viewport/width)
	'''

	def __init__(self, style: DrawStyle | None = None):
		self.style = style or DrawStyle()
		self.geom = Geometry()
		self._batch = None
		self.model_matrix: mathutils.Matrix | None = None

	def set_style(self, style: DrawStyle) -> None:
		'''
		Swap the current style (immutable).
		'''

		self.style = style

	def set_geometry(self, geom: Geometry) -> None:
		'''
		Replace geometry and invalidate the GPU batch.
		'''

		self.geom = geom
		self._batch = None

	def _shader(self):
		'''
		Return the GPU shader for this drawable.
		'''

		raise NotImplementedError

	def _primitive(self):
		'''
		Terminology:
		- 'primitive' = GPU draw topology ('POINTS' | 'LINES' | 'TRIS'), not Blender mesh primitives.
		'''

		raise NotImplementedError

	def _apply_common_state(self, style: DrawStyle) -> None:
		'''
		Apply shared depth/blend state.
		'''

		if style.depth_test:
			gpu.state.depth_test_set('LESS_EQUAL')
		else:
			gpu.state.depth_test_set('NONE')
		gpu.state.blend_set('ALPHA' if style.blend else 'NONE')

	def _apply_per_primitive_state(self, style: DrawStyle) -> None:
		'''
		Optional state hook for subclasses (legacy line/point width).
		'''

		pass

	def _apply_shader_uniforms(self, shader, style: DrawStyle) -> None:
		'''
		Optional uniforms hook for subclasses (e.g., viewportSize, lineWidth, size).
		'''

		pass

	def _ensure_batch(self) -> None:
		'''
		Build or rebuild the batch if geometry changed.
		'''

		if self._batch is not None and not self.geom.is_dirty():
			return

		verts = [tuple(v) for v in self.geom.positions]
		primitive = self._primitive()
		shader = self._shader()

		if primitive == 'POINTS':
			self._batch = gpu_batch.batch_for_shader(shader, 'POINTS', {'pos': verts})
		elif primitive == 'LINES':
			if not self.geom.indices:
				self._batch = gpu_batch.batch_for_shader(shader, 'LINES', {'pos': verts})
			else:
				self._batch = gpu_batch.batch_for_shader(shader, 'LINES', {'pos': verts}, indices=self.geom.indices)
		elif primitive == 'TRIS':
			if not self.geom.indices:
				self._batch = gpu_batch.batch_for_shader(shader, 'TRIS', {'pos': verts})
			else:
				self._batch = gpu_batch.batch_for_shader(shader, 'TRIS', {'pos': verts}, indices=self.geom.indices)
		else:
			raise RuntimeError(f'Unknown primitive: {primitive}')

		self.geom.mark_clean()

	def draw(self, *, style_override: DrawStyle | None = None) -> None:
		'''
		Draw using the batch, applying state, shader uniforms, and optional model matrix.
		'''

		style = style_override or self.style
		self._ensure_batch()

		self._apply_common_state(style)
		self._apply_per_primitive_state(style)

		shader = self._shader()
		shader.bind()
		shader.uniform_float('color', style.color)
		self._apply_shader_uniforms(shader, style)

		if self.model_matrix is not None:
			gpu.matrix.push()
			gpu.matrix.multiply_matrix(self.model_matrix)

		self._batch.draw(shader)

		if self.model_matrix is not None:
			gpu.matrix.pop()


class PointSet(Drawable):
	'''
	Draws points using POINT_UNIFORM_COLOR (size via uniform).
	'''

	def _shader(self):
		return ShaderRegistry.point()

	def _primitive(self):
		return 'POINTS'

	def draw(self, *, style_override: DrawStyle | None = None) -> None:
		'''
		Wrap base draw to enable program point size while we draw.
		'''
		
		gpu.state.program_point_size_set(True)
		try:
			super().draw(style_override=style_override)
		finally:
			gpu.state.program_point_size_set(False)

	def _apply_shader_uniforms(self, shader, style: DrawStyle) -> None:
		'''
		Set the required 'size' uniform (pixels).
		'''
		shader.uniform_float('size', float(max(1.0, style.width_px)))



class LineSet(Drawable):
	'''
	Draws anti-aliased, screen-space thick lines using POLYLINE_UNIFORM_COLOR.
	Requires 'viewportSize' and 'lineWidth' uniforms.
	'''

	def _shader(self):
		return ShaderRegistry.line()

	def _primitive(self):
		return 'LINES'

	def _apply_per_primitive_state(self, style: DrawStyle) -> None:
		'''
		No gpu.state.line_width_set; polyline shader ignores it.
		'''

		pass

	def _apply_shader_uniforms(self, shader, style: DrawStyle) -> None:
		'''
		Set polyline uniforms: viewportSize (w, h in px) and lineWidth (px).
		'''

		shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
		shader.uniform_float('lineWidth', float(max(1.0, style.width_px)))


class FaceSet(Drawable):
	'''
	Draws filled triangles using UNIFORM_COLOR.
	'''
	def _shader(self):
		return ShaderRegistry.face()

	def _primitive(self):
		return 'TRIS'


# DRAW LAYER (HANDLER) __________________________________________

class DrawLayer:
	'''
	A draw layer holds a list of drawables and one draw handler.
	Use POST_VIEW for 3D; POST_PIXEL for 2D overlays.
	'''

	def __init__(self, region_type='WINDOW', draw_type='POST_VIEW'):
		'''
		Configure which region/type this layer draws into.
		'''

		self._region_type = region_type
		self._draw_type = draw_type
		self._drawables: list[Drawable] = []
		self._handler = None
		self._enabled = False
		self.visible = True

	def add(self, drawable: Drawable) -> None:
		'''
		Add a drawable to this layer.
		'''

		self._drawables.append(drawable)

	def remove(self, drawable: Drawable) -> None:
		'''
		Remove a drawable if present.
		'''

		try:
			self._drawables.remove(drawable)
		except ValueError:
			pass

	def enable(self) -> None:
		'''
		Register the draw handler (no-op if already enabled).
		'''

		if self._enabled:
			return

		self._handler = bpy.types.SpaceView3D.draw_handler_add(
			self._callback, (), self._region_type, self._draw_type
		)
		self._enabled = True

	def disable(self) -> None:
		'''
		Unregister the draw handler (no-op if already disabled).
		'''

		if not self._enabled:
			return
		
		bpy.types.SpaceView3D.draw_handler_remove(self._handler, self._region_type)
		self._handler = None
		self._enabled = False

	def _callback(self):
		'''
		Draw callback bound to the SpaceView3D handler.
		'''

		if not self.visible:
			return 
		
		for d in self._drawables:
			d.draw()


# DRAW REQUESTS (ADAPTER OUTPUT) ________________________________

@dataclasses.dataclass(frozen=True)
class DrawRequest:
	'''
	Normalized request for drawing geometry.

	kind: 'points' | 'lines' | 'tris'
	coords_world: world-space vertex positions
	indices: optional index list (pairs for lines, triplets for tris)
	'''

	kind: str
	coords_world: list[mathutils.Vector]
	indices: list[tuple[int, int]] | list[tuple[int, int, int]] | None = None


# ADAPTER HELPERS (BM / MESH / RAW) _____________________________

def _to_world(vec: mathutils.Vector, matrix_world: mathutils.Matrix) -> mathutils.Vector:
	'''
	Transform a vector by matrix_world, returning a new Vector.
	'''

	return matrix_world @ vec


def _mesh_coords_world(mesh: bpy.types.Mesh, matrix_world: mathutils.Matrix) -> list[mathutils.Vector]:
	'''
	Return world-space coordinates for all mesh verts.
	'''

	return [_to_world(v.co, matrix_world) for v in mesh.vertices]


def _triangulate_coords(coords: list[mathutils.Vector]) -> list[tuple[int, int, int]]:
	'''
	Robustly triangulate a polygon described by 'coords' (no holes).
	Uses mathutils.geometry.tessellate_polygon; falls back to fan.
	'''

	if len(coords) < 3:
		return []

	try:
		tris = mathutils.geometry.tessellate_polygon([coords])
		if tris:
			return [(a, b, c) for (a, b, c) in tris]
	except Exception:
		pass

	# fallback: simple fan
	return [(0, i, i + 1) for i in range(1, len(coords) - 1)]


def request_from_point(co: mathutils.Vector, matrix: mathutils.Matrix = None) -> DrawRequest:
	'''
	Create a point request from a BMVert.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	return DrawRequest(
		kind='points',
		coords_world=[_to_world(co, matrix)],
		indices=None,
	)

def request_from_bmvert(vert: bmesh.types.BMVert, matrix: mathutils.Matrix = None) -> DrawRequest:
	'''
	Create a point request from a BMVert.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	return DrawRequest(
		kind='points',
		coords_world=[_to_world(vert.co, matrix)],
		indices=None,
	)


def request_from_bmedge(edge: bmesh.types.BMEdge, matrix: mathutils.Matrix = None) -> DrawRequest:
	'''
	Create a line request from a BMEdge.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	a = _to_world(edge.verts[0].co, matrix)
	b = _to_world(edge.verts[1].co, matrix)
	return DrawRequest(
		kind='lines',
		coords_world=[a, b],
		indices=[(0, 1)],
	)


def request_from_bmface(face: bmesh.types.BMFace, matrix: mathutils.Matrix = None, *, outline: bool = True) -> tuple[DrawRequest, DrawRequest | None]:
	'''
	Create a filled triangulated face request and an optional outline request.
	Concave ngons are handled via tessellation; falls back to fan.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	coords = [_to_world(l.vert.co, matrix) for l in face.loops]
	tri_idx = _triangulate_coords(coords)

	fill_req = DrawRequest(
		kind='tris',
		coords_world=coords,
		indices=tri_idx if tri_idx else None,
	)

	outline_req = None
	if outline and len(coords) >= 2:
		n = len(coords)
		edges = [(i, (i + 1) % n) for i in range(n)]
		outline_req = DrawRequest(
			kind='lines',
			coords_world=coords,
			indices=edges,
		)

	return fill_req, outline_req


def request_from_meshvertex(vert: bpy.types.MeshVertex, matrix: mathutils.Matrix = None) -> DrawRequest:
	'''
	Create a point request from a MeshVertex.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	return DrawRequest(
		kind='points',
		coords_world=[_to_world(vert.co, matrix)],
		indices=None,
	)


def request_from_meshedge(edge: bpy.types.MeshEdge, matrix: mathutils.Matrix = None) -> DrawRequest:
	'''
	Create a line request from a MeshEdge.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	mesh: bpy.types.Mesh = edge.id_data
	va = mesh.vertices[edge.vertices[0]].co
	vb = mesh.vertices[edge.vertices[1]].co
	a = _to_world(va, matrix)
	b = _to_world(vb, matrix)
	return DrawRequest(
		kind='lines',
		coords_world=[a, b],
		indices=[(0, 1)],
	)


def request_from_meshpolygon(poly: bpy.types.MeshPolygon, matrix: mathutils.Matrix = None, *, outline: bool = True) -> tuple[DrawRequest, DrawRequest | None]:
	'''
	Create a filled triangulated polygon request and an optional outline request.
	Concave ngons are handled via tessellation; falls back to fan.
	'''

	if matrix is None:
		matrix = mathutils.Matrix.Identity(4)

	mesh: bpy.types.Mesh = poly.id_data
	coords = [_to_world(mesh.vertices[i].co, matrix) for i in poly.vertices]
	tri_idx = _triangulate_coords(coords)

	fill_req = DrawRequest(
		kind='tris',
		coords_world=coords,
		indices=tri_idx if tri_idx else None,
	)

	outline_req = None
	if outline and len(coords) >= 2:
		n = len(coords)
		edges = [(i, (i + 1) % n) for i in range(n)]
		outline_req = DrawRequest(
			kind='lines',
			coords_world=coords,
			indices=edges,
		)

	return fill_req, outline_req


def requests_from_iterable(items, matrix_world: mathutils.Matrix = None, *, outline: bool = True) -> list[DrawRequest]:
	'''
	Dispatch a heterogeneous iterable of BMesh/Mesh elements into DrawRequests.
	Also supports bpy.types.Object by emitting its local AABB as line requests.
	Set 'outline' to False to skip face outlines. Unknown items are ignored.
	'''

	if matrix_world is None:
		matrix_world = mathutils.Matrix.Identity(4)

	reqs: list[DrawRequest] = []
	for it in items:
		if isinstance(it, bmesh.types.BMVert):
			reqs.append(request_from_bmvert(it, matrix_world))

		elif isinstance(it, bmesh.types.BMEdge):
			reqs.append(request_from_bmedge(it, matrix_world))

		elif isinstance(it, bmesh.types.BMFace):
			fill_req, outline_req = request_from_bmface(it, matrix_world, outline=outline)
			reqs.append(fill_req)
			if outline_req:
				reqs.append(outline_req)

		elif isinstance(it, bpy.types.MeshVertex):
			reqs.append(request_from_meshvertex(it, matrix_world))

		elif isinstance(it, bpy.types.MeshEdge):
			reqs.append(request_from_meshedge(it, matrix_world))

		elif isinstance(it, bpy.types.MeshPolygon):
			fill_req, outline_req = request_from_meshpolygon(it, matrix_world, outline=outline)
			reqs.append(fill_req)
			if outline_req:
				reqs.append(outline_req)

		elif isinstance(it, bpy.types.Object):
			# route objects to bounds-as-lines; ignores 'matrix_world' arg by design
			# (request_from_object_bounds uses the object's own matrix_world)
			try:
				reqs.append(request_from_object_bounds(it))
			except Exception as ex:
				print(f'Object bounds request failed for {it!r}: {ex}')

		else:
			print(f'Unknown type {type(it)} → SKIP DRAW')
			pass

	return reqs


# def requests_from_elements(elements, *, outline: bool = True) -> list[DrawRequest]:
# 	'''
# 	Dispatch a heterogeneous iterable of BMesh/Mesh elements into DrawRequests.
# 	Also supports bpy.types.Object by emitting its local AABB as line requests.
# 	Set 'outline' to False to skip face outlines. Unknown elementss are ignored.
# 	'''

# 	# if matrix_world is None:
# 	# 	matrix_world = mathutils.Matrix.Identity(4)

# 	reqs: list[DrawRequest] = []

# 	for elem in elements:

# 		if hasattr(elem, 'obj'):
# 			M = elem.obj.matrix_world
# 		else:
# 			M = mathutils.Matrix.Identity(4)

# 		# FACE
# 		if hasattr(elem, 'edges'):
# 			fill_req, outline_req = request_from_bmface(elem, M, outline=outline)
# 			reqs.append(fill_req)
# 			if outline_req:
# 				reqs.append(outline_req)

# 		# EDGE
# 		elif hasattr(elem, 'verts'):
# 			reqs.append(request_from_bmedge(elem, M))
		
# 		# VERT
# 		else:
# 			reqs.append(request_from_bmvert(elem, M))

# 	return reqs

def requests_from_interfaces(
	elements: list[datatypes.ElementInterface],
	*,
	outline: bool = True
) -> list[DrawRequest]:

	reqs: list[DrawRequest] = []

	for elem in elements:

		# --------------------
		# FACE
		# --------------------
		if isinstance(elem, datatypes.FaceElement):

			coords = [v.world_co for v in elem.verts]
			tri_idx = _triangulate_coords(coords)

			# Fill
			reqs.append(
				DrawRequest(
					kind='tris',
					coords_world=coords,
					indices=tri_idx if tri_idx else None,
				)
			)

			# Outline
			if outline and len(coords) >= 2:
				n = len(coords)
				edges = [(i, (i + 1) % n) for i in range(n)]

				reqs.append(
					DrawRequest(
						kind='lines',
						coords_world=coords,
						indices=edges,
					)
				)

		# --------------------
		# EDGE
		# --------------------
		elif isinstance(elem, datatypes.EdgeElement):

			coords = [v.world_co for v in elem.verts]

			if len(coords) == 2:
				reqs.append(
					DrawRequest(
						kind='lines',
						coords_world=coords,
						indices=[(0, 1)],
					)
				)

		# --------------------
		# VERT
		# --------------------
		elif isinstance(elem, datatypes.VertElement):

			reqs.append(
				DrawRequest(
					kind='points',
					coords_world=[elem.world_co],
					indices=None,
				)
			)
		
		elif elem is None:
			return
		
		else:
			raise TypeError(
				f'This function only works with ElementInterface types, '
				f'got {type(elem).__name__}'
			)

	return reqs



# def requests_from_object(
# 	obj: bpy.types.Object,
# 	rv3d,
# 	*,
# 	outline: bool = True,
# 	include_boundary: bool = True,
# ) -> list[DrawRequest]:
# 	'''
# 	Produce DrawRequests for a whole mesh object.

# 	If outline is False:
# 		- Return fills for all polygons (no per-face outlines), by delegating to
# 		  request_from_meshpolygon(.., outline=False) across the mesh.

# 	If outline is True:
# 		- Compute a single 'lines' request that draws the object's silhouette
# 		  (plus boundary edges if include_boundary=True) using world-space
# 		  face normals and the current view (persp/ortho-aware).

# 	Args:
# 		obj: Mesh object to visualize.
# 		depsgraph: context.evaluated_depsgraph_get() for modifiers, etc.
# 		rv3d: context.region_data (to get view matrix / perspective).

# 	Returns:
# 		list[DrawRequest]: zero or more requests, ready for build_primitive_batches().
# 	'''

# 	if not obj or not isinstance(getattr(obj, 'data', None), bpy.types.Mesh):
# 		return []

# 	# Use the evaluated object to reflect modifiers, depsgraph state, etc.
# 	mesh: bpy.types.Mesh = obj.data
# 	M: mathutils.Matrix = obj.matrix_world

# 	if not outline:
# 		# Fill all faces (no outlines) by reusing the existing polygon adapter.
# 		reqs: list[DrawRequest] = []
# 		for poly in mesh.polygons:
# 			fill_req, _maybe_outline = request_from_meshpolygon(poly, M, outline=False)
# 			reqs.append(fill_req)
# 		return reqs

# 	# --- Outline path (silhouette + optional boundary) ----------------------

# 	# World-space verts for edge coordinate lookup
# 	verts_world = [M @ v.co for v in mesh.vertices]

# 	# Map each edge to the polygons that reference it
# 	edge_to_polys: dict[int, list[int]] = {i: [] for i in range(len(mesh.edges))}
# 	for poly in mesh.polygons:
# 		for li in poly.loop_indices:
# 			ei = mesh.loops[li].edge_index
# 			edge_to_polys[ei].append(poly.index)

# 	# World-space face normals and centers
# 	# Transform normals by inverse-transpose to handle object scale/shear.
# 	Nx = M.to_3x3().inverted().transposed()
# 	n_world: list[mathutils.Vector] = [mathutils.Vector((0, 0, 1))] * len(mesh.polygons)
# 	c_world: list[mathutils.Vector] = [mathutils.Vector((0, 0, 0))] * len(mesh.polygons)

# 	for p in mesh.polygons:
# 		n_world[p.index] = (Nx @ p.normal).normalized()
# 		c_world[p.index] = M @ p.center

# 	# View data: perspective uses camera position; ortho uses view direction
# 	view_inv = rv3d.view_matrix.inverted()
# 	cam_pos = view_inv.translation
# 	view_dir = -(view_inv.to_3x3().col[2]).normalized()  # points from camera into scene

# 	def face_facing_sign(p_index: int) -> float:
# 		'''
# 		>0.0 if face is front-facing relative to the view, <0.0 if back-facing.
# 		Uses perspective-correct vectors when in perspective view.
# 		'''
# 		n = n_world[p_index]
# 		if rv3d.is_perspective:
# 			v = (cam_pos - c_world[p_index]).normalized()
# 		else:
# 			v = view_dir
# 		return n.dot(v)

# 	# Accumulate included edges as one big line request
# 	line_coords: list[mathutils.Vector] = []
# 	line_indices: list[tuple[int, int]] = []
# 	base = 0

# 	for i, edge in enumerate(mesh.edges):
# 		pis = edge_to_polys.get(i, [])

# 		include = False
# 		if len(pis) <= 1:
# 			# Boundary edges (one or zero faces)
# 			include = include_boundary
# 		elif len(pis) == 2:
# 			# Silhouette test: opposite facing wrt the view
# 			s0 = face_facing_sign(pis[0]) > 0.0
# 			s1 = face_facing_sign(pis[1]) > 0.0
# 			include = (s0 != s1)

# 		if include:
# 			i0, i1 = edge.vertices
# 			a = verts_world[i0]
# 			b = verts_world[i1]
# 			line_coords.extend((a, b))
# 			line_indices.append((base, base + 1))
# 			base += 2

# 	if not line_indices:
# 		return []

# 	return [DrawRequest(kind='lines', coords_world=line_coords, indices=line_indices)]


def request_point(co: tuple[float, ...]) -> DrawRequest:
	x, y, *rest = co
	z = rest[0] if rest else 0.0

	co = mathutils.Vector((x, y, z))

	return DrawRequest(kind='points', coords_world=[co], indices=None)


def requests_from_points(points: list[tuple[float, ...]]) -> list[DrawRequest]:
	'''
	Many POST_PIXEL points at once.
	'''

	return [request_point(p) for p in points]


def request_from_aabb(min_co: mathutils.Vector, max_co: mathutils.Vector) -> DrawRequest:
	'''
	Return a DrawRequest that draws an AABB as lines.

	Params:
		min_co: world-space minimum corner (x0, y0, z0)
		max_co: world-space maximum corner (x1, y1, z1)
	'''
	x0, y0, z0 = float(min_co.x), float(min_co.y), float(min_co.z)
	x1, y1, z1 = float(max_co.x), float(max_co.y), float(max_co.z)

	# 8 corners (world space)
	corners = [
		mathutils.Vector((x0, y0, z0)),  # 0
		mathutils.Vector((x1, y0, z0)),  # 1
		mathutils.Vector((x1, y1, z0)),  # 2
		mathutils.Vector((x0, y1, z0)),  # 3
		mathutils.Vector((x0, y0, z1)),  # 4
		mathutils.Vector((x1, y0, z1)),  # 5
		mathutils.Vector((x1, y1, z1)),  # 6
		mathutils.Vector((x0, y1, z1)),  # 7
	]

	# 12 edges (index pairs into corners)
	edges = [
		(0, 1), (1, 2), (2, 3), (3, 0),  # bottom loop
		(4, 5), (5, 6), (6, 7), (7, 4),  # top loop
		(0, 4), (1, 5), (2, 6), (3, 7),  # verticals
	]

	return DrawRequest(kind='lines', coords_world=corners, indices=edges)


def request_from_object_bounds(obj: bpy.types.Object, *, matrix_world: mathutils.Matrix | None = None, inflate: float = 0.0) -> DrawRequest:
	'''
	Create a line DrawRequest for an object's local AABB (obj.bound_box), in world space.
	No depsgraph eval; uses obj.bound_box then transforms by matrix_world or obj.matrix_world.
	'''
	# local corners (8 tuples) → Vectors
	corners_local = [mathutils.Vector(c) for c in obj.bound_box]

	# optional uniform expansion in local space
	if inflate != 0.0:
		center = sum(corners_local, mathutils.Vector((0.0, 0.0, 0.0))) / 8.0
		corners_local = [
			mathutils.Vector((
				c.x + (1.0 if c.x >= center.x else -1.0) * inflate,
				c.y + (1.0 if c.y >= center.y else -1.0) * inflate,
				c.z + (1.0 if c.z >= center.z else -1.0) * inflate,
			)) for c in corners_local
		]

	# to world space
	M = matrix_world if matrix_world is not None else obj.matrix_world
	corners_world = [M @ c for c in corners_local]

	# Blender bound_box corner order:
	# 0:(-,-,-) 1:(-,-,+) 2:(-,+,+) 3:(-,+,-)
	# 4:(+,-,-) 5:(+,-,+) 6:(+,+,+) 7:(+,+,-)
	# canonical 12 edges (no diagonals, no crossings):
	edges = [
		(0, 1), (1, 2), (2, 3), (3, 0),  # min-X face loop
		(4, 5), (5, 6), (6, 7), (7, 4),  # max-X face loop
		(0, 4), (1, 5), (2, 6), (3, 7),  # bridges
	]

	return DrawRequest(kind='lines', coords_world=corners_world, indices=edges)




# PIPELINE (BUCKETING) _________________________________________

@dataclasses.dataclass
class PrimitiveBatches:
	'''
	Per-primitive geometry accumulators for a single layer frame.
	'''

	points: Geometry = dataclasses.field(default_factory=Geometry)
	lines: Geometry  = dataclasses.field(default_factory=Geometry)
	tris: Geometry   = dataclasses.field(default_factory=Geometry)


def build_primitive_batches(requests: list[DrawRequest]) -> PrimitiveBatches:
	'''
	Accumulate DrawRequests into per-primitive Geometry buckets,
	so we draw at most three batches per frame ('POINTS', 'LINES', 'TRIS').
	'''

	batches = PrimitiveBatches()

	# points
	point_coords: list[mathutils.Vector] = []

	# lines
	line_coords: list[mathutils.Vector] = []
	line_indices: list[tuple[int, int]] = []
	line_base = 0

	# tris
	tri_coords: list[mathutils.Vector] = []
	tri_indices: list[tuple[int, int, int]] = []
	tri_base = 0

	for req in requests:
		if req.kind == 'points':
			point_coords.extend(req.coords_world)

		elif req.kind == 'lines':
			if req.indices:
				line_coords.extend(req.coords_world)
				for a, b in req.indices:
					line_indices.append((line_base + a, line_base + b))
				line_base += len(req.coords_world)
			else:
				# treat as line list in-order pairs
				cs = req.coords_world
				if len(cs) % 2 == 0:
					line_coords.extend(cs)
					for i in range(0, len(cs), 2):
						line_indices.append((line_base + i, line_base + i + 1))
					line_base += len(cs)

		elif req.kind == 'tris':
			if req.indices:
				tri_coords.extend(req.coords_world)
				for a, b, c in req.indices:
					tri_indices.append((tri_base + a, tri_base + b, tri_base + c))
				tri_base += len(req.coords_world)
			else:
				# in-order triplets
				cs = req.coords_world
				if len(cs) % 3 == 0:
					tri_coords.extend(cs)
					for i in range(0, len(cs), 3):
						tri_indices.append((tri_base + i, tri_base + i + 1, tri_base + i + 2))
					tri_base += len(cs)

	# assign
	batches.points.set_positions(point_coords)

	batches.lines.set_positions(line_coords)
	batches.lines.set_indices(line_indices if line_indices else None)

	batches.tris.set_positions(tri_coords)
	batches.tris.set_indices(tri_indices if tri_indices else None)

	return batches


# WIRES UP TO DRAWLAYER ________________________________________

class ElementLayer:
	'''
	Convenience wrapper around DrawLayer that owns one drawable per primitive type.
	You feed it DrawRequests (or BMesh/Mesh items / whole objects), it draws them batched.
	'''

	def __init__(self, draw_type: str = 'POST_VIEW'):
		'''
		Create drawables, set defaults, and register draw order.
		'''
		self.layer = DrawLayer(draw_type=draw_type)
		self.points = PointSet(style=DrawStyle(color=(1.0, 1.0, 0.0, 1.0), width_px=6.0, depth_test=True))
		self.lines  = LineSet(style=DrawStyle(color=(1.0, 0.2, 0.2, 1.0), width_px=3.0, depth_test=True))
		self.tris   = FaceSet(style=DrawStyle(color=(0.2, 0.6, 1.0, 0.25), depth_test=True, blend=True))

		self.layer.add(self.tris)   # draw order: fill first
		self.layer.add(self.lines)  # then outlines
		self.layer.add(self.points) # then points

		self._enabled = False
		self._outline_faces = True  # default; can be driven by ElementStyle.outline

	def enable(self) -> None:
		'''
		Register the draw handler.
		'''
		self.layer.enable()
		self._enabled = True

	def disable(self) -> None:
		'''
		Unregister the draw handler.
		'''
		self.layer.disable()
		self._enabled = False
	
	@property
	def visible(self) -> bool:
		return self.layer.visible

	@visible.setter
	def visible(self, flag: bool) -> None:
		self.layer.visible = bool(flag)

	def set_styles(self, *, points: DrawStyle | None = None, lines: DrawStyle | None = None, tris: DrawStyle | None = None) -> None:
		'''
		Swap styles (immutable) for each primitive.
		'''
		if points:
			self.points.set_style(points)
		if lines:
			self.lines.set_style(lines)
		if tris:
			self.tris.set_style(tris)

	def clear(self) -> None:
		'''
		Clear all geometry buckets (forces batch rebuild next draw).
		'''

		self.points.set_geometry(Geometry())
		self.lines.set_geometry(Geometry())
		self.tris.set_geometry(Geometry())

	def set_from_requests(self, requests: list[DrawRequest]) -> None:
		'''
		Consume normalized requests and update geometry buckets.
		'''

		batches = build_primitive_batches(requests)
		self.points.set_geometry(batches.points)
		self.lines.set_geometry(batches.lines)
		self.tris.set_geometry(batches.tris)

	def set_from_items(self, items, matrix_world: mathutils.Matrix = None, *, outline: bool | None = None) -> None:
		'''
		Adapter path: pass BMesh/Mesh items, get highlight drawing.
		Use 'outline=False' to skip face outlines for this call.
		If outline is None, uses the layer's default policy.
		'''

		if matrix_world is None:
			matrix_world = mathutils.Matrix.Identity(4)

		use_outline = self._outline_faces if outline is None else outline
		reqs = requests_from_iterable(items, matrix_world, outline=use_outline)
		self.set_from_requests(reqs)

	def apply_element_style(self, style: ElementStyle) -> None:
		'''
		Resolve a compound ElementStyle into per-primitive DrawStyles,
		apply them to this layer, and adopt its outline policy.
		'''

		points, lines, tris = style.to_draw_styles()
		self.set_styles(points=points, lines=lines, tris=tris)
		self._outline_faces = bool(style.outline)

	def set_object_fill_fast(self, obj: bpy.types.Object, *, overlay: bool = True, color: RGBA | None = None) -> None:
		'''
		Highlight an entire mesh by drawing all loop triangles in object space
		and letting the GPU apply matrix_world. No silhouette math, no per-vertex
		CPU transforms each frame.
		'''
		
		if not obj or not isinstance(getattr(obj, 'data', None), bpy.types.Mesh):
			self.clear()
			return
		
		mesh: bpy.types.Mesh = obj.data
		verts_obj, tri_idx = get_mesh_tris_objspace(mesh)
		
		geo = Geometry()
		geo.set_positions(verts_obj)      # object-space verts
		geo.set_indices(tri_idx)          # loop triangles
		
		self.tris.set_geometry(geo)
		self.tris.model_matrix = obj.matrix_world  # GPU does the transform
		
		# optional style tweaks: overlay + color
		style = self.tris.style
		if overlay:
			style = style.with_(depth_test=False, blend=True)
		if color is not None:
			style = style.with_(color=color)
		
		# style.blend = False
		
		gpu.state.face_culling_set('BACK')
		
		self.tris.set_style(style)
		
		# ensure other buckets are empty
		self.points.set_geometry(Geometry())
		self.lines.set_geometry(Geometry())
		gpu.state.face_culling_set('NONE')


# OPTIONAL: RAYCAST ADAPTER _____________________________________

def requests_from_raycast_result(hit: datatypes.Raycast) -> list[DrawRequest]:
	'''
	Adapt a Raycast (your datatypes module) into draw requests.
	Assumes hit.co is in world space or hit.matrix is provided for transform.
	'''

	reqs: list[DrawRequest] = []
	if not getattr(hit, 'hit', False):
		return reqs

	# point at hit
	if getattr(hit, 'co', None) is not None:
		reqs.append(DrawRequest(kind='points', coords_world=[hit.co], indices=None))

	# face highlight if available (MeshPolygon by index)
	obj = getattr(hit, 'obj', None)
	deps = getattr(hit, 'obj_eval', None)  # optional evaluated object
	face_index = getattr(hit, 'face_index', None)

	if obj and isinstance(face_index, int) and face_index >= 0:
		source_obj = deps if deps else obj
		mesh = source_obj.data
		if isinstance(mesh, bpy.types.Mesh) and face_index < len(mesh.polygons):
			poly = mesh.polygons[face_index]
			fill_req, outline_req = request_from_meshpolygon(poly, source_obj.matrix_world, outline=True)
			reqs.append(fill_req)
			if outline_req:
				reqs.append(outline_req)

	return reqs


# DEBUG STYLES __________________________________________________

def debug_element_style_overlay() -> ElementStyle:
	'''
	Bright debug palette (overlay).
	Yellow points, red edges, blue translucent faces.
	Always drawn on top of the scene.
	'''
	
	return ElementStyle(
		color=None,
		point_color =(0.2, 1.0, 0.2, 1.0),
		line_color =(1.0, 0.5, 0.0, 1.0),
		poly_color =(0.2, 0.3, 1.0, 1.0),
		point_size=8.0,
		line_width=3.0,
		face_opacity=0.4,
		depth_test=False,
		outline=True,
	)


def debug_element_style_depth() -> ElementStyle:
	'''
	Same debug palette as overlay, but depth-tested so it occludes naturally.
	'''

	return debug_element_style_overlay.with_(depth_test=True)
	

class ShapeTracer:
	'''
	Stateless 2D shape drawing helpers.
	All methods are static.
	'''

	# ------------------------------------------------------------
	# Internal Helpers
	# ------------------------------------------------------------

	@staticmethod
	def _bind_polyline_shader(context, color, line_width):
		shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
		shader.bind()
		shader.uniform_float('color', color)
		shader.uniform_float('lineWidth', line_width)
		shader.uniform_float(
			'viewportSize',
			(context.area.width, context.area.height),
		)
		return shader

	@staticmethod
	def _draw_batch(shader, primitive, coords, indices=None):
		gpu.state.blend_set('ALPHA')
		gpu.state.depth_test_set('NONE')

		if indices:
			batch = gpu_batch.batch_for_shader(
				shader,
				primitive,
				{'pos': coords},
				indices=indices,
			)
		else:
			batch = gpu_batch.batch_for_shader(
				shader,
				primitive,
				{'pos': coords},
			)

		batch.draw(shader)

		gpu.state.blend_set('NONE')

	# ------------------------------------------------------------
	# Shapes
	# ------------------------------------------------------------

	@staticmethod
	def draw_circle(
		context,
		center,
		radius=10.0,
		segments=32,
		color=(1, 1, 1, 1),
		line_width=3.0,
	):
		if center is None:
			return

		cx, cy = center
		seg = max(4, min(int(segments), 128))

		verts = []
		step = (2.0 * math.pi) / seg

		for i in range(seg + 1):
			theta = i * step
			verts.append((
				cx + math.cos(theta) * radius,
				cy + math.sin(theta) * radius,
				0.0,
			))

		shader = ShapeTracer._bind_polyline_shader(context, color, line_width)
		ShapeTracer._draw_batch(shader, 'LINE_STRIP', verts)

	# ------------------------------------------------------------

	@staticmethod
	def draw_square(
		context,
		center: mathutils.Vector,
		radius=12,
		angle_deg=0.0,
		color=(1, 1, 1, 1),
		line_width=3.0,
	):
		if center is None:
			return

		def extend_line(p1, p2):
			dir_vec = p2 - p1
			if dir_vec.length == 0:
				return p1, p2
			n = dir_vec.normalized()
			offset = n * (line_width * 0.5)
			return p1 - offset, p2 + offset

		R = mathutils.Matrix.Rotation(math.radians(angle_deg), 2)
		center3 = mathutils.Vector((center.x, center.y, 0.0))

		base = [
			(-radius,  radius),
			( radius,  radius),
			( radius, -radius),
			(-radius, -radius),
		]

		corners = []
		for ox, oy in base:
			v2 = R @ mathutils.Vector((ox, oy))
			corners.append(center3 + mathutils.Vector((v2.x, v2.y, 0.0)))

		coords = []
		for i in range(4):
			p1, p2 = extend_line(corners[i], corners[(i + 1) % 4])
			coords.extend([p1, p2])

		indices = [(i, i + 1) for i in range(0, 8, 2)]

		shader = ShapeTracer._bind_polyline_shader(context, color, line_width)
		ShapeTracer._draw_batch(shader, 'LINES', coords, indices)

	# ------------------------------------------------------------

	@staticmethod
	def draw_square_gap(
		context,
		center: mathutils.Vector,
		radius=14,
		gap_ratio=0.4,
		color=(1, 1, 1, 1),
		line_width=3.0,
	):
		if center is None:
			return

		diameter = radius * 2
		gap_length = diameter * gap_ratio
		half_gap = gap_length * 0.5
		outer_offset = line_width * 0.5

		corners = [
			center + mathutils.Vector((-radius,  radius)),
			center + mathutils.Vector(( radius,  radius)),
			center + mathutils.Vector(( radius, -radius)),
			center + mathutils.Vector((-radius, -radius)),
		]

		coords = []
		indices = []
		idx = 0

		for i in range(4):
			start = corners[i]
			end = corners[(i + 1) % 4]

			edge = end - start
			if edge.length == 0:
				continue

			n = edge.normalized()
			half = edge.length * 0.5

			p1 = start
			p2 = start + n * (half - half_gap)
			p3 = end - n * (half - half_gap)
			p4 = end

			ext_p1 = p1 - n * outer_offset
			ext_p4 = p4 + n * outer_offset

			coords.extend([ext_p1, p2])
			indices.append((idx, idx + 1))
			idx += 2

			coords.extend([p3, ext_p4])
			indices.append((idx, idx + 1))
			idx += 2

		shader = ShapeTracer._bind_polyline_shader(context, color, line_width)
		ShapeTracer._draw_batch(shader, 'LINES', coords, indices)

	# ------------------------------------------------------------

	@staticmethod
	def draw_angled_crosshairs_gap(
		context,
		center: mathutils.Vector,
		gap_radius,
		line_length,
		color=(1, 1, 1, 1),
		line_width=3.0,
	):
		if center is None:
			return

		diag_gap = gap_radius * math.sqrt(2)
		outer_offset = line_width * 0.5

		directions = [
			mathutils.Vector(( 1,  1)),
			mathutils.Vector((-1,  1)),
			mathutils.Vector((-1, -1)),
			mathutils.Vector(( 1, -1)),
		]

		coords = []

		for d in directions:
			n = d.normalized()
			start = center + n * diag_gap
			end = center + n * (diag_gap + line_length)

			p1 = start - n * outer_offset
			p2 = end + n * outer_offset

			coords.extend([p1, p2])

		indices = [(i, i + 1) for i in range(0, len(coords), 2)]

		shader = ShapeTracer._bind_polyline_shader(context, color, line_width)
		ShapeTracer._draw_batch(shader, 'LINES', coords, indices)

	# ------------------------------------------------------------

	@staticmethod
	def draw_x_into_square_gap(
		context,
		center: mathutils.Vector,
		square_radius=12.0,
		gap_ratio=0.5,
		color=(1, 1, 1, 1),
		line_width=3.0,
	):
		if center is None or gap_ratio >= 1.0:
			return

		diag = square_radius * math.sqrt(2)
		start_dist = diag
		end_dist = diag * gap_ratio
		outer_offset = line_width * 0.5

		directions = [
			mathutils.Vector(( 1,  1)),
			mathutils.Vector((-1,  1)),
			mathutils.Vector((-1, -1)),
			mathutils.Vector(( 1, -1)),
		]

		coords = []

		for d in directions:
			n = d.normalized()
			start = center + n * start_dist
			end = center + n * end_dist

			p1 = start - n * outer_offset
			p2 = end + n * outer_offset

			coords.extend([p1, p2])

		indices = [(i, i + 1) for i in range(0, len(coords), 2)]

		shader = ShapeTracer._bind_polyline_shader(context, color, line_width)
		ShapeTracer._draw_batch(shader, 'LINES', coords, indices)