# release_check.py
import bpy
import urllib.request
import tomllib
import traceback
import hashlib
import time
import threading
import dataclasses
import pathlib

GITHUB_OWNER = 'ArmoredColony'
MANIFESTS_REPO = 'extension-manifests'
MANIFEST_FILENAME = 'blender_manifest.toml'
BRANCH_CANDIDATES = ['master', 'main']
NETWORK_TIMEOUT_SECONDS = 3.0
FETCH_ADAPTER = None  # set to a callable for tests; default None


def _log(message: str) -> None:
	print(f'[release_check] {message}')


def _log_exception(context: str) -> None:
	print(f'[release_check] {context}\n{traceback.format_exc()}')


def _releases_folder_name() -> str:
	# Mirror your extension and github manifest repo folder name 1:1 
	# eg: 'PixiePivot' and not 'bl_ext.Extensions.PixiePivot'
	return __package__.split('.')[2]


def _make_raw_file_url(branch: str, filename: str) -> str:
	folder = _releases_folder_name()
	return f'https://raw.githubusercontent.com/{GITHUB_OWNER}/{MANIFESTS_REPO}/{branch}/{folder}/{filename}'\


def make_changelog_url(branch: str = 'master', filename: str = 'changelog.md') -> str:
	folder = _releases_folder_name()
	return f'https://github.com/{GITHUB_OWNER}/{MANIFESTS_REPO}/blob/{branch}/{folder}/{filename}'


def _current_version_tuple() -> tuple[int, ...] | None:
    try:
        package_root = pathlib.Path(__file__).resolve().parents[2]
        manifest_path = package_root / MANIFEST_FILENAME

        with open(manifest_path, "rb") as f:
            data = tomllib.load(f)

        version_str = data.get("version", "")
        return _parse_version_string(version_str)

    except Exception as e:
        _log(f"Failed to read manifest: {e}")
        return None


def _parse_version_string(text: str) -> tuple[int, ...]:
	'''
	Take '1.0.0-RC1' and discard everything after the 
	first non-numeric character, returning a tuple.
	'''

	assert isinstance(text, str), 'Non-strings should NOT bet allowed here'
	
	s = (text or '').strip()

	out = []
	for part in s.split('.'):
		if not part:
			continue

		try:
			out.append(int(part))
		except ValueError:
			break   # stop at first non-numeric segment like 'rc1'

	return tuple(out)


def _strip_trailing_zeros(version: tuple[int, ...]) -> tuple[int, ...]:
	'''
	Remove trailing zeros so versions (1, 2) and (1, 2, 0) are equal.
	'''

	assert isinstance(version, tuple), 'Only tuples of int are allowed here'
	
	version = list(version)
	while version and version[-1] == 0:	# while last element is 0 (zero) → remove it
		version.pop()

	return tuple(version)


def _is_a_newer_than_b(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
	'''
	Newer == bigger tuple.
	'''
	
	return _strip_trailing_zeros(a) > _strip_trailing_zeros(b)


def _fetch_release_toml() -> tuple[dict, str, str]:
	'''
	Download and parse TOML. Returns (parsed_dict, used_url, snippet_str).
	On failure, raises RuntimeError with aggregated details.
	'''

	errors: list[tuple[str, str]] = []

	for branch in BRANCH_CANDATES if (BRANCH_CANDATES := BRANCH_CANDIDATES) else BRANCH_CANDIDATES:
		url = _make_raw_file_url(branch, filename=MANIFEST_FILENAME)
		try:
			_log(f'Trying: {url}')
			req = urllib.request.Request(url, headers={'User-Agent': f'{__package__} release-check'})
			with urllib.request.urlopen(req, timeout=NETWORK_TIMEOUT_SECONDS) as resp:
				raw_bytes = resp.read()

			# Log basic facts about the download
			sha = hashlib.sha256(raw_bytes).hexdigest()[:8]
			snippet = raw_bytes[:200].decode('utf-8', errors='replace').replace('\n', '\\n')
			_log(f'Download OK: bytes={len(raw_bytes)}, sha256={sha}, snippet="{snippet}"')

			# Decode to TEXT for tomllib.loads (Python 3.11 expects str)
			text = raw_bytes.decode('utf-8', errors='strict')
			data = tomllib.loads(text)
			_log('Parse OK')

			return data, url, snippet  # success: stop trying other branches

		except Exception as e:
			errors.append((url, f'{type(e).__name__}: {e!s}'))
			_log_exception(f'failed on {url}')

	# If none worked, raise a consolidated error
	details = '\n'.join(f'  - {url} -> {error}' for url, error in errors)
	raise RuntimeError(f'All raw URLs failed:\n{details}')


# def _get_latest_section(data: dict) -> dict:
# 	'''
# 	Helper to safely retrieve the [latest] table as a dict (or empty dict).
# 	'''

# 	if not isinstance(data, dict):
# 		return {}
	
# 	latest = data.get('latest')
# 	return latest if isinstance(latest, dict) else {}


def _extract_latest_payload(data: dict) -> tuple[dict, dict]:
	'''
	Extract version info from a Blender extension manifest.
	'''

	if not isinstance(data, dict):
		return {}, {}

	payload: dict = {}

	ver_str = str(data.get('version', '')).strip()

	payload['latest_version_string'] = ver_str
	payload['latest_version_tuple'] = (
		_parse_version_string(ver_str) if ver_str else ()
	)

	# You *could* also extract blender_version_min if you ever want:
	# min_blender = str(data.get('blender_version_min', '')).strip()
	# payload['blender_version_min_string'] = min_blender
	# payload['blender_version_min_tuple'] = (
	#	_parse_version_string(min_blender) if min_blender else ()
	# )

	return payload, dict(data)


# ───────────────────────────────────────────────────────────────────────────────
# Models: local + status; remote is a dict for easy extension
# ───────────────────────────────────────────────────────────────────────────────


@dataclasses.dataclass
class LocalVersion:
	current_version_tuple: tuple[int, ...] = ()
	current_version_string: str = ''


@dataclasses.dataclass
class FetchState:
	has_fetched: bool = False
	fetch_in_progress: bool = False
	error_message: str = ''


@dataclasses.dataclass
class ReleaseState:
	fetch: FetchState = dataclasses.field(default_factory=FetchState)
	local: LocalVersion = dataclasses.field(default_factory=LocalVersion)
	latest: dict = dataclasses.field(default_factory=dict)      # normalized
	latest_raw: dict = dataclasses.field(default_factory=dict)  # verbatim


_state = ReleaseState()


# background-thread handoff storage
_fetch_thread: threading.Thread | None = None
_pending_result: dict | None = None   # normalized payload from thread
_pending_raw: dict | None = None      # raw latest table from thread
_pending_error: str | None = None


# ───────────────────────────────────────────────────────────────────────────────
# Transition helpers (single source of truth)
# ───────────────────────────────────────────────────────────────────────────────

def _reset_remote_payload() -> None:
	_state.latest.clear()
	_state.latest_raw.clear()
	_state.fetch.error_message = ''


def _state_begin_fetch() -> None:
	_state.fetch.fetch_in_progress = True
	_state.fetch.has_fetched = False
	_reset_remote_payload()

def _state_apply_success(payload: dict, raw_latest: dict) -> None:
	# normalized payload merged in one shot
	_state.latest.update(payload)
	_state.latest_raw = raw_latest or {}

	# refresh local only once per fetch
	cur = _current_version_tuple()
	_state.local.current_version_tuple = cur
	_state.local.current_version_string = '.'.join(map(str, cur)) if cur else None


def _state_apply_error(msg: str) -> None:
	_reset_remote_payload()
	_state.fetch.error_message = msg or 'release fetch failed'


def _state_end_fetch() -> None:
	_state.fetch.fetch_in_progress = False
	_state.fetch.has_fetched = True


# Derived (compute, don't store)
def has_latest_version_info() -> bool:
	return bool(_state.latest.get('latest_version_tuple'))


def update_available() -> bool:
	latest_tuple = _state.latest.get('latest_version_tuple')
	current_tuple = _state.local.current_version_tuple

	if not latest_tuple or not current_tuple:
		_log('Failed to get version tuples for comparison')
		return False

	return _is_a_newer_than_b(latest_tuple, current_tuple)
	

# ───────────────────────────────────────────────────────────────────────────────
# Threading (network in thread; apply on main thread)
# ───────────────────────────────────────────────────────────────────────────────

def _thread_fetch_body():
	global _pending_result, _pending_error, _pending_raw
	try:
		fetch = FETCH_ADAPTER or _fetch_release_toml
		data, used_url, _ = fetch()
		_log(f'Loaded: {used_url}')

		payload, raw_latest = _extract_latest_payload(data)

		_pending_result = payload
		_pending_raw = raw_latest
		_pending_error = ''
	except Exception:
		_pending_result = None
		_pending_raw = None
		_pending_error = 'release fetch failed (see console)'
		_log_exception('fetch failed')


def blender_in_background_mode() -> bool:
	'''
	Return True if Blender is running in background/headless mode.
	'''
	if bpy.app.background:
		_log('Skip release check in background mode')
		return True
	
	return False


def _start_fetch_thread():
	if blender_in_background_mode():
		return None
	
	global _fetch_thread, _pending_result, _pending_error, _pending_raw

	if _state.fetch.fetch_in_progress:
		return
	
	_pending_result = None
	_pending_raw = None
	_pending_error = None
	_state_begin_fetch()

	_fetch_thread = threading.Thread(target=_thread_fetch_body, daemon=True)
	_fetch_thread.start()


def _poll_fetch():
	global _fetch_thread, _pending_result, _pending_error, _pending_raw

	# not done yet → keep polling
	if _pending_result is None and _pending_error is None:
		return 0.2  # 200ms

	# apply outcome
	if _pending_error:
		_state_apply_error(_pending_error)
	else:
		_state_apply_success(_pending_result or {}, _pending_raw or {})

		# Console notice (only when there IS an update)
		if update_available() and not bpy.app.background:
			print(f'PIXIE PIVOT → Update Available')

	_state_end_fetch()
	_tag_preferences_redraw()

	# cleanup & stop polling
	_fetch_thread = None
	_pending_result = None
	_pending_raw = None
	_pending_error = None

	return None


def _do_fetch_once():
	if blender_in_background_mode():
		return None
	
	if _state.fetch.has_fetched or _state.fetch.fetch_in_progress:
		return None  # stop timer

	# kick off background fetch (non-blocking) and start polling
	_start_fetch_thread()
	bpy.app.timers.register(_poll_fetch, first_interval=0.0)

	return None  # stop this one-shot timer


def force_fetch_now() -> None:
	if blender_in_background_mode():
		return None
	
	# Kick a fresh non-blocking fetch
	_start_fetch_thread()
	bpy.app.timers.register(_poll_fetch, first_interval=0.0)


def _fake_success_slow():
	delay_seconds = 5
	print(f'Faking slow network success → sleeping for {delay_seconds}s')
	time.sleep(delay_seconds)  # simulate slow network
	text = b'[latest]\nversion = "9.9.9"\nchanges = ["test A","test B"]\n'
	data = tomllib.loads(text.decode('utf-8'))
	return data, 'fake://success', 'fake snippet'


def _fake_failure_slow():
	delay_seconds = 5
	print(f'Faking slow network failure → sleeping for {delay_seconds}s')
	time.sleep(delay_seconds)
	raise RuntimeError('Simulated Failure')


def _tag_preferences_redraw() -> None:
	try:
		wm = bpy.context.window_manager
		if not wm:
			return
		for window in wm.windows:
			screen = window.screen
			if not screen:
				continue
			for area in screen.areas:
				if area.type == 'PREFERENCES':
					area.tag_redraw()
					# Extra-safe: also tag regions
					for region in area.regions:
						region.tag_redraw()
	except Exception as e:
		_log_exception(f'preferences redraw tag failed {e}')


def schedule_initial_fetch(first_interval: float = 0.5) -> None:
	if blender_in_background_mode():
		return None

	def _runner():
		return _do_fetch_once()
	
	bpy.app.timers.register(_runner, first_interval=first_interval)


def get_release_state() -> dict:
	'''
	Nested shape:
	{
		fetch		# lifecycle & errors
		local		# current installed version (tuple/string)
		remote		# normalized remote fields (whatever _extract_latest_payload put there)
		remote_raw	# full [latest] table from TOML (verbatim)
		derived {
			"has_latest_version_info": bool,
			"update_available": bool
		}
	}
	'''

	return {
		'fetch': dataclasses.asdict(_state.fetch),
		'local': dataclasses.asdict(_state.local),
		'latest': dict(_state.latest),
		'latest_raw': dict(_state.latest_raw),
		'derived': {
			'has_latest_version_info': has_latest_version_info(),
			'update_available': update_available(),
		},
	}
