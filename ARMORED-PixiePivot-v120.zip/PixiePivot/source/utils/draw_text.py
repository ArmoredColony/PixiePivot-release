import blf
import dataclasses
import mathutils
import typing

from . import datatypes


# TYPE ALIASES __________________________________________________

RGB  = tuple[float, float, float]
RGBA = tuple[float, float, float, float]


# DATACLASSES  __________________________________________________

@dataclasses.dataclass
class TextDimensions:
	width: float
	height: float


@dataclasses.dataclass
class TextBounds:
	width:  float
	height: float
	left:   float
	right:  float
	top:    float
	bottom: float



# ───────────────────────────────────────────────
# Justification Strategies
# ───────────────────────────────────────────────

class HorizontalJustify(typing.Protocol):
	def offset_x(self, width: float) -> float: ...


class VerticalJustify(typing.Protocol):
	def offset_y(self, height: float) -> float: ...


@dataclasses.dataclass
class Left(HorizontalJustify):
	def offset_x(self, width: float) -> float:
		return 0


@dataclasses.dataclass
class CenterH(HorizontalJustify):
	def offset_x(self, width: float) -> float:
		return -width / 2


@dataclasses.dataclass
class Right(HorizontalJustify):
	def offset_x(self, width: float) -> float:
		return -width


@dataclasses.dataclass
class Bottom(VerticalJustify):
	def offset_y(self, height: float) -> float:
		return 0


@dataclasses.dataclass
class CenterV(VerticalJustify):
	def offset_y(self, height: float) -> float:
		return -height / 2


@dataclasses.dataclass
class Top(VerticalJustify):
	def offset_y(self, height: float) -> float:
		return -height


# ───────────────────────────────────────────────
# Shared Text Arguments
# ───────────────────────────────────────────────

@dataclasses.dataclass
class TextArgs:
	text: str
	coords: tuple[int, int] = (0, 0)
	offset: tuple[int, int] = (0, 0)
	color: tuple[float, float, float, float] = (1, 1, 1, 1)
	shadow: bool = True
	shadow_color: tuple[float, float, float, float] = (0, 0, 0, 1)
	font_id: int = 0
	font_size: int = 14
	scale: float = 1.0
	dim_sample: typing.Optional[str] = None


@dataclasses.dataclass
class JustifyArgs:
	h_justify: HorizontalJustify = dataclasses.field(default_factory=Left)
	v_justify: VerticalJustify   = dataclasses.field(default_factory=Bottom)


# ───────────────────────────────────────────────
# Drawing Logic
# ───────────────────────────────────────────────

@dataclasses.dataclass
class TextDimensions:
	width: float
	height: float


def _srgb_to_linear(c: float) -> float:
	# sRGB → linear
	if c <= 0.04045:
			return c / 12.92
	return ((c + 0.055) / 1.055) ** 2.4

def _normalize_rgb(color) -> tuple[float, float, float, float]:
	# Accept mathutils.Color, RGB/RGBA tuples, 0–1 or 0–255
	if isinstance(color, mathutils.Color):
			r, g, b = color.r, color.g, color.b
			a = 1.0
	else:
			seq = tuple(color)
			if len(seq) < 3:
					raise ValueError('color must have at least 3 components')
			r, g, b = float(seq[0]), float(seq[1]), float(seq[2])
			a = float(seq[3]) if len(seq) >= 4 else 1.0
	if r > 1.0 or g > 1.0 or b > 1.0 or a > 1.0:
			r, g, b, a = r / 255.0, g / 255.0, b / 255.0, a / 255.0
	# Clamp defensively
	r = max(0.0, min(1.0, r))
	g = max(0.0, min(1.0, g))
	b = max(0.0, min(1.0, b))
	a = max(0.0, min(1.0, a))
	return r, g, b, a

def relative_luminance_srgb(color) -> float:
	r, g, b, _a = _normalize_rgb(color)
	R = _srgb_to_linear(r)
	G = _srgb_to_linear(g)
	B = _srgb_to_linear(b)
	return 0.2126 * R + 0.7152 * G + 0.0722 * B


def contrast_ratio(luminance_a: float, luminance_b: float) -> float:
	'''
	WCAG contrast ratio between two luminance values.
	'''

	lighter = max(luminance_a, luminance_b)
	darker = min(luminance_a, luminance_b)
	
	return (lighter + 0.05) / (darker + 0.05)


def choose_bw_for_background(
	background_color,
	min_contrast: float = 4.5,
	prefer_black_bias: float = 0.0,
) -> tuple[float, float, float, float]:
	'''
	Choose black or white text based on contrast.

	min_contrast:
		Minimum acceptable contrast ratio (4.5 is WCAG AA for normal text).
		Lower = more permissive.

	prefer_black_bias:
		Positive values slightly favor black.
		Negative values slightly favor white.
		0.0 = neutral.
	'''

	background_luminance = relative_luminance_srgb(background_color)

	white_luminance = 1.0
	black_luminance = 0.0

	contrast_with_white = contrast_ratio(background_luminance, white_luminance)
	contrast_with_black = contrast_ratio(background_luminance, black_luminance)

	# Apply optional bias (small nudge, not brute force)
	contrast_with_black += prefer_black_bias

	# If one clearly satisfies minimum contrast and the other doesn't, choose it
	if contrast_with_black >= min_contrast and contrast_with_white < min_contrast:
		return 0.0, 0.0, 0.0, 1.0

	if contrast_with_white >= min_contrast and contrast_with_black < min_contrast:
		return 1.0, 1.0, 1.0, 1.0

	# Otherwise choose whichever has stronger contrast
	if contrast_with_black > contrast_with_white:
		return 0.0, 0.0, 0.0, 1.0

	return 1.0, 1.0, 1.0, 1.0

def is_near_black(color, lum_threshold: float = 0.05) -> bool:
	'''
	Returns True if perceived luminance is low enough to consider "near black".
	Default ~0.05 is conservative; tweak 0.03–0.06 to taste.
	'''
	L = relative_luminance_srgb(color)
	return L <= lum_threshold


def draw_text(text_args: TextArgs, justify_args: JustifyArgs) -> TextDimensions:
	coords = mathutils.Vector(text_args.coords)
	offset = mathutils.Vector(text_args.offset)

	# Apply scaled font size
	scaled_font_size = int(text_args.font_size * text_args.scale)
	blf.size(text_args.font_id, scaled_font_size)
	blf.color(text_args.font_id, *text_args.color)

	# Use sample with descender for vertical alignment
	sample_text = text_args.dim_sample or 'Ag'

	text_width, _ = blf.dimensions(text_args.font_id, text_args.text)
	_, text_height = blf.dimensions(text_args.font_id, sample_text)

	# Justification offsets are already in scaled space — don't re-scale them
	x_shift = justify_args.h_justify.offset_x(text_width)
	y_shift = justify_args.v_justify.offset_y(text_height)

	adjusted = coords + offset + mathutils.Vector((x_shift, y_shift))

	# Final draw position
	blf.position(text_args.font_id, adjusted.x, adjusted.y, 1)

	if text_args.shadow and not is_near_black(text_args.color):
		shadow_blur = 6
		shadow_offset = 0
		# shadow_offset = max(1, int(text_args.scale * text_args.font_size / 15))
		blf.enable(text_args.font_id, blf.SHADOW)
		blf.shadow(text_args.font_id, shadow_blur, *text_args.shadow_color)
		blf.shadow_offset(text_args.font_id, shadow_offset, -shadow_offset)
	# else:
		# shadow_blur = 0
		# shadow_offset = 0


	blf.draw(text_args.font_id, text_args.text)

	if text_args.shadow:
		blf.disable(text_args.font_id, blf.SHADOW)

	return TextDimensions(
		width=text_width,
		height=text_height,
	)


def draw_text_center_center(**kwargs) -> TextDimensions:
	return draw_text(
		TextArgs(**kwargs),
		JustifyArgs(
			h_justify=CenterH(),
			v_justify=CenterV(),
		)
	)


def draw_text_center_top(**kwargs) -> TextDimensions:
	return draw_text(
		TextArgs(**kwargs),
		JustifyArgs(
			h_justify=CenterH(),
			v_justify=Top(),
		)
	)


def draw_text_center_bottom(**kwargs) -> TextDimensions:
	return draw_text(
		TextArgs(**kwargs),
		JustifyArgs(
			h_justify=CenterH(),
			v_justify=Bottom(),
		)
	)


def draw_text_left_bottom(**kwargs) -> TextDimensions:
	return draw_text(
		TextArgs(**kwargs),
		JustifyArgs(
			h_justify=CenterH(),
			v_justify=Bottom(),
		)
	)


def draw_text_right_bottom(**kwargs) -> TextDimensions:
	return draw_text(
		TextArgs(**kwargs),
		JustifyArgs(
			h_justify=CenterH(),
			v_justify=Bottom(),
		)
	)


def _draw_hud_row(
	prop: datatypes.HUDProperty,
	region,
	position: str,
	offset: tuple[int, int],
	row_idx: int,
	padding: tuple[int, int],
	field_colors: tuple[RGBA, RGBA, RGBA, RGBA],
	field_font_sizes: tuple[int, int, int, int],
	font_id: int,
	scale: float,
	col_widths: tuple[float, float, float, float],
	shadow: RGBA = (0, 0, 0, 1),
):
	'''
	Draw one datatypes.HUDProperty row using four column widths:
	  col_widths = (name_w, value_w, hotkey_w, modifier_w).
	'''

	# 1) Compute line height (max of all four font sizes)
	line_heights = []
	for fs in field_font_sizes:
		blf.size(font_id, int(fs * scale))
		_, h = blf.dimensions(font_id, 'Ag')
		line_heights.append(h)
	line_h = max(line_heights)

	# 2) Total row width (4 cols + 3 gaps)
	total_w = sum(col_widths) + (padding[0] * scale) * 3

	# 3) Determine start_x
	if position == 'BOTTOM_RIGHT':
		start_x = region.width - total_w - offset[0]
	elif position == 'BOTTOM_CENTER':
		start_x = (region.width - total_w) / 2 + offset[0]
	else:  # bottom_left
		start_x = offset[0]

	# 4) Compute Y
	# row_y = region.y + offset[1] + row_idx * (line_h + padding[1] * scale)
	row_y = offset[1] + row_idx * (line_h + padding[1] * scale)

	# 5) Draw name
	args = TextArgs(
		text=prop.name,
		coords=(start_x, row_y),
		color=field_colors[0],
		font_id=font_id,
		font_size=field_font_sizes[0],
		scale=scale,
		shadow=shadow,
	)
	draw_text(args, JustifyArgs())

	# 6) Draw value
	val_x = start_x + col_widths[0] + padding[0] * scale
	args = TextArgs(
		text=str(prop.value) if prop.value != '' else '',
		coords=(val_x, row_y),
		color=field_colors[1] if prop.value else (0.7, 0.7, 0.7, 1.0),
		font_id=font_id,
		font_size=field_font_sizes[1],
		scale=scale,
		shadow=shadow,
	)
	draw_text(args, JustifyArgs())

	# 7) Draw hotkey (3rd col)
	hot_x = val_x + col_widths[1] + padding[0] * scale
	args = TextArgs(
		text=prop.hotkey or '',
		coords=(hot_x, row_y),
		color=field_colors[2],
		font_id=font_id,
		font_size=field_font_sizes[2],
		scale=scale,
		shadow=shadow,
	)
	draw_text(args, JustifyArgs())

	# 8) Draw modifier (4th col)
	mod_x = hot_x + col_widths[2] + padding[0] * scale
	args = TextArgs(
		text=prop.modifier or '',
		coords=(mod_x, row_y),
		color=field_colors[3],
		font_id=font_id,
		font_size=field_font_sizes[3],
		scale=scale,
		shadow=shadow,
	)
	draw_text(args, JustifyArgs())


def draw_fixed_hud(
	props_list: list[datatypes.HUDProperty],
	region,
	position: str = 'BOTTOM_CENTER',
	offset: tuple[int, int] = (80, 40),
	padding: tuple[int, int] = (20, 6),
	field_colors: tuple[RGBA, RGBA, RGBA, RGBA] = (
		(1, 1, 1, 1),
		(1, 1, 1, 1),
		(1, 1, 1, 1),
		(1, 1, 1, 1),
	),
	field_font_sizes: tuple[int, int, int, int] = (16, 16, 12, 12),
	font_id: int = 0,
	scale: float = 1.0,
	col_widths: tuple[float, float, float, float] | None = None,
	shadow: RGBA = (0, 0, 0, 1),
):
	'''
	Draw each datatypes.HUDProperty row using manual column widths:
	  col_widths = (name_w, value_w, hotkey_w, modifier_w).
	If col_widths is None, they are computed from content.
	'''

	# Auto-compute widths if none provided
	if col_widths is None:
		max_name_w = 0.0
		max_val_w = 0.0
		max_hot_w = 0.0
		max_mod_w = 0.0

		for hud_prop in props_list:
			name_w = get_text_width(hud_prop.name or '', font_id, field_font_sizes[0], scale)
			if name_w > max_name_w:
				max_name_w = name_w

			val_txt = str(hud_prop.value) if hud_prop.value != '' else ''
			val_w = get_text_width(val_txt, font_id, field_font_sizes[1], scale)
			if val_w > max_val_w:
				max_val_w = val_w

			hot_w = get_text_width(hud_prop.hotkey or '', font_id, field_font_sizes[2], scale)
			if hot_w > max_hot_w:
				max_hot_w = hot_w

			mod_w = get_text_width(hud_prop.modifier or '', font_id, field_font_sizes[3], scale)
			if mod_w > max_mod_w:
				max_mod_w = mod_w

		col_widths = (max_name_w, max_val_w, max_hot_w, max_mod_w)
	else:
		# Ensure it's exactly 4 columns
		if len(col_widths) != 4:
			raise ValueError('col_widths must be a 4-tuple: (name, value, hotkey, modifier)')

	max_name_width = 0.0 
	for hud_prop in props_list: 
		width = get_text_width(hud_prop.name, font_id, field_font_sizes[0], scale) 
		if width > max_name_width: 
			max_name_width = width

	# HARDCODED VALUES
	max_val_width      = get_text_width('Cursor',	font_id, field_font_sizes[1], scale)
	max_hotkey_width   = get_text_width('C, O',	font_id, field_font_sizes[1], scale)
	max_modifier_width = get_text_width('SHIFT',	font_id, field_font_sizes[1], scale)

	col_widths = (
		max_name_width,
		max_val_width,
		max_hotkey_width,
		max_modifier_width
	)

	for idx, hud_prop in enumerate(props_list):
		_draw_hud_row(
			hud_prop,
			region,
			position,
			offset,
			idx,
			padding,
			field_colors,
			field_font_sizes,
			font_id,
			scale,
			col_widths,
			shadow,
		)


def get_text_width(text: str, font_id: int, font_size: int, scale: float = 1.0) -> float:
	'''
	Returns the horizontal BLF width of the given text string
	using the specified font ID, font size, and scale.
	'''
	blf.size(font_id, int(font_size * scale))
	width, _ = blf.dimensions(font_id, text or '')
	return width