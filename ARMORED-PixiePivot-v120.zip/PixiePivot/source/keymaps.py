import bpy
import rna_keymap_ui

from .. import EXTENSION_PACKAGE

# (km, kmi)
addon_keymaps = []


def draw_addon_keymaps(layout: bpy.types.UILayout) -> None:
	'''
	Iterate over addon_keymaps and draw each individual kmi.
	'''
	
	wm = bpy.context.window_manager

	kc_user = wm.keyconfigs.user
	if kc_user is None:
		layout.label(text='User keyconfig not available', icon='ERROR')
		return
	
	layout.label(text=f'Activation Keymaps:')
	layout.separator(factor=1)

	# Registry: list[tuple[addon_km, addon_kmi]]
	for addon_km, addon_kmi in addon_keymaps:

		# Resolve user keymap using addon keymap name
		km_user = kc_user.keymaps.get(addon_km.name)
		if km_user is None:
			layout.label(text=f'Keymap not found: {addon_km.name}', icon='ERROR')
			continue

		# Resolve user RNA keymap item using addon idname
		kmi_user = km_user.keymap_items.get(addon_kmi.idname)
		if kmi_user is None:
			layout.label(text=f'Keymap item missing: {addon_kmi.idname}', icon='ERROR')
			continue
		
		row = layout.row(align=True)
		draw_kmi(row, kc_user, km_user, kmi_user)
		layout.separator(factor=1)


def draw_kmi(
	layout: bpy.types.UILayout, 
	kc: bpy.types.KeyConfig, 
	km: bpy.types.KeyMap, 
	kmi: bpy.types.KeyMapItem, 
	simple: bool = False
) -> None:
	'''
	Draw a keymap item using user keyconfig RNA objects.
	'''

	if kmi is None:
		layout.label(text='Keymap item missing', icon='ERROR')
		return

	if simple:
		layout.prop(kmi, 'type', text='', full_event=True)
	else:
		# RNA UI helper used by Blender internal keymap drawing
		rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)


def ensure_keymap(keymap_name: str) -> bpy.types.KeyMap:
	'''
	Get or create addon keymap by category name.
	- eg. `'Object Mode'`, `'Mesh'`
	'''
		
	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon
	km = kc.keymaps.get(keymap_name)

	if km is None:
		km = kc.keymaps.new(name=keymap_name)

	return km


def create_kmi(km, idname, type, value, ctrl=False, alt=False, shift=False, *, active=True) -> bpy.types.KeyMapItem:
	'''
	Create a new Keymap Item.
	'''
	
	kmi = km.keymap_items.new(idname, type, value, ctrl=ctrl, alt=alt, shift=shift)

	kmi.active = active

	return kmi


def create_and_track_kmi(km, idname, type, value, ctrl=False, alt=False, shift=False, *, active=True) -> bpy.types.KeyMapItem:
	'''
	Create and append a new Keymap Item to the global addon_keymaps list.
	'''
	
	kmi = create_kmi(km, idname, type, value, ctrl=ctrl, alt=alt, shift=shift, active=active)
	addon_keymaps.append((km, kmi))

	return kmi


def recovery_handler(*args) -> None:
	mirror_addon_bindings_to_user_layer()

	# Self-remove handler after execution
	if recovery_handler in bpy.app.handlers.load_post:
		bpy.app.handlers.load_post.remove(recovery_handler)


def mirror_addon_bindings_to_user_layer() -> None:
	'''
	Remake missing user keymap items.
	'''
	
	wm = bpy.context.window_manager
	kc = wm.keyconfigs

	kc_user = kc.user

	if not kc_user:
		return

	for km, kmi_addon in addon_keymaps:
		km_user = kc_user.keymaps.get(km.name)

		if not km_user:
			km_user = kc_user.keymaps.new(
				name=km.name,
				space_type=km.space_type
			)

		kmi_user = km_user.keymap_items.find_from_operator(kmi_addon.idname)

		if kmi_user:
			continue

		create_kmi(
			km_user,
			kmi_addon.idname,
			kmi_addon.type,
			kmi_addon.value,
			ctrl=kmi_addon.ctrl,
			alt=kmi_addon.alt,
			shift=kmi_addon.shift,
			active=kmi_addon.active
		)

		print(f'{EXTENSION_PACKAGE} → Mirrored missing keymap: km[{km.name}] idname[{kmi_addon.idname}]')
			

def register() -> None:
	'''
	This sets the default value for the addon's activation keymap.
	The correct way to set-up your own keymaps is through the addon preferences.
	'''

	km = ensure_keymap('Object Mode')
	create_and_track_kmi(km, idname='object.armored_pixie_pivot', type='D', value='PRESS')

	km = ensure_keymap('Mesh')
	create_and_track_kmi(km, idname='mesh.armored_pixie_pivot', type='D', value='PRESS')
	
	bpy.app.handlers.load_post.append(recovery_handler)  # Auto removes itself


	# You can set a new permanent defaults by replacing the type 'D' with another CAPITAL letter between quotes ''.
	# You can also set any or multiple modifiers (shift, ctrl, alt) to True if you want to use those in 
	# combination with your key press.

	# Example (to activate with the Y key press): 
	# type='Y', value='PRESS'

	# Example (to activate with CTRL + SHIFT + M): 
	# type='M', value='PRESS', shift=True, ctrl=True

	# Here is a list of other keys you can assign (mouse buttons, numpad keys, etc):
	# https://docs.blender.org/api/current/bpy_types_enum_items/event_type_items.html


def unregister() -> None:
	for km, kmi in addon_keymaps:
		km.keymap_items.remove(kmi)

	addon_keymaps.clear()
