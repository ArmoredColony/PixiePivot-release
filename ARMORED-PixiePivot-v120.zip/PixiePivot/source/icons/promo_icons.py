import bpy.utils.previews
import os


# THIS SCRIPT AND THE PNG ICONS SHOULD BE IN THE SAME FOLDER
ICON_DIR = os.path.dirname(os.path.abspath(__file__))
preview_collections = {}


icon_names = [	# Without the PNG extension.
	'armored_colony32',
	'artstation32',
	'blender_market32',
	'github32',
	'gumroad32',
	'youtube32',
]


def register():
	pcoll = bpy.utils.previews.new()

	for icon_name in icon_names:
		pcoll.load(icon_name, os.path.join(ICON_DIR, f'{icon_name}.png'), 'IMAGE')

	preview_collections['web_icons'] = pcoll
	
	return preview_collections


def unregister():
	for pcoll in preview_collections.values():
		bpy.utils.previews.remove(pcoll)

	preview_collections.clear()


def draw(self, layout):
	'''
	Adds a centered row of clickable icon buttons that link to my online profiles and stores.
	Each button opens a website like ArtStation, GitHub, or YouTube in the user's browser.
	'''

	def url_button(row, url, icon):
		row.operator('wm.url_open', text='', icon_value=icon.icon_id).url = url
	
	col = layout.column(align=True)
	row = col.row(align=True)
	row.alignment = 'CENTER'
	row.scale_y = 1.5
	row.scale_x = 4.0	# Anything above 2.0 seems to stretch to fill the space.

	web_icons = preview_collections['web_icons']

	url_button(row, url='https://armoredColony.com',                        icon=web_icons['armored_colony32'])
	url_button(row, url='https://www.artstation.com/armoredcolony',         icon=web_icons['artstation32'])
	url_button(row, url='https://blendermarket.com/creators/armoredcolony', icon=web_icons['blender_market32'])

	url_button(row, url='https://github.com/ArmoredColony/ARMORED-Toolkit', icon=web_icons['github32'])
	url_button(row, url='https://armoredcolony.gumroad.com',                icon=web_icons['gumroad32'])
	url_button(row, url='https://www.youtube.com/armoredColony',            icon=web_icons['youtube32'])
