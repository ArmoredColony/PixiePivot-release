import bpy
import bmesh
import bmesh.ops
import dataclasses
import math
import mathutils
import string


from ..gizmos import gizmo_groups

from ..utils import addon
from ..utils import bmeshutils
from ..utils import datatypes as dtypes
from ..utils import debug
from ..utils import drawcore
from ..utils import draw_text
from ..utils import events
from ..utils import event_utils
from ..utils import pretty
from ..utils import raycast_utils
from ..utils import view3d

from ..runtime_state import runtime_state


# TYPE ALIASES __________________________________________________

RotationMatrix = mathutils.Matrix	# 3x3
TransformMatrix = mathutils.Matrix	# 4x4


# CONSTANTS __________________________________________________

NEAR_ZERO = 1e-6
MIN_SAFE_SCALE = 1e-6

AXES = ('X', 'Y', 'Z')

BASE_AXES = {
	'X': mathutils.Vector((1, 0, 0)),
	'Y': mathutils.Vector((0, 1, 0)),
	'Z': mathutils.Vector((0, 0, 1)),
}

BASE_COLUMNS = [
	BASE_AXES['X'],
	BASE_AXES['Y'],
	BASE_AXES['Z']
]

BASE_MATRIX = mathutils.Matrix(BASE_COLUMNS).transposed()


# HELPERS __________________________________________________

def vectors_are_similar(
	a: mathutils.Vector, b: mathutils.Vector, tolerance: float = NEAR_ZERO
) -> bool:
	return (a - b).length <= tolerance


def vectors_are_different(
	a: mathutils.Vector, b: mathutils.Vector, tolerance: float = NEAR_ZERO
) -> bool:
    return not vectors_are_similar(a, b, tolerance)


def rotations_differ(mat_a: mathutils.Matrix, mat_b: mathutils.Matrix, tolerance_degrees: float = 0.01) -> bool:
	'''
	Returns True if the rotations of the two matrices differ
	by more than the given angular tolerance (in degrees).
	'''

	# Extract pure rotation
	rot_a = mat_a.to_quaternion()
	rot_b = mat_b.to_quaternion()

	# Quaternion angle difference
	angle = rot_a.rotation_difference(rot_b).angle

	return angle > math.radians(tolerance_degrees)


def find_source_center(source) -> mathutils.Vector:
	'''
	Uses existing non-updated BBox corners to find a center cheaply.
	'''
	
	corners = dtypes.LocalBoundingBox.fast(source)

	min_v = mathutils.Vector(map(min, *corners))
	max_v = mathutils.Vector(map(max, *corners))
	center = (min_v + max_v) * 0.5

	return center


def center_as_vert(source) -> dtypes.CenterAsVertElement:
	center = find_source_center(source)
	bm = bmeshutils.create_single_vert_bmesh(location=center)

	return dtypes.CenterAsVertElement(bm=bm, raw=bm.verts[0], matrix=source.matrix)


def assert_is_rotation_matrix(R, tol=1e-4):
	'''
	Assert that a 3x3 rotation matrix R is orthonormal and has no scale/skew.
	Raises a ValueError with detailed info if the check fails.
	'''

	# Ensure 3x3
	R3 = R.to_3x3() if hasattr(R, 'to_3x3') else R

	# Columns / basis vectors
	x = R3.col[0]
	y = R3.col[1]
	z = R3.col[2]

	# Length errors (should all be 1)
	length_errors = [
		abs(x.length - 1.0),
		abs(y.length - 1.0),
		abs(z.length - 1.0),
	]

	# Dot product errors (should all be 0)
	dot_errors = [
		abs(x.dot(y)),
		abs(x.dot(z)),
		abs(y.dot(z)),
	]

	# Full matrix orthogonality check: Rᵀ * R ≈ I
	identity = mathutils.Matrix.Identity(3)
	test = R3.transposed() @ R3
	matrix_errors = [
		abs(test[i][j] - (1 if i == j else 0))
		for i in range(3)
		for j in range(3)
	]

	# Maximum deviation across all checks
	max_error = max(length_errors + dot_errors + matrix_errors)

	if max_error > tol:
		raise ValueError(
			f'Orthonormality check failed for rotation matrix.\n'
			f'Max deviation from ideal: {max_error:.6f}\n'
			f'Diagonal lengths: x={x.length:.6f}, y={y.length:.6f}, z={z.length:.6f}\n'
			f'Dot products: x·y={x.dot(y):.6f}, x·z={x.dot(z):.6f}, y·z={y.dot(z):.6f}\n'
			f'Rᵀ * R =\n{test}\n'
			f'Tolerance used: {tol}'
		)


def has_rotation(matrix: mathutils.Matrix, deg_eps: float = 0.1) -> bool:
	'''
	Check if the input matrix has a non-trivial rotation.
	'''
	
	# cleanly separate rotation regardless of scale/shear
	_, quaternion, _ = matrix.decompose()

	return quaternion.angle > math.radians(deg_eps)


def build_matrix(
	rotation: mathutils.Matrix, 
	location: mathutils.Vector, 
	extra:    mathutils.Matrix = None,
) -> mathutils.Matrix:
	'''
	Build a 4x4 matrix from:
	- location (Vector)
	- rotation (3x3 or 4x4)
	Optional:
	- extra matrix multiplication (applied first)
	'''

	mat = rotation.to_4x4()
	mat.translation = location

	if extra is not None:
		mat = extra @ mat

	return mat


def flat_key_bindings(
	items: list[dtypes.KeyBinding | dtypes.KeyBindingGroup]
) -> list[dtypes.KeyBinding]:
	'''
	Extract every KeyBinding from any KeyBindingGroup in the input list.
	'''
	
	for item in items:
		if isinstance(item, dtypes.KeyBindingGroup):
			yield from item  # uses dtypes.KeyBindingGroup.__iter__()
		else:
			yield item


# CURRENTLY UNUSED
# def tag_redraw_all_viewports(context=None):
# 	'''
# 	Redraw all 3D viewport regions in all Blender windows.

# 	Lightweight: only flags regions as dirty; real redraw happens later.
# 	Scales with the number of windows × viewports × regions.
# 	'''

# 	if context is None:
# 		context = bpy.context

# 	wm = context.window_manager
# 	if wm is None:
# 		return
	
# 	for window in wm.windows:
# 		screen = window.screen
# 		if screen is None:
# 			continue

# 		for area in screen.areas:
# 			if area.type == 'VIEW_3D':
# 				for region in area.regions:
# 					if region.type == 'WINDOW':
# 						region.tag_redraw()


class Draw2D:
	'''
	Group of methods used to draw 3D elements in the viewport using
	pre-instantiated classes.
	'''

	@staticmethod
	def callback(self, context) -> None:
		'''
		The drawing method called by Blender's draw handler.
		'''

		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences
		args = (self, context)

		Draw2D.draw_mouse_hud(self, context)
		if addon_prefs.draw_fixed_hud:
			Draw2D.draw_fixed_hud(self, context)
		
		gizmo_groups.draw_axis_labels(context)

		Draw2D.draw_origin_mode_reticle(context)
		Draw2D.draw_center_as_vert(self, context)

		if modal_prefs.lock_cursor_location:
			Draw2D.draw_anchor_text(*args)

	@staticmethod
	def draw_mouse_hud(self, context) -> None:
		'''
		The text under the mouse, displaying instructions and current settings.
		'''

		# RESTRICT TO SINGLE REGION
		if context.region != self.mouse_region:
			return

		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences
		
		warning_text = ''
		if modal_prefs.operation_type == 'ORIGIN':
			M1 = self.snap_target.matrix
			M2 = runtime_state.gizmo_matrix
			if rotations_differ(M1, M2):
				warning_text = 'You are setting a rotated origin'

		toggles = []
		wrap = lambda s: f'[{s}]'

		if modal_prefs.lock_cursor_location:
			toggles.append('🔒')
			# toggles.append('⤓')
			# toggles.append('⚓')

		if modal_prefs.use_global_orientation:
			toggles.append(wrap('Global'))

		if modal_prefs.snap_to_bounding_box:
			toggles.append(wrap('Bounds'))

		if modal_prefs.align_with_normal:
			toggles.append(wrap('Normal'))
		
		toggles = ' '.join(toggles)

		text_scale = context.preferences.system.ui_scale * addon_prefs.draw_scale
		main_font_size = addon_prefs.hud_font_size
		sub_font_size  = addon_prefs.hud_font_size * 0.8
		offset = mathutils.Vector((0, -25 * text_scale))
		line_space = 1.4
		draw_fn = draw_text.draw_text_center_top

		shared_kwargs = {
			'coords': self.mouse_pos,
			'scale': text_scale,
			'offset': offset,
			'shadow': addon_prefs.mouse_hud_shadow,
		}

		# Setting CURSOR/ORIGIN
		dimensions = draw_fn(
			**shared_kwargs,
			text=Draw2D._build_pivot_dots_with_status(
				modal_prefs.pivot_point_mode,
				self.targets,
			),
			font_size=sub_font_size,
			color=addon_prefs.mouse_hud_base_rgba,
		)

		# Setting CURSOR/ORIGIN
		shared_kwargs['offset'].y -= dimensions.height * line_space
		dimensions = draw_fn(
			**shared_kwargs,
			text=modal_prefs.operation_type,
			font_size=sub_font_size,
			color=addon_prefs.origin_mode_rgba if modal_prefs.operation_type == 'ORIGIN' else (1, 1, 1, 1),
		)

		# # Pivot Mode Instructions
		# shared_kwargs['offset'].y -= dimensions.height * line_space
		# dimensions = draw_fn(
		# 	**shared_kwargs,
		# 	text=action_text,
		# 	font_size=main_font_size,
		# 	color=addon_prefs.mouse_hud_base_rgba,
		# )
		
		if toggles:
			# Active States (toggles)
			shared_kwargs['offset'].y -= dimensions.height * line_space
			dimensions = draw_fn(
				**shared_kwargs,
				text=toggles,
				font_size=sub_font_size,
				color=addon_prefs.active_states_rgba,
			)

		# Optional Warnings
		shared_kwargs['offset'].y -= dimensions.height * line_space
		dimensions = draw_fn(
			**shared_kwargs,
			text=warning_text,
			font_size=sub_font_size,
			color=addon_prefs.warning_rgba,
		)

	@staticmethod
	def _build_pivot_dots_with_status(mode: str, targets) -> str:
		'''
		Build a string of symbols representing the current mode and assigned targets.
		
		Note:
		- DONE turns solid only after we advance past it (idx < active_index).
		'''

		required = {'ONE': 1, 'TWO': 2, 'THREE': 3}.get(mode, 1)

		DONE = '■'  # completed
		CURR = '□'  # current
		PEND = '□'  # pending

		# DONE = '●'  # completed
		# CURR = '○'  # current
		# PEND = '○'  # pending

		# Clamp assigning index; allow required+1 to mean "all done / no current"
		active_index = max(1, min(getattr(targets, 'active_index', 1), required + 1))

		def is_set(idx: int) -> bool:
			if idx == 1:
				return targets.first  is not None
			if idx == 2:
				return targets.second is not None
			if idx == 3:
				return targets.third  is not None
			
			return False

		dots = []
		for i in range(1, required + 1):
			if i < active_index and is_set(i):
				dots.append(DONE)           # locked in a previous step
			elif i == active_index and active_index <= required:
				dots.append(CURR)           # currently assigning
			else:
				dots.append(PEND)           # not yet reached (or skipped)

		return ''.join(dots)

	@staticmethod
	def _build_fixed_hud(self, context) -> list[dtypes.HUDProperty]:
		'''
		Return a list of HUDProperty objects to be drawn later; built from the list 
		containing KeyBinding and KeyBindingGroup objects.
		'''
		
		modal_prefs = runtime_state.modal_preferences

		fixed_hud = []
		for kb in self.key_bindings:
			prop_group = getattr(kb, 'prop_group', False)
			if prop_group:
				val = ', '.join(getattr(modal_prefs, prop) for prop in prop_group)
			else:
				val = prop_group or getattr(modal_prefs, kb.name, '')
			
			titled_val = pretty.safe_title(val)
			
			hud_prop = dtypes.HUDProperty(
				key_binding=kb,
				value=titled_val,
			)
			fixed_hud.append(hud_prop)

		return fixed_hud
			
	@staticmethod
	def draw_fixed_hud(self, context) -> None:
		'''
		The fixed text displaying currently enabled modes and modal hotkeys.
		'''

		# RESTRICT TO SINGLE REGION
		if context.region != self.mouse_region:
			return

		addon_prefs = addon.get_preferences()

		fixed_hud = list(reversed(Draw2D._build_fixed_hud(self, context)))

		text_scale = context.preferences.system.ui_scale * addon_prefs.draw_scale
		draw_fn = draw_text.draw_fixed_hud

		draw_fn(
			props_list=fixed_hud,
			region=context.region,
			scale=text_scale,
			position=addon_prefs.fixed_hud_position,
			padding=(20, 6),
			field_colors=(
				addon_prefs.fixed_hud_name_rgba,
				addon_prefs.fixed_hud_value_rgba,
				addon_prefs.fixed_hud_hotkey_rgba,
				addon_prefs.fixed_hud_hotkey_rgba,
			),
			field_font_sizes=(
				addon_prefs.hud_font_size,
				addon_prefs.hud_font_size,
				addon_prefs.hud_font_size * 0.7,
				addon_prefs.hud_font_size * 0.7,
			),
			shadow=addon_prefs.fixed_hud_shadow,
		)

	
	@staticmethod
	def draw_origin_mode_reticle(context) -> None:
		'''
		Setting the origin is more destructive than than setting the cursor, so draw
		a special reticle to make this mode stand out more.
		'''

		modal_prefs = runtime_state.modal_preferences
		addon_prefs = addon.get_preferences()
		
		if modal_prefs.operation_type != 'ORIGIN':
			return
		
		axis_origin = runtime_state.gizmo_matrix.translation
		axis_origin_2d = view3d.get_2d_from_3d(axis_origin, context)

		scale = context.preferences.system.ui_scale * addon_prefs.draw_scale
		square_radius = 14 * scale
		
		kwargs = {
			'color':      addon_prefs.origin_mode_rgba,
			'line_width': addon_prefs.axis_width,
		}

		shapes = drawcore.ShapeTracer  # static methods
		shapes.draw_square_gap(context, center=axis_origin_2d, radius=square_radius, **kwargs)
		shapes.draw_angled_crosshairs_gap(
			context,
			center=axis_origin_2d, 
			gap_radius=square_radius, 
			line_length=10 * scale,
			**kwargs,
		)
	
	@staticmethod
	def draw_center_as_vert(self, context):

		if not self.center:
			return
		
		addon_prefs = addon.get_preferences()
				
		scale = context.preferences.system.ui_scale * addon_prefs.draw_scale

		M = self.center.matrix
		co = self.center.co
		coords_2d = view3d.get_2d_from_3d(M @ co, context)
		
		drawcore.ShapeTracer.draw_square(
			context,
			center=coords_2d,
			radius=6 * scale, 
			angle_deg=45,
			line_width=addon_prefs.axis_width,
			color=addon_prefs.highlight_rgba,
		)
	
	@staticmethod
	def draw_anchor_text(self, context) -> None:
		'''
		Draw an aditional indicator of where the pivot point will be anchored.
		'''

		addon_prefs = addon.get_preferences()

		# co = Draw3D.get_anchor_location(self, context)
		co = context.scene.cursor.location.copy()
		# world_co = self.snap_target.matrix @ co
		pos = view3d.get_2d_from_3d(co, context)
		draw_fn = draw_text.draw_text_center_bottom

		text_scale = context.preferences.system.ui_scale * addon_prefs.draw_scale
		main_font_size = addon_prefs.hud_font_size
		sub_font_size  = addon_prefs.hud_font_size * 0.8
		offset = (0, addon_prefs.vert_size/2 + 10)
		
		draw_fn(
			coords=pos,
			text='Locked',
			font_size = sub_font_size,
			color=addon_prefs.active_states_rgba,
			offset=offset,
			scale=text_scale,
		)


class Draw3D:
	'''
	Group of methods used to draw 3D elements in the viewport.
	Each draw layer keeps track of its own drawing handler.
	'''

	@staticmethod
	def draw_target_line(self, context):
		
		layer = self.draw_layers['target_line']

		if runtime_state.gizmo_matrix is None or self.targets.second is None:
			layer.clear()
			return
		
		modal_prefs = runtime_state.modal_preferences
		primary_axis = modal_prefs.primary_axis.lower()

		ui = context.preferences.themes[0].user_interface
		axis_color = getattr(ui, f'axis_{primary_axis}')
		
		style = drawcore.ElementStyle(color=(*axis_color, 0.8),line_width=1)
		layer.apply_element_style(style)

		start, end = runtime_state.gizmo_matrix.translation, self.targets.second.world_co
		
		req = drawcore.DrawRequest(
			kind='lines',
			coords_world=[start, end],
			indices=[(0, 1)],
		)
		
		layer.set_from_requests([req])

	@staticmethod
	def update_bbox_layer(self) -> None:
		'''
		Handles drawing the bounding box.
		'''
		
		layer = self.draw_layers['bbox']

		if self.snap_target is None:
			layer.clear()
			# The BBox still draws because the last snap_target is stored.
			return

		layer.visible = runtime_state.modal_preferences.snap_to_bounding_box

		if not layer.visible:
			return

		bm = self.snap_target.get_bmesh()
		M = self.snap_target.matrix
		all_elements = [*bm.verts, *bm.edges, *bm.faces]
		layer.set_from_items(all_elements, M)

	@staticmethod
	def highlight_elements(self, targets: dtypes.Targets) -> None:
		elem_layer = self.draw_layers['elem']
		elem_layer.clear()
		
		faded_elem_layer = self.draw_layers['faded_elem']
		faded_elem_layer.clear()

		reqs = []

		if targets.active and not isinstance(targets.active, dtypes.CenterAsVertElement):
			reqs.extend(drawcore.requests_from_interfaces([targets.active]))

		# Point for all elements types except centers (draw as a 2d shape)
		points = [t.world_co for t in targets.valid if not isinstance(t, dtypes.CenterAsVertElement)]
		if points:
			reqs.extend(drawcore.requests_from_points(points))
			elem_layer.set_from_requests(reqs)

		# INACTIVE/LOCKED IN ELEMENTS
		if targets.inactive:
			reqs = drawcore.requests_from_interfaces(targets.inactive)
			faded_elem_layer.set_from_requests(reqs)
		else:
			faded_elem_layer.clear()
	
	@staticmethod
	def draw_cursor_lock_point(self, context) -> None:
		'''
		Draw a point at the 3d cursor location when the location lock is enabled.
		'''

		layer = self.draw_layers['cursor_lock']

		modal_prefs = runtime_state.modal_preferences

		if modal_prefs.lock_cursor_location:
			co = context.scene.cursor.location.copy()
			req = drawcore.request_from_point(co)
			layer.set_from_requests([req])
		else:
			layer.clear()


class PixiePivotBase:
	def invoke(self, context, event):
		addon_prefs = addon.get_preferences()

		runtime_state.reset()
		runtime_state.modal_operator_instance = self

		runtime_state.modal_preferences = dtypes.ModalPreferences(
			pivot_point_mode	= addon_prefs.pivot_point_mode,
			operation_type		= addon_prefs.operation_type,
			lock_cursor_location	= addon_prefs.lock_cursor_location,
			primary_axis		= addon_prefs.primary_axis,
			secondary_axis		= addon_prefs.secondary_axis,
			align_with_normal	= addon_prefs.align_with_normal,
			snap_to_bounding_box	= addon_prefs.snap_to_bounding_box,
			use_global_orientation	= addon_prefs.use_global_orientation,
		)

		self.activation_key = event.type
		self.depsgraph      = context.evaluated_depsgraph_get()
		self.mouse_pos      = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
		self.mouse_region   = context.region

		self.pressed_modifiers = set()
		self.cached_objects = {}
		self.wireframed_objects = []
		self.first_activation = True
		self.pressed_MMB = False
		self.cursor_was_hidden = False
		self.LMB_release_guard = False
		self.snap_target = None
		self.first_target_face = None
		self.first_snap_target = None
		self.handler_2d = None
		self.handler_3d = None
		self.bvh_raycast = None
		self.targets = dtypes.Targets()
		self.center = None

		self.key_bindings = self._build_key_bindings()
		self.key_event_map	= event_utils.map_events_to_key_bindings(flat_key_bindings(self.key_bindings))
		self.modifier_event_map	= event_utils.map_events_to_modifiers(self.key_bindings)
		self.raycast_events = (
			{'MOUSEMOVE'}
			| self.key_event_map.keys()
			| self.modifier_event_map.keys()
		)
		debug.dump(self.key_event_map, title='KEY EVENT MAP')
		debug.dump(self.modifier_event_map, title='MOD EVENT MAP')

		if (
			context.scene.transform_orientation_slots[0].type != 'CURSOR'
			or context.scene.tool_settings.transform_pivot_point != 'CURSOR'
		):
			runtime_state.original_transform_orientation = context.scene.transform_orientation_slots[0].type
			runtime_state.original_transform_pivot_point = context.scene.tool_settings.transform_pivot_point
			debug.msg(
				f'Stored Orientation and Pivot Point: '
				f'{runtime_state.original_transform_orientation} '
				f'& {runtime_state.original_transform_pivot_point}'
			)

		if addon_prefs.hide_3d_cursor:
			context.space_data.overlay.show_cursor = False
			self.cursor_was_hidden = True

		self._create_draw_layers()
		self._add_draw_handlers(context)

		gizmo_groups.VIEW3D_GGT_pixie_axes.create(context)
		gizmo_groups.VIEW3D_GGT_pixie_tips.create(context)

		self.modal(context, event)

		context.window_manager.modal_handler_add(self)

		return {'RUNNING_MODAL'}


	def modal(self, context, event):
		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences



		# MAYA NAVIGATION __________________________________________________

		if addon_prefs.use_maya_navigation:
			if event.alt:
				return {'PASS_THROUGH'}



		# TOGGLE UNRELEASED MODIFIERS __________________________________________________

		# Special case for modifier event RELEASE getting swallowed by PASSTHROUGH modals
		if self.pressed_MMB:
			self.pressed_MMB = False
			if self.pressed_modifiers:
				self._callback_unpressed_modifiers(event)



		# BEGIN __________________________________________________
		
		if event.type != 'TIMER_REPORT':
			debug.msg(event.type, event.value)

		context.area.tag_redraw()
		self.mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
		self.mouse_region = context.region
		self._auto_switch_pivot_mode()



		# MODIFIER KEYS __________________________________________________

		if event.type in self.modifier_event_map:
			mod = event_utils.simple_modifier(event.type)

			# Only allow a event RELEASE callback if there was a previous PRESS one.
			# Guards for PASS_THROUGH modals swallowing modifier PRESS.

			if event.value == 'PRESS':
				self.pressed_modifiers.add(mod)

			if mod in self.pressed_modifiers:
				callback = self.modifier_event_map[mod]
				callback()

				debug.msg('Called', f'{self.modifier_event_map[mod].__name__}()')
			else:
				debug.msg(f'Modifier {mod} was RELEASED but never PRESSED', 'SKIP CALLBACK')

			if event.value == 'RELEASE':
				self.pressed_modifiers.discard(mod)



		# REGULAR KEYS __________________________________________________

		elif event.type in self.key_event_map and event.value == 'PRESS':
			self.pressing_regular_key = True
			kb = self.key_event_map[event.type]
			kb.callback()

			if addon_prefs.persistent_state:
				_attr = kb.parent or kb.name
				
				if _attr == 'axis_priority':
					# DO NOTHING HERE
					debug.msg(f'Special persistence case handled by the callback')
				elif hasattr(addon_prefs, _attr):
					setattr(addon_prefs, _attr, getattr(modal_prefs, _attr))
					debug.msg(f'Prop {_attr} will Persist')
				else:
					debug.msg(f'Addon Prefs does NOT have an attribute {_attr}')



		one_point_pivot   = modal_prefs.pivot_point_mode == 'ONE'
		two_point_pivot   = modal_prefs.pivot_point_mode == 'TWO'
		three_point_pivot = modal_prefs.pivot_point_mode == 'THREE'

		# LEFTMOUSE PRESS __________________________________________________

		if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
			self.LMB_release_guard = False

			if one_point_pivot and self.targets.first:
				self.targets.choosing_second = True
			
			elif two_point_pivot and self.targets.first:
				self.targets.choosing_second = True

			elif three_point_pivot:
				if self.targets.first:
					self.targets.choosing_second = True
					
				if self.targets.second:
					self.targets.choosing_third = True
			


		# LEFTMOUSE RELEASE __________________________________________________

		if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':

			if self.LMB_release_guard:
				self.LMB_release_guard = False
				debug.msg('RELEASE GUARD')
				
				return {'RUNNING_MODAL'}

			if two_point_pivot and self.targets.second is None:
				debug.msg('TWO mode and second target is None')

				return {'RUNNING_MODAL'}

			elif three_point_pivot and self.targets.third is None:

				# Special case tu support click and drag to assign first and second
				# targets in one go, while in 3PP mode.
				if self.targets.second:
					self.targets.choosing_third = True

				debug.msg('THREE mode and third target is None')

				return {'RUNNING_MODAL'}

			self._finish(context)
			self._cleanup(context)

			return {'FINISHED'}



		# RAYCAST TRIGGERS __________________________________________________

		if event.type in self.raycast_events or self.first_activation:
			self.first_activation = False
			snap_mesh = None
			snap_to_bounding_box = modal_prefs.snap_to_bounding_box

			for obj in self.wireframed_objects:
				obj.show_wire = False
			self.wireframed_objects.clear()

			# Mousemove is NOT a trigger
			scene_raycast_event = event.type in (
				self.key_event_map.keys() | self.modifier_event_map.keys())

			if not self.bvh_raycast or not snap_to_bounding_box or scene_raycast_event:
				self.scene_raycast = raycast_utils.scene_raycast(context, event, self.depsgraph)
				self.snap_target = self.get_snap_target(self.scene_raycast)
				

			nearest_element = None
			self.center = None

			if self.snap_target:
				self.wireframed_objects.append(self.snap_target.source.obj)
				self.snap_target.source.obj.show_wire = True
				
				obj = self.snap_target.source.obj
				if obj.mode == 'OBJECT' and not snap_to_bounding_box:
					obj_eval = obj.evaluated_get(self.depsgraph)
					mesh = obj_eval.data
					if self.scene_raycast:
						# Check the result of self.scene_raycast first.
						# It can still be None.
						face = mesh.polygons[self.scene_raycast.face_index]
						face_elem = dtypes.FaceElement(face, self.snap_target.matrix)
						snap_mesh = dtypes.SnapMesh(face_elem, self.scene_raycast.co)
						nearest_element = snap_mesh.nearest_element
				else:
					self.bvh_raycast = raycast_utils.bvh_raycast(context, event, self.snap_target)
					if self.bvh_raycast:
						snap_mesh = dtypes.SnapMesh.from_raycast(self.bvh_raycast)
						nearest_element = snap_mesh.nearest_element

			if nearest_element is None:
				if self.snap_target:
					nearest_element = center_as_vert(self.snap_target.source)
					self.center = nearest_element

				# OLD
				# nearest_element = self.snap_target.get_center_as_vert()

			if self.targets.choosing_first:
				self.targets.first = nearest_element
				self.first_target_face = snap_mesh.face if snap_mesh else None
				self.first_snap_target = self.snap_target
				
			elif self.targets.choosing_second:
				nearest_is_different = vectors_are_different(
					nearest_element.world_co, self.targets.first.world_co
				)
				self.targets.second = nearest_element if nearest_is_different else None
			
			elif self.targets.choosing_third:
				nearest_is_different = (
					vectors_are_different(nearest_element.world_co, self.targets.first.world_co) and
					vectors_are_different(nearest_element.world_co, self.targets.second.world_co)
				)
				self.targets.third = nearest_element if nearest_is_different else None
				
			runtime_state.second_world_co = getattr(self.targets.second, 'world_co', None)

			debug.msg(f'\nSnap Obj {self.snap_target.source if self.snap_target else None}')
			debug.msg(f'First  {type(self.targets.first).__name__}')
			debug.msg(f'Second {type(self.targets.second).__name__}')
			debug.msg(f'Third  {type(self.targets.third).__name__}\n')

			self._build_gizmo_matrix()
			self._update_draw_layers(context)

			return {'RUNNING_MODAL'}
			


		# GROW/SHRINK PIVOT __________________________________________________

		if event.type in events.SCALE_PIVOT:

			if event.value == 'RELEASE':
				return {'RUNNING_MODAL'}

			current_scale = getattr(addon_prefs, 'axis_size')
			increment = 25
			
			if event.type in events.GROW_PIVOT:
				setattr(addon_prefs, 'axis_size', current_scale + increment)

			elif event.type in events.SHRINK_PIVOT:
				setattr(addon_prefs, 'axis_size', current_scale - increment)
			
			return {'RUNNING_MODAL'}



		# RESET PIVOT SIZE __________________________________________________

		if event.type in events.RESET_PIVOT_SIZE and event.value == 'PRESS':
			addon_prefs.property_unset('axis_size')

			return {'RUNNING_MODAL'}
		

		
		# FINISH / CANCEL __________________________________________________

		if event.type in events.FINISH and event.value == 'PRESS':
			assert self.targets.first is not None, 'Expected first_target to be set, but it is None.'
			self._finish(context)
			self._cleanup(context)

			return {'FINISHED'}
		

		if event.type in events.CANCEL and event.value == 'PRESS':
			# self.report({'INFO'}, 'CANCEL → Nothing was done')
			self._cleanup(context)

			return {'FINISHED'}


		# Prevents events like LEFTMOUSE or ENTER being used as a reset key
		# when the modal is activated from a menu or a weird hotkey.
		_is_valid_activation_key = (
			event.type == self.activation_key
			and self.activation_key in string.ascii_uppercase
		)

		if _is_valid_activation_key and event.value == 'PRESS':
			self._reset_cursor_and_orientation(context)
			self._cleanup(context)
			self.report({'INFO'}, 'Reset Pivot Transforms')

			return {'FINISHED'}



		# PASS_THROUGH __________________________________________________

		if event.type in events.PASSTHROUGH:
			if event.type == 'MIDDLEMOUSE':
				self.pressed_MMB = True

			return {'PASS_THROUGH'}


		return {'RUNNING_MODAL'}
	

	
	# PRIVATE METHODS __________________________________________________

	def _finish(self, context) -> None:
		self._do_operation(context)
	
	def _do_operation(self, context) -> None:
		modal_prefs = runtime_state.modal_preferences

		if modal_prefs.operation_type == 'ORIGIN':
			self._set_origin(context)
			# self.report({'INFO'}, 'Origin Set')
		else:
			self._set_cursor(context)
			# self.report({'INFO'}, 'Cursor Set')

	def _build_gizmo_matrix(self) -> None:
		'''
		Set the final gizmo_matrix world transforms (scale stripped).
		'''

		target_count = len(self.targets.valid)

		if not target_count:
			return
		
		location = self.targets.first.world_co

		# Orientation only conditionals
		if target_count == 1:
			use_global_orientation = runtime_state.modal_preferences.use_global_orientation

			if use_global_orientation:
				rotation = mathutils.Matrix.Identity(3)
			else:
				rotation = self.snap_target.source.matrix.to_3x3().normalized()

		elif target_count > 1:
			dir_a, dir_b = self._find_directions_from_targets()
			rotation = self._orthonormal_rotation_matrix(dir_a, dir_b)
		else:
			raise ValueError('SHOULD NOT BE REACHABLE; CHECK THE GUARD CLAUSE')

		gizmo_matrix = build_matrix(rotation, location)
		runtime_state.gizmo_matrix = gizmo_matrix

	def get_snap_target(self, scene_raycast):
		if not scene_raycast:
			# Retain the last snap_target when hovering empty space.
			return self.snap_target

		obj = scene_raycast.obj

		snap_target = self.cached_objects.get(obj)

		if snap_target is None:
			source = dtypes.SingleObjectSource(obj)
			snap_target = dtypes.SnapTarget(source)
			self.cached_objects[obj] = snap_target

		return snap_target

	def _auto_switch_pivot_mode(self) -> None:
		'''
		Switch to two point pivot mode automatically if a second target was set 
		(click and drag in mode one allows setting 2 target elemenets).
		'''
		
		modal_prefs = runtime_state.modal_preferences

		one_point_pivot = modal_prefs.pivot_point_mode == 'ONE'

		if one_point_pivot and self.targets.second:
			modal_prefs.pivot_point_mode = 'TWO'
	
	# @debug.run_check
	def _callback_unpressed_modifiers(self, event) -> None:
		mods_being_held = event_utils.current_mods_from_event(event)
		mods_to_unpress = {
			key 
			for key in self.pressed_modifiers
			if event_utils.simple_modifier(key) not in mods_being_held}
		
		# Only run unpress callbacks on modifiers that are no longer held down.
		if not mods_to_unpress:
			return

		for mod in mods_to_unpress:
			callback = self.modifier_event_map[mod]
			callback()
			self._build_gizmo_matrix()

			debug.msg(
				f'Modifier {mod} was PRESSED but never RELEASED', 
				f'Called {self.modifier_event_map[mod].__name__}()',
			)
		
		# Placing this here saves us from typing it twice;
		# the top loop wont run anyway if falsy.
		if mods_to_unpress:
			self.pressed_modifiers.difference_update(mods_to_unpress)	
			self._build_gizmo_matrix()

	def _build_key_bindings(self) -> list[dtypes.KeyBinding | dtypes.KeyBindingGroup]:
		'''
		Uses a hardcoded list of actions to build KeyBinding types, which have their
		own methods for finding the right callbacks and assigned keys.
		- Very brittle if you use the wrong names (KeyBinding finds required objects by name).
		'''
		
		addon_prefs = addon.get_preferences()

		@dataclasses.dataclass
		class ActionGroup:
			name: str		# Matching field in ModalPrefs to draw in HUD or later control with a callback
			actions: list[str]	# Actions with potential key assignments

			# Optional Props you want to group under ModalPrefs field.
			# Ex: field_name 'axis_priority', addon_prefs props are 'primary_axis' and 'secondary_axis'
			props: tuple[str, ...] | None = None	

			# Some groups have no callbacks
			has_callback: bool = True  
		
			def __iter__(self):
				yield from self.actions

		actions = [
			ActionGroup(
				name='pivot_point_mode',
				actions=(
					'one_point_pivot',
					'two_point_pivot',
					'three_point_pivot'
				),
				has_callback=False,
			),
			ActionGroup(
				name='operation_type',
				actions=(
					'set_origin',
					'set_cursor',
				),
			),
			ActionGroup(
				name='axis_priority',
				props=('primary_axis', 'secondary_axis'),
				actions=(
					'set_x_axis',
					'set_y_axis',
					'set_z_axis',
				),
				has_callback=False,
			),
			'lock_cursor_location',
			'align_with_normal',
			'snap_to_bounding_box',
			'use_global_orientation',
			'reset_defaults',
		]

		mod_action_dict = {
			addon_prefs.ctrl_action.lower(): 'CTRL',
			addon_prefs.alt_action.lower(): 'ALT',
			addon_prefs.shift_action.lower(): 'SHIFT',
		}

		# We need separate logic for each dtypes.Binding type becaue groups can have their own 
		# callbacks for toggling/cycling value, on top of the sub key bindigs;
		# [IN SUCH A CASE, THE SUB KEYS SHOULD NOT USE THE SIMILAR BINDINGS -> Fix later]
		key_bindings = []
		for action in actions:
			if isinstance(action, ActionGroup):
				action_group = action
				
				kb_group = []
				for sub_action in action_group:
					sub_kb = dtypes.KeyBinding(
						name=sub_action, 
						parent=action_group.name
					)
					kb_group.append(sub_kb)
				
				kb = dtypes.KeyBindingGroup(
					name=action_group.name, 
					modifier=mod_action_dict.get(action_group.name),
					kb_group=kb_group, 
					prop_group=action_group.props,
					has_callback=action_group.has_callback,
				)
			else:
				kb = dtypes.KeyBinding(
					name=action, 
					modifier=mod_action_dict.get(action),
				)
			
			key_bindings.append(kb)

		# debug.msg_data(key_bindings, 'name', 'hotkey_str')
		
		return key_bindings
		
	def _set_pivot_mode_helper(self, mode: str) -> None:
		modal_prefs = runtime_state.modal_preferences

		modal_prefs.pivot_point_mode = mode
		
		self.targets.second = None
		self.targets.third = None

		self.targets.choosing_first = True
		self.LMB_release_guard = True

	def _one_point_pivot_callback(self) -> None:
		self._set_pivot_mode_helper('ONE')

	def _two_point_pivot_callback(self) -> None:
		self._set_pivot_mode_helper('TWO')

	def _three_point_pivot_callback(self) -> None:
		self._set_pivot_mode_helper('THREE')
	
	def _lock_cursor_location_callback(self) -> None:
		'''
		Keep the original `Transform Pivot Point`
		'''
		
		modal_prefs = runtime_state.modal_preferences
		modal_prefs.lock_cursor_location = not modal_prefs.lock_cursor_location

	def _align_with_normal_callback(self) -> None:
		'''
		Align with the target element normal if possible.
		'''
		
		modal_prefs = runtime_state.modal_preferences
		modal_prefs.align_with_normal = not modal_prefs.align_with_normal

	def _snap_to_bounding_box_callback(self) -> None:
		'''
		Toggle the active snapping surface.
		'''

		modal_prefs = runtime_state.modal_preferences
		modal_prefs.snap_to_bounding_box = not modal_prefs.snap_to_bounding_box
		# self.active_data = self.snap_target.get_active(modal_prefs)

	def _use_global_orientation_callback(self) -> None:
		'''
		Switch between GLOBAL and LOCAL orientation.
		'''

		modal_prefs = runtime_state.modal_preferences
		modal_prefs.use_global_orientation = not modal_prefs.use_global_orientation
		# self.active_data = self.snap_target.get_active(modal_prefs)
		
	def _set_origin_callback(self) -> None:
		modal_prefs = runtime_state.modal_preferences
		modal_prefs.operation_type = 'ORIGIN'

	def _set_cursor_callback(self) -> None:
		modal_prefs = runtime_state.modal_preferences
		modal_prefs.operation_type = 'CURSOR'

	def _operation_type_callback(self) -> None:
		'''
		Switch between setting the ORIGIN or the CURSOR.
		'''

		modal_prefs = runtime_state.modal_preferences
		modal_prefs.operation_type = 'CURSOR' if modal_prefs.operation_type == 'ORIGIN' else 'ORIGIN'
	

	def _set_axis_helper(self, axis: str) -> None:
		'''
		This is such a special case that persistence is also controlled here.
		'''
		
		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences

		def set_and_check(set_attr: str, set_val: str,  check_attr: str) -> None:
			'''
			Set the attr to a new val and check its ocunterpart
			for duplication (change if equal).
			'''

			if set_val not in AXES:
				raise ValueError(f'Invalid axis {set_val!r}; expected one of {AXES}')
			
			setattr(modal_prefs, set_attr, set_val)
			
			other_val = getattr(modal_prefs, check_attr)
			if other_val == set_val:
				for candidate in AXES:
					if candidate != set_val:
						setattr(modal_prefs, check_attr, candidate)
						debug.msg('Fixed Duplicate axis')
						break

		if self.targets.choosing_third:
			set_and_check('secondary_axis', axis, 'primary_axis')
			_attr = 'secondary_axis'
		else:
			set_and_check('primary_axis', axis, 'secondary_axis')
			_attr = 'primary_axis'

		# I had to do this here because of how these 2 properties are grouped under the parent 'axis_priority', 
		# for HUD drawing purposes, but because it is not a real parent property we can't push is like the others.
		if addon_prefs.persistent_state:
			if hasattr(addon_prefs, _attr):
				setattr(addon_prefs, _attr, getattr(modal_prefs, _attr))
				debug.msg(f'Special Case: Prop {_attr} will Persist')

		
	def _set_x_axis_callback(self) -> None:
		self._set_axis_helper('X')

	def _set_y_axis_callback(self) -> None:
		self._set_axis_helper('Y')

	def _set_z_axis_callback(self) -> None:
		self._set_axis_helper('Z')

	def _reset_defaults_callback(self) -> None:
		'''
		Unset the addon preferences and set the modal_preferences to match them.
		- Updates persist even after a CANCEL event.
		- Does NOT require pushing changes because we reset the source first and pull back to modal prefs.
		'''
		
		addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences

		def unset_and_update_local(attr: str) -> None:
			addon_prefs.property_unset(attr)
			new_val = getattr(addon_prefs, attr)
			setattr(modal_prefs, attr, new_val)

		for attr in modal_prefs.attr_names:
			if hasattr(addon_prefs, attr):
				unset_and_update_local(attr)
			else:
				debug.msg(f'SOFT ERROR → addon_prefs.{attr} does not exist', 'SKIP')

		self.targets.clear()
		self.LMB_release_guard = True

		self.report({'INFO'}, 'Reset Pixie Defaults')


	def _set_origin(self, context) -> None:
		'''
		Use the Target Matrix to set the origin.
		'''

		obj = self.snap_target.source.obj
		if not obj or obj.type != 'MESH':
			return

		if context.mode != 'OBJECT':
			bpy.ops.object.mode_set(mode='OBJECT')

		old_world = obj.matrix_world.copy()
		new_world = runtime_state.gizmo_matrix.copy()

		# compensation so world-space verts stay fixed
		mesh_comp = new_world.inverted() @ old_world

		mesh = obj.data

		# --- SHAPE KEY SUPPORT (DISABLED FOR NOW) ---
		# If you later want proper shape key support,
		# you must transform every key block, not just the base mesh.
		#
		# if mesh.shape_keys:
		# 	for key_block in mesh.shape_keys.key_blocks:
		# 		for v in key_block.data:
		# 			v.co = mesh_comp @ v.co
		# else:
		# 	mesh.transform(mesh_comp)

		mesh.transform(mesh_comp)
		mesh.update()

		obj.matrix_world = new_world

	def _set_cursor(self, context) -> None:
		if runtime_state.gizmo_matrix is None:
			self.report({'INFO'}, 'CANCEL → Nothing was done')
			return

		modal_prefs = runtime_state.modal_preferences

		cursor = context.scene.cursor
		original_location = cursor.location.copy()

		cursor.matrix = runtime_state.gizmo_matrix
		
		if modal_prefs.lock_cursor_location:
			cursor.location = original_location
		
		context.scene.tool_settings.transform_pivot_point = 'CURSOR'
		context.scene.transform_orientation_slots[0].type = 'CURSOR'	

	def _directions_with_one_target(self, dir_a, dir_b):
		return dir_a, dir_b

	def _directions_with_two_targets(self, dir_a, dir_b):
		'''
		Compute directions from the first two targets.

		If their world-space delta is near zero (<= NEAR_ZERO),
		the existing axes are preserved to avoid degenerate vectors.
		'''

		modal_prefs = runtime_state.modal_preferences

		# --- Primary Direction (A) ---
		delta_a = self.targets.second.world_co - self.targets.first.world_co

		if delta_a.length <= NEAR_ZERO:
			print('[Directions] Two targets share nearly identical position. Falling back to primary axis.')
		else:
			dir_a = delta_a

		# --- Secondary Direction (B) ---
		if modal_prefs.align_with_normal:
			n1 = self.targets.first.world_normal
			n2 = self.targets.second.world_normal
			combined = n1 + n2

			if combined.length <= NEAR_ZERO:
				print('[Directions] Averaged normals cancel out. Falling back to secondary axis.')
			else:
				dir_b = combined

		else:
			first_target_face_normal = (
				BASE_AXES['Z']
				if self.first_target_face is None
				else self.first_target_face.world_normal
			)

			n2 = self.targets.second.world_normal
			avg = first_target_face_normal + n2

			if avg.length <= NEAR_ZERO:
				print('[Directions] Face normals cancel out. Falling back to secondary axis.')
			else:
				dir_b = first_target_face_normal

		return dir_a, dir_b

	def _directions_with_three_targets(self, dir_a, dir_b):
		'''
		Refine secondary direction using the third target.

		If the computed delta is near zero (<= NEAR_ZERO),
		the existing secondary axis is preserved.
		'''

		delta_b = self.targets.third.world_co - self.targets.second.world_co

		if delta_b.length <= NEAR_ZERO:
			print('[Directions] Third target is nearly identical to second. Keeping previous secondary direction.')
		else:
			dir_b = delta_b

		return dir_a, dir_b

	def _find_directions_from_targets(self) -> tuple[mathutils.Vector, mathutils.Vector]:
		'''
		Find the desired Primary and Secondary axis directions based on
		the current alignment points and the target elements.

		Output orthogonality is not enforced.
		'''

		assert self.targets.first is not None, 'First target must exist.'

		if self.targets.second:
			assert self.targets.first != self.targets.second, \
				'First and second targets must be different.'

		if self.targets.third:
			assert self.targets.second is not None, \
				'Third target requires a second target.'
			assert self.targets.third != self.targets.first, \
				'Third target must differ from first.'
			assert self.targets.third != self.targets.second, \
				'Third target must differ from second.'

		modal_prefs = runtime_state.modal_preferences

		# Default axes
		dir_a = BASE_AXES[modal_prefs.primary_axis]
		dir_b = BASE_AXES[modal_prefs.secondary_axis]

		# Step progressively
		# Dummy func, does nothing
		# dir_a, dir_b = self._directions_with_one_target(dir_a, dir_b)

		if self.targets.second:
			dir_a, dir_b = self._directions_with_two_targets(dir_a, dir_b)

		if self.targets.third:
			dir_a, dir_b = self._directions_with_three_targets(dir_a, dir_b)

		return dir_a, dir_b
	
	def _orthonormal_rotation_matrix(self, dir_a: mathutils.Vector, dir_b: mathutils.Vector) -> RotationMatrix:
		'''
		Creates a normalized orthogonal rotation matrix where:
		- Alignment to `dir_a` is exact.
		- Alignment to `dir_b` is as close as posible (cannot affect `dir_a`).

		Note:
		- The `dir` arguments are not required to be orthogonal.
		'''
		
		# addon_prefs = addon.get_preferences()
		modal_prefs = runtime_state.modal_preferences

		primary_axis   = modal_prefs.primary_axis
		secondary_axis = modal_prefs.secondary_axis

		# Normalize inputs
		dir_a = dir_a.normalized()
		if dir_b is None:
			dir_b = BASE_AXES[secondary_axis]
		else:
			dir_b = dir_b.normalized()
		
		# Step 1: Calculate rotation aligning base primary axis to dir_a
		rot_to_primary = BASE_COLUMNS[
			AXES.index(primary_axis)
		].rotation_difference(dir_a).to_matrix().to_4x4()

		# Rotate the base matrix so its primary axis aligns with dir_a
		rotated_mat = rot_to_primary @ BASE_MATRIX.to_4x4()

		# Step 2: Now adjust roll around primary axis to align secondary axis to dir_b as close as possible
		# Extract rotated secondary axis
		rotated_secondary = rotated_mat.col[
			AXES.index(secondary_axis)
		].to_3d().normalized()

		# Project dir_b onto plane perpendicular to dir_a (primary axis)
		proj_dir_b = dir_b - dir_a * dir_b.dot(dir_a)
		
		if proj_dir_b.length == 0:
			# No way to adjust roll: secondary direction is parallel to primary
			return rotated_mat.to_3x3()
		
		proj_dir_b.normalize()

		# Calculate angle between rotated secondary axis and desired dir_b projection
		angle = rotated_secondary.angle(proj_dir_b)
		# Determine sign of rotation (direction of roll)
		sign = dir_a.dot(rotated_secondary.cross(proj_dir_b))
		if sign < 0:
			angle = -angle

		# Create rotation matrix around primary axis by this angle
		roll_rot = mathutils.Matrix.Rotation(angle, 4, dir_a)

		# Apply roll rotation to the matrix
		final_mat = roll_rot @ rotated_mat

		# Return the 3x3 rotation matrix
		return final_mat.to_3x3()

	def build_element_styles(self) -> dict[str, drawcore.ElementStyle]:
		'''
		Build ElementStyle objects from current addon prefs (pure function).
		'''

		addon_prefs = addon.get_preferences()
		scale = getattr(self, 'ui_scale', 1.0) * addon_prefs.draw_scale

		point_size = addon_prefs.vert_size * scale
		line_width = addon_prefs.edge_width * scale
		highlight = addon_prefs.highlight_rgba

		elem = drawcore.ElementStyle(
			color=highlight,
			point_size=point_size,
			line_width=line_width,
			depth_test=False,
			outline=True,
		)
		
		faded_elem = elem.faded()
		cursor_lock = elem

		# Drawn from the gizmo location to the second target location
		target_line = elem.with_(
			color=(1, 1, 1, .8),
			line_width=1,
		)

		bbox = elem.with_(
			point_size=point_size,
			line_width=line_width,
			color=addon_prefs.bounding_box_rgba,
			face_opacity=0,
		)
		
		debug = drawcore.debug_element_style_overlay()

		return {
			'bbox': bbox,
			'target_line': target_line,
			'elem': elem,
			'faded_elem': faded_elem,
			'cursor_lock': cursor_lock,
			'debug': debug,
		}

	def apply_element_styles(self, styles: dict[str, drawcore.ElementStyle]) -> None:
		'''
		Apply the given styles to the existing layers by key.
		Safe if a style is missing (skips that layer).
		'''

		for key, layer in self.draw_layers.items():
			style = styles.get(key)
			if style is not None:
				layer.apply_element_style(style)
	
	def _update_draw_layers(self, context):
		# Order is irrelevant.
		Draw3D.update_bbox_layer(self)
		Draw3D.highlight_elements(self, self.targets)
		Draw3D.draw_target_line(self, context)
		Draw3D.draw_cursor_lock_point(self, context)

	def _create_draw_layers(self) -> None:
		'''
		Create ElementLayers and register handlers in correct order.
		'''

		# ORDER MATTERS HERE
		# LAST WILL BE DRAWN ON TOP
		self.draw_layers = {
			'bbox':		drawcore.ElementLayer(),
			'target_line':	drawcore.ElementLayer(),
			'elem':		drawcore.ElementLayer(),
			'faded_elem':	drawcore.ElementLayer(),
			'cursor_lock':	drawcore.ElementLayer(),
			'debug':	drawcore.ElementLayer(),
		}

		self._enable_draw_layers()
		self.apply_element_styles(self.build_element_styles())

	def _cleanup(self, context) -> None:
		'''
		Stop drawing and return other changes to their original state.
		'''
		
		self._hide_object_wireframes()
		self._disable_draw_layers()
		self._remove_draw_handlers()
		gizmo_groups.VIEW3D_GGT_pixie_axes.destroy(context)
		gizmo_groups.VIEW3D_GGT_pixie_tips.destroy(context)

		if self.cursor_was_hidden:
			context.space_data.overlay.show_cursor = True
	
	def _hide_object_wireframes(self):
		for obj in self.wireframed_objects:
			obj.show_wire = False
	
	def _enable_draw_layers(self) -> None:
		for layer in self.draw_layers.values():
			layer.enable()
		
	def _disable_draw_layers(self) -> None:
		for layer in self.draw_layers.values():
			layer.disable()

	def _remove_draw_handlers(self) -> None:
		'''
		Remove any existing viewport draw handlers.
		'''
		# return

		if self.handler_2d is not None:
			bpy.types.SpaceView3D.draw_handler_remove(self.handler_2d, 'WINDOW')
			self.handler_2d = None

		# if self.handler_3d is not None:
		# 	bpy.types.SpaceView3D.draw_handler_remove(self.handler_3d, 'WINDOW')
		# 	self.handler_3d = None

	def _add_draw_handlers(self, context) -> None:
		'''
		GPU drawing handlers.
		'''

		args = (self, context)
		self.handler_2d = bpy.types.SpaceView3D.draw_handler_add(
			Draw2D.callback, args, 'WINDOW', 'POST_PIXEL'
		)
		# self.handler_3d = bpy.types.SpaceView3D.draw_handler_add(
		# 	Draw3D.callback, args, 'WINDOW', 'POST_VIEW'
		# )

	def _reset_cursor_and_orientation(self, context) -> None:
		addon_prefs = addon.get_preferences()
		double_tap_resets_to = addon_prefs.double_tap_resets_to

		def reset_to(transform_orientation, transform_pivot_point):
			context.scene.transform_orientation_slots[0].type = transform_orientation
			context.scene.tool_settings.transform_pivot_point = transform_pivot_point

		# bpy.ops.view3d.snap_cursor_to_center()
		context.scene.cursor.matrix = mathutils.Matrix.Identity(4)
		
		if double_tap_resets_to == 'PREVIOUS' and runtime_state.original_transform_orientation:
			reset_to(
				runtime_state.original_transform_orientation, 
				runtime_state.original_transform_pivot_point
			)
		
		elif double_tap_resets_to == 'CUSTOM':
			reset_to(
				addon_prefs.transform_orientation_reset, 
				addon_prefs.transform_pivot_point_reset
			)

		else:
			reset_to('GLOBAL', 'MEDIAN_POINT')



class OBJECT_OT_armored_pixie_pivot(bpy.types.Operator, PixiePivotBase):
	'''Click and drag on any mesh element to place and align the 3D Cursor or set the Origin.

	armoredColony.com '''

	bl_idname = 'object.armored_pixie_pivot'
	bl_label = 'Pixie Pivot (Object Mode)'
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context) -> bool:
		return context.mode == 'OBJECT'


class MESH_OT_armored_pixie_pivot(bpy.types.Operator, PixiePivotBase):
	'''Click and drag on any mesh element to place and align the 3D Cursor or set the Origin.

	armoredColony.com '''

	bl_idname = 'mesh.armored_pixie_pivot'
	bl_label = 'Pixie Pivot (Edit Mode)'
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context) -> bool:
		return context.mode == 'EDIT_MESH'


def draw_button(self, context) -> None:
	layout = self.layout

	layout.separator()
	row = layout.row(align=True)
	row.operator(
		'mesh.armored_pixie_pivot', icon='ORIENTATION_LOCAL', text='Pixie Pivot'
	)


classes = (
	OBJECT_OT_armored_pixie_pivot,
	MESH_OT_armored_pixie_pivot,
)


def register() -> None:
	for cls in classes:
		bpy.utils.register_class(cls)

	bpy.types.VIEW3D_MT_snap.append(draw_button)


def unregister() -> None:
	for cls in classes:
		bpy.utils.unregister_class(cls)

	bpy.types.VIEW3D_MT_snap.remove(draw_button)
