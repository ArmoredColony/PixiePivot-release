import importlib

from .. import module_loader


# WE CONTROL IMPORT ORDER MANUALLY INSTEAD OF 
# AUTO-RESOLVING ALL THE SAME-LEVEL MODULES
source_modules = [
	'utils',
	'ui',
	'icons',
	'runtime_state',

	'gizmos',
	'operators',
	'keymaps',
	'preferences',
]

def resolve_modules():
	return [importlib.import_module(f'.{module}', __package__) for module in source_modules]


def register():
	module_loader.register_modules(resolve_modules())


def unregister():
	module_loader.unregister_modules(resolve_modules())
