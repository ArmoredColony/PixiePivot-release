'''
Global runtime state.
'''


import bpy
import mathutils


class RuntimeState:
	'''
	Manages global variables.
	'''
	
	def __init__(self):
		self.reset()

		# These are NOT meant to be reset manually
		self.original_transform_pivot_point: str = None
		self.original_transform_orientation: str = None

	def reset(self):
		'''
		Stores values that you want to reset every run.
		'''
		
		self.gizmo_matrix: mathutils.Matrix = None

		# mathutils.Vectors
		self.axis_tip_world = {
			'X': None,
			'Y': None,
			'Z': None,
		}

		self.modal_operator_instance: bpy.types.Operator = None
		self.modal_preferences = None # dtypes.ModalPreferences
		self.second_world_co: mathutils.Vector = None


# Create a single instance for everythong to use
runtime_state = RuntimeState()
