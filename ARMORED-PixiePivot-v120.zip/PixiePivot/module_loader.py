import inspect
import importlib
import pkgutil


def discover_module_names(package_name, skip_prefix='_'):
	'''
	Discover modules directly inside a package (non-recursive).

	package_name:	full package name, e.g. 'my_addon.ops' (usually __name__)
	skip_prefix:	skip modules starting with this prefix

	Returns:
		list of FULL module names, e.g.
		['my_addon.ops.op_a', 'my_addon.ops.op_b']
	'''

	pkg = importlib.import_module(package_name)

	module_fullnames = []
	for _, mod_name, is_pkg in pkgutil.iter_modules(pkg.__path__):
		if is_pkg:
			continue
		if mod_name.startswith(skip_prefix):
			continue

		module_fullnames.append(f'{package_name}.{mod_name}')

	return sorted(module_fullnames)


def import_modules(module_fullnames):
	'''
	Import modules by full name.

	module_fullnames: iterable like
		['my_addon.ops.op_a', 'my_addon.ops.op_b']

	Returns:
		list of imported module objects
	'''

	return [importlib.import_module(name) for name in module_fullnames]


def load_package_modules(package_name, skip_prefix='_'):
	'''
	One-liner: discover + import for a package (non-recursive).

	Returns:
		list of imported module objects
	'''
	
	names = discover_module_names(package_name, skip_prefix=skip_prefix)
	return import_modules(names)


def reload_modules(imported_modules):
	for mod in imported_modules:
		importlib.reload(mod)


def register_modules(imported_modules):
	for mod in imported_modules:
		if hasattr(mod, 'register'):
			mod.register()


def unregister_modules(imported_modules):
	for mod in reversed(imported_modules):
		if hasattr(mod, 'unregister'):
			mod.unregister()


def get_module_classes(module):
	return [obj for name, obj in inspect.getmembers(module) if inspect.isclass(obj)]


def get_module_class_names(module):
    return [name for name, obj in inspect.getmembers(module) if inspect.isclass(obj)]